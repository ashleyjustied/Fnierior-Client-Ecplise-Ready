/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javafx.embed.swing.JFXPanel
 *  javafx.scene.media.MediaPlayer$Status
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.util.math.MathHelper
 *  org.lwjgl.input.Keyboard
 *  org.lwjgl.input.Mouse
 *  org.lwjgl.opengl.GL11
 */
package cn.hanabi.gui.cloudmusic.ui;

import cn.hanabi.gui.cloudmusic.MusicManager;
import cn.hanabi.gui.cloudmusic.api.CloudMusicAPI;
import cn.hanabi.gui.cloudmusic.impl.Track;
import cn.hanabi.gui.cloudmusic.ui.CustomTextField;
import cn.hanabi.gui.cloudmusic.ui.TrackSlot;
import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;
import javafx.embed.swing.JFXPanel;
import javafx.scene.media.MediaPlayer;
import javax.swing.SwingUtilities;
import net.ccbluex.liquidbounce.utils.ClientUtils;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public class MusicPlayerUI
extends GuiScreen {
    public float x = 10.0f;
    public float y = 10.0f;
    public float x2 = 0.0f;
    public float y2 = 0.0f;
    public boolean drag = false;
    public CopyOnWriteArrayList<TrackSlot> slots = new CopyOnWriteArrayList();
    public float field_146294_l = 150.0f;
    public float field_146295_m = 250.0f;
    public boolean extended = false;
    public float sidebarAnimation = 0.0f;
    public float scrollY = 0.0f;
    public float scrollAni = 0.0f;
    public float minY = -100.0f;
    public CustomTextField textField = new CustomTextField("");

    public void func_73866_w_() {
        SwingUtilities.invokeLater(JFXPanel::new);
        Keyboard.enableRepeatEvents((boolean)true);
        super.func_73866_w_();
    }

    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        this.sidebarAnimation = RenderUtils.smoothAnimation(this.sidebarAnimation, this.extended ? this.field_146294_l + 5.0f : 0.1f, 50.0f, 0.4f);
        if (Math.ceil(this.sidebarAnimation) > 1.0) {
            float newX = this.x + this.sidebarAnimation;
            float newWidth = this.x + this.field_146294_l + this.sidebarAnimation;
            RenderUtils.drawRoundedRect(newX, this.y, newWidth, this.y + this.field_146295_m, 2, -13684426);
            this.textField.draw(newX + 6.0f, this.y + 2.0f);
            RenderUtils.drawRoundedRect(newWidth - 26.0f, this.y + 5.0f, newWidth - 7.0f, this.y + 17.0f, 2, RenderUtils.isHovering(mouseX, mouseY, newWidth - 26.0f, this.y + 5.0f, newWidth - 7.0f, this.y + 17.0f) || MusicManager.INSTANCE.analyzeThread != null ? new Color(80, 80, 80).getRGB() : -13355204);
            Minecraft.func_71410_x().field_71466_p.func_78276_b("\u5bfc\u5165", (int)(newWidth - 23.0f), (int)(this.y + 6.0f), Color.GRAY.getRGB());
            if (this.textField.textString.isEmpty()) {
                Minecraft.func_71410_x().field_71466_p.func_78276_b("\u8f93\u5165\u6b4c\u5355ID", (int)(newX + 8.0f), (int)(this.y + 6.0f), Color.GRAY.getRGB());
            }
            if (RenderUtils.isHovering(mouseX, mouseY, newX + 5.0f, this.y + 20.0f, newWidth - 5.0f, this.y + this.field_146295_m - 4.0f)) {
                int wheel = Mouse.getDWheel() / 2;
                this.scrollY += (float)wheel;
                if (this.scrollY <= this.minY) {
                    this.scrollY = this.minY;
                }
                if (this.scrollY >= 0.0f) {
                    this.scrollY = 0.0f;
                }
                this.minY = this.field_146295_m - 24.0f;
            } else {
                Mouse.getDWheel();
            }
            this.scrollAni = RenderUtils.getAnimationState(this.scrollAni, this.scrollY, Math.max(10.0f, Math.abs(this.scrollAni - this.scrollY) * 50.0f) * 0.3f);
            float startY = this.y + 21.0f + this.scrollAni;
            float yShouldbe = 0.0f;
            GL11.glEnable((int)3089);
            RenderUtils.doGlScissor((int)(newX + 6.0f), (int)(this.y + 21.0f), 137.0, 224.0);
            for (TrackSlot s : this.slots) {
                if (startY > this.y && startY < this.y + this.field_146295_m - 4.0f) {
                    s.render(newX + 6.0f, startY, mouseX, mouseY);
                }
                startY += 22.0f;
                yShouldbe += 22.0f;
            }
            GL11.glDisable((int)3089);
            if (RenderUtils.isHovering(mouseX, mouseY, newX + 5.0f, this.y + 20.0f, newWidth - 5.0f, this.y + this.field_146295_m - 4.0f)) {
                this.minY -= yShouldbe;
            }
            if (this.slots.size() > 10) {
                float viewable = 224.0f;
                float progress = MathHelper.func_76131_a((float)(-this.scrollAni / -this.minY), (float)0.0f, (float)1.0f);
                float ratio = viewable / yShouldbe * viewable;
                float barHeight = Math.max(ratio, 20.0f);
                float position = progress * (viewable - barHeight);
                RenderUtils.drawRect(newWidth - 5.0f, this.y + 21.0f, newWidth - 2.0f, this.y + 245.0f, new Color(100, 100, 100).getRGB());
                RenderUtils.drawRect(newWidth - 5.0f, this.y + 21.0f + position, newWidth - 2.0f, this.y + 21.0f + position + barHeight, new Color(73, 73, 73).getRGB());
            }
        } else {
            Mouse.getDWheel();
        }
        RenderUtils.drawRoundedRect(this.x, this.y, this.x + this.field_146294_l, this.y + this.field_146295_m, 2, -13684426);
        RenderUtils.drawRoundedRect(this.x, this.y + this.field_146295_m - 60.0f, this.x + this.field_146294_l, this.y + this.field_146295_m, 2, -13355204);
        RenderUtils.drawRect(this.x, this.y + this.field_146295_m - 60.0f, this.x + this.field_146294_l, this.y + this.field_146295_m - 58.0f, -13355204);
        Minecraft.func_71410_x().field_71466_p.func_78276_b("\u7f51\u6613\u4e91\u97f3\u4e50", (int)(this.x + this.field_146294_l / 2.0f - (float)Minecraft.func_71410_x().field_71466_p.func_78256_a("\u7f51\u6613\u4e91\u97f3\u4e50") / 2.0f - 2.0f), (int)(this.y + 5.0f), -1);
        float progress = 0.0f;
        if (MusicManager.INSTANCE.getMediaPlayer() != null) {
            progress = (float)MusicManager.INSTANCE.getMediaPlayer().getCurrentTime().toSeconds() / (float)MusicManager.INSTANCE.getMediaPlayer().getStopTime().toSeconds() * 100.0f;
        }
        RenderUtils.drawRoundedRect(this.x + 10.0f, this.y + this.field_146295_m - 50.0f, this.x + this.field_146294_l - 10.0f, this.y + this.field_146295_m - 46.0f, 1, Color.GRAY.getRGB());
        if (MusicManager.INSTANCE.loadingThread != null) {
            RenderUtils.drawRoundedRect10(this.x + 10.0f, this.y + this.field_146295_m - 50.0f, this.x + 10.0f + 1.3f * MusicManager.INSTANCE.downloadProgress, this.y + this.field_146295_m - 46.0f, 1, Color.WHITE.getRGB());
            RenderUtils.circle(this.x + 10.0f + 1.3f * MusicManager.INSTANCE.downloadProgress, this.y + this.field_146295_m - 48.0f, 3.0f, new Color(255, 255, 255).getRGB());
            RenderUtils.circle(this.x + 10.0f + 1.3f * MusicManager.INSTANCE.downloadProgress, this.y + this.field_146295_m - 48.0f, 2.0f, new Color(255, 50, 50, 255).getRGB());
        } else {
            RenderUtils.drawRoundedRect10(this.x + 10.0f, this.y + this.field_146295_m - 50.0f, this.x + 10.0f + 1.3f * progress, this.y + this.field_146295_m - 46.0f, 1, Color.WHITE.getRGB());
            RenderUtils.circle(this.x + 10.0f + 1.3f * progress, this.y + this.field_146295_m - 48.0f, 3.0f, new Color(255, 255, 255).getRGB());
            RenderUtils.circle(this.x + 10.0f + 1.3f * progress, this.y + this.field_146295_m - 48.0f, 2.0f, new Color(50, 176, 255, 255).getRGB());
        }
        RenderUtils.circle(this.x + this.field_146294_l / 2.0f, this.y + this.field_146295_m - 24.0f, 12.0f, -12565429);
        if (this.extended) {
            Minecraft.func_71410_x().field_71466_p.func_78276_b(" \u00b7 ", (int)(this.x + this.field_146294_l - 15.0f), (int)(this.y + 5.5f), Color.WHITE.getRGB());
        } else {
            Minecraft.func_71410_x().field_71466_p.func_78276_b("\u00b7\u00b7\u00b7", (int)(this.x + this.field_146294_l - 15.0f), (int)(this.y + 5.5f), Color.WHITE.getRGB());
        }
        Minecraft.func_71410_x().field_71466_p.func_78276_b("QR", (int)(this.x + 5.0f), (int)(this.y + 5.5f), Color.WHITE.getRGB());
        String songName = MusicManager.INSTANCE.currentTrack == null ? "\u5f53\u524d\u672a\u5728\u64ad\u653e" : MusicManager.INSTANCE.currentTrack.name;
        String songArtist = MusicManager.INSTANCE.currentTrack == null ? "N/A" : MusicManager.INSTANCE.currentTrack.artists;
        GL11.glEnable((int)3089);
        RenderUtils.doGlScissor((int)this.x, (int)this.y + (int)(this.field_146295_m / 2.0f - 95.0f), (int)this.field_146294_l, 25.0);
        Minecraft.func_71410_x().field_71466_p.func_78276_b(songName, (int)(this.x + this.field_146294_l / 2.0f - (float)(Minecraft.func_71410_x().field_71466_p.func_78256_a(songName) / 2) - 1.5f), (int)(this.y + (this.field_146295_m / 2.0f - 95.0f)), -1);
        Minecraft.func_71410_x().field_71466_p.func_78276_b(songArtist, (int)(this.x + this.field_146294_l / 2.0f - (float)(Minecraft.func_71410_x().field_71466_p.func_78256_a(songArtist) / 2) - 1.5f), (int)(this.y + (this.field_146295_m / 2.0f - 82.0f)), -1);
        GL11.glDisable((int)3089);
        if (MusicManager.INSTANCE.getMediaPlayer() != null) {
            if (MusicManager.INSTANCE.getMediaPlayer().getStatus() == MediaPlayer.Status.PLAYING) {
                Minecraft.func_71410_x().field_71466_p.func_78276_b("| |", (int)(this.x + this.field_146294_l / 2.0f - (float)(Minecraft.func_71410_x().field_71466_p.func_78256_a("K") / 2)), (int)(this.y + this.field_146295_m - 25.5f), Color.WHITE.getRGB());
            } else {
                Minecraft.func_71410_x().field_71466_p.func_78276_b("|>", (int)(this.x + this.field_146294_l / 2.0f - (float)(Minecraft.func_71410_x().field_71466_p.func_78256_a("J") / 2)), (int)(this.y + this.field_146295_m - 25.5f), Color.WHITE.getRGB());
            }
        } else {
            Minecraft.func_71410_x().field_71466_p.func_78276_b("|>", (int)(this.x + this.field_146294_l / 2.0f - (float)(Minecraft.func_71410_x().field_71466_p.func_78256_a("J") / 2)), (int)(this.y + this.field_146295_m - 25.5f), Color.WHITE.getRGB());
        }
        Minecraft.func_71410_x().field_71466_p.func_78276_b("\u2190", (int)(this.x + this.field_146294_l / 2.0f - (float)(Minecraft.func_71410_x().field_71466_p.func_78256_a("L") / 2) - 30.0f), (int)(this.y + this.field_146295_m - 25.5f), Color.WHITE.getRGB());
        Minecraft.func_71410_x().field_71466_p.func_78276_b("\u2192", (int)(this.x + this.field_146294_l / 2.0f - (float)(Minecraft.func_71410_x().field_71466_p.func_78256_a("M") / 2) + 27.5f), (int)(this.y + this.field_146295_m - 25.5f), Color.WHITE.getRGB());
        if (MusicManager.INSTANCE.repeat) {
            Minecraft.func_71410_x().field_71466_p.func_78276_b("\u221e", (int)(this.x + this.field_146294_l - 20.0f), (int)(this.y + this.field_146295_m - 25.5f), Color.WHITE.getRGB());
        } else {
            Minecraft.func_71410_x().field_71466_p.func_78276_b("-", (int)(this.x + this.field_146294_l - 20.0f), (int)(this.y + this.field_146295_m - 25.5f), Color.WHITE.getRGB());
        }
        if (MusicManager.INSTANCE.lyric) {
            Minecraft.func_71410_x().field_71466_p.func_78276_b("\u8bcd", (int)(this.x + 19.0f), (int)(this.y + this.field_146295_m - 25.5f), -1);
        } else {
            Minecraft.func_71410_x().field_71466_p.func_78276_b("\u8bcd", (int)(this.x + 19.0f), (int)(this.y + this.field_146295_m - 25.5f), -9736591);
        }
        if (MusicManager.INSTANCE.currentTrack != null && MusicManager.INSTANCE.getArt(MusicManager.INSTANCE.currentTrack.id) != null) {
            GL11.glPushMatrix();
            RenderUtils.drawImage2(MusicManager.INSTANCE.getArt(MusicManager.INSTANCE.currentTrack.id), 50, 50, 100, 100);
            GL11.glPopMatrix();
        }
        this.dragWindow(mouseX, mouseY);
        super.func_73863_a(mouseX, mouseY, partialTicks);
    }

    protected void func_73864_a(int mouseX, int mouseY, int mouseButton) throws IOException {
        if (RenderUtils.isHovering(mouseX, mouseY, this.x + this.field_146294_l - 15.0f, this.y + 5.0f, this.x + this.field_146294_l - 5.0f, this.y + 15.0f) && mouseButton == 0) {
            boolean bl = this.extended = !this.extended;
        }
        if (mouseButton == 0) {
            if (RenderUtils.isHovering(mouseX, mouseY, this.x + this.field_146294_l / 2.0f - 12.0f, this.y + this.field_146295_m - 36.0f, this.x + this.field_146294_l / 2.0f + 12.0f, this.y + this.field_146295_m - 12.0f) && !MusicManager.INSTANCE.playlist.isEmpty()) {
                if (MusicManager.INSTANCE.currentTrack == null) {
                    try {
                        MusicManager.INSTANCE.play(MusicManager.INSTANCE.playlist.get(0));
                    }
                    catch (Exception e) {
                        e.printStackTrace();
                    }
                } else if (MusicManager.INSTANCE.getMediaPlayer() != null) {
                    if (MusicManager.INSTANCE.getMediaPlayer().getStatus() == MediaPlayer.Status.PLAYING) {
                        MusicManager.INSTANCE.getMediaPlayer().pause();
                    } else {
                        MusicManager.INSTANCE.getMediaPlayer().play();
                    }
                }
            }
            if (RenderUtils.isHovering(mouseX, mouseY, this.x + 39.0f, this.y + this.field_146295_m - 32.0f, this.x + 55.0f, this.y + this.field_146295_m - 16.0f)) {
                MusicManager.INSTANCE.prev();
            }
            if (RenderUtils.isHovering(mouseX, mouseY, this.x + 96.0f, this.y + this.field_146295_m - 32.0f, this.x + 112.0f, this.y + this.field_146295_m - 16.0f)) {
                MusicManager.INSTANCE.next();
            }
            if (RenderUtils.isHovering(mouseX, mouseY, this.x + 10.0f, this.y + this.field_146295_m - 29.0f, this.x + 20.0f, this.y + this.field_146295_m - 19.0f)) {
                boolean bl = MusicManager.INSTANCE.lyric = !MusicManager.INSTANCE.lyric;
            }
            if (RenderUtils.isHovering(mouseX, mouseY, this.x + this.field_146294_l - 20.0f, this.y + this.field_146295_m - 29.0f, this.x + this.field_146294_l - 10.0f, this.y + this.field_146295_m - 19.0f)) {
                boolean bl = MusicManager.INSTANCE.repeat = !MusicManager.INSTANCE.repeat;
            }
            if (RenderUtils.isHovering(mouseX, mouseY, this.x + 5.0f, this.y + 5.0f, this.x + 15.0f, this.y + 15.0f)) {
                // empty if block
            }
        }
        if (this.extended && Math.ceil(this.sidebarAnimation) >= (double)(this.field_146294_l + 5.0f)) {
            float newX = this.x + this.sidebarAnimation;
            float newWidth = this.x + this.field_146294_l + this.sidebarAnimation;
            if (mouseButton == 0 && RenderUtils.isHovering(mouseX, mouseY, newWidth - 26.0f, this.y + 5.0f, newWidth - 7.0f, this.y + 17.0f) && !this.textField.textString.isEmpty() && MusicManager.INSTANCE.analyzeThread == null) {
                MusicManager.INSTANCE.analyzeThread = new Thread(() -> {
                    try {
                        this.slots.clear();
                        MusicManager.INSTANCE.playlist = (ArrayList)CloudMusicAPI.INSTANCE.getPlaylistDetail(this.textField.textString)[1];
                        for (Track t : MusicManager.INSTANCE.playlist) {
                            this.slots.add(new TrackSlot(t));
                        }
                    }
                    catch (Exception ex) {
                        ClientUtils.displayChatMessage("\u89e3\u6790\u6b4c\u5355\u65f6\u53d1\u751f\u9519\u8bef!");
                        ex.printStackTrace();
                    }
                    MusicManager.INSTANCE.analyzeThread = null;
                });
                MusicManager.INSTANCE.analyzeThread.start();
            }
            if (RenderUtils.isHovering(mouseX, mouseY, newX + 5.0f, this.y + 20.0f, newWidth - 5.0f, this.y + this.field_146295_m - 4.0f)) {
                float startY = this.y + 21.0f + this.scrollAni;
                for (TrackSlot s : this.slots) {
                    if (startY > this.y && startY < this.y + this.field_146295_m - 4.0f) {
                        s.click(mouseX, mouseY, mouseButton);
                    }
                    startY += 22.0f;
                }
            }
            this.textField.mouseClicked(mouseX, mouseY, mouseButton);
        }
        super.func_73864_a(mouseX, mouseY, mouseButton);
    }

    protected void func_73869_a(char typedChar, int keyCode) throws IOException {
        if (this.extended) {
            this.textField.keyPressed(keyCode);
            this.textField.charTyped(typedChar);
        }
        super.func_73869_a(typedChar, keyCode);
    }

    public void dragWindow(int mouseX, int mouseY) {
        if (RenderUtils.isHovering(mouseX, mouseY, this.x + this.field_146294_l - 15.0f, this.y + 5.0f, this.x + this.field_146294_l - 5.0f, this.y + 15.0f)) {
            return;
        }
        if (!Mouse.isButtonDown((int)0) && this.drag) {
            this.drag = false;
        }
        if (this.drag) {
            this.x = (float)mouseX - this.x2;
            this.y = (float)mouseY - this.y2;
        } else if (RenderUtils.isHovering(mouseX, mouseY, this.x, this.y, this.x + this.field_146294_l, this.y + 20.0f) && Mouse.isButtonDown((int)0)) {
            this.drag = true;
            this.x2 = (float)mouseX - this.x;
            this.y2 = (float)mouseY - this.y;
        }
    }

    public void func_73876_c() {
        super.func_73876_c();
    }

    public void func_146281_b() {
        Keyboard.enableRepeatEvents((boolean)false);
        super.func_146281_b();
    }

    public boolean func_73868_f() {
        return false;
    }
}

