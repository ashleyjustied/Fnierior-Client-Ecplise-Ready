/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 */
package cn.hanabi.gui.cloudmusic.ui;

import cn.hanabi.gui.cloudmusic.MusicManager;
import cn.hanabi.gui.cloudmusic.impl.Track;
import java.awt.Color;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import net.minecraft.client.Minecraft;

public class TrackSlot {
    public Track track;
    public float x;
    public float y;

    public TrackSlot(Track t) {
        this.track = t;
    }

    public void render(float a, float b, int mouseX, int mouseY) {
        this.x = a;
        this.y = b;
        RenderUtils.drawRoundedRect(this.x, this.y, this.x + 137.0f, this.y + 20.0f, 2, -13355204);
        Minecraft.func_71410_x().field_71466_p.func_78276_b(this.track.name, (int)(this.x + 2.0f), (int)(this.y + 1.0f), Color.WHITE.getRGB());
        Minecraft.func_71410_x().field_71466_p.func_78276_b(this.track.artists, (int)(this.x + 2.0f), (int)(this.y + 10.0f), Color.WHITE.getRGB());
        RenderUtils.drawRoundedRect(this.x + 122.0f, this.y, this.x + 137.0f, this.y + 20.0f, 2, -13355204);
        Minecraft.func_71410_x().field_71466_p.func_78276_b(">", (int)(this.x + 125.5f), (int)(this.y + 5.5f), Color.WHITE.getRGB());
    }

    public void click(int mouseX, int mouseY, int mouseButton) {
        if (RenderUtils.isHovering(mouseX, mouseY, this.x + 125.0f, this.y + 5.0f, this.x + 135.0f, this.y + 15.0f) && mouseButton == 0) {
            try {
                MusicManager.INSTANCE.play(this.track);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}

