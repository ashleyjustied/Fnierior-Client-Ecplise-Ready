/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.FontRenderer
 *  net.minecraft.client.gui.ScaledResolution
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.util.ResourceLocation
 *  org.lwjgl.opengl.GL11
 */
package cn.hanabi.gui.cloudmusic.ui;

import cn.hanabi.gui.cloudmusic.MusicManager;
import cn.hanabi.gui.cloudmusic.ui.CustomTextField;
import java.awt.Color;
import net.ccbluex.liquidbounce.ui.font.Fonts;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import net.ccbluex.liquidbounce.utils.timer.MSTimer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public enum MusicOverlayRenderer {
    INSTANCE;

    public String downloadProgress = "0";
    public long readedSecs = 0L;
    public long totalSecs = 0L;
    public float animation = 0.0f;
    public MSTimer timer = new MSTimer();
    public boolean firstTime = true;

    public void renderOverlay() {
        int addonX = 10;
        int addonY = 60;
        ScaledResolution sr = new ScaledResolution(Minecraft.func_71410_x());
        if (MusicManager.INSTANCE.getCurrentTrack() != null && MusicManager.INSTANCE.getMediaPlayer() != null) {
            this.readedSecs = (int)MusicManager.INSTANCE.getMediaPlayer().getCurrentTime().toSeconds();
            this.totalSecs = (int)MusicManager.INSTANCE.getMediaPlayer().getStopTime().toSeconds();
        }
        if (MusicManager.INSTANCE.getCurrentTrack() != null && MusicManager.INSTANCE.getMediaPlayer() != null) {
            Fonts.font35.drawString(MusicManager.INSTANCE.getCurrentTrack().name + " - " + MusicManager.INSTANCE.getCurrentTrack().artists, 36.0f + (float)addonX, (float)(10 + addonY), Color.WHITE.getRGB());
            Fonts.font35.drawString(this.formatSeconds((int)this.readedSecs) + "/" + this.formatSeconds((int)this.totalSecs), 36.0f + (float)addonX, 20.0f + (float)addonY, -1);
            if (MusicManager.INSTANCE.circleLocations.containsKey(MusicManager.INSTANCE.getCurrentTrack().id)) {
                GL11.glPushMatrix();
                GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                ResourceLocation icon = MusicManager.INSTANCE.circleLocations.get(MusicManager.INSTANCE.getCurrentTrack().id);
                RenderUtils.drawImage2(icon, 4 + addonX, 6 + addonY, 28, 28);
                GL11.glPopMatrix();
            } else {
                MusicManager.INSTANCE.getCircle(MusicManager.INSTANCE.getCurrentTrack());
            }
            try {
                float currentProgress = (float)(MusicManager.INSTANCE.getMediaPlayer().getCurrentTime().toSeconds() / Math.max(1.0, MusicManager.INSTANCE.getMediaPlayer().getStopTime().toSeconds())) * 100.0f;
                RenderUtils.drawArc(18 + addonX, 19 + addonY, 14.0, Color.WHITE.getRGB(), 0, 360.0, 4);
                RenderUtils.drawArc(18 + addonX, 19 + addonY, 14.0, Color.BLUE.getRGB(), 180, 180.0f + currentProgress * 3.6f, 4);
            }
            catch (Exception currentProgress) {
                // empty catch block
            }
        }
        if (MusicManager.INSTANCE.lyric) {
            FontRenderer lyricFont = Minecraft.func_71410_x().field_71466_p;
            int addonYlyr = 50;
            int col = MusicManager.INSTANCE.tlrc.isEmpty() ? Color.GRAY.getRGB() : -16732281;
            GlStateManager.func_179084_k();
            Fonts.font35.drawCenteredString(MusicManager.INSTANCE.lrcCur.contains("_EMPTY_") ? "\u7b49\u5f85\u4e2d......." : MusicManager.INSTANCE.lrcCur, (float)sr.func_78326_a() / 2.0f - 0.5f, sr.func_78328_b() - 140 - 80 + addonYlyr, -16732281);
            Fonts.font35.drawCenteredString(MusicManager.INSTANCE.tlrcCur.contains("_EMPTY_") ? "Waiting......." : MusicManager.INSTANCE.tlrcCur, (float)sr.func_78326_a() / 2.0f, (float)(sr.func_78328_b() - 125) + 0.5f - 80.0f + (float)addonYlyr, col);
            GlStateManager.func_179147_l();
        }
        if (MusicManager.showMsg) {
            if (this.firstTime) {
                this.timer.reset();
                this.firstTime = false;
            }
            FontRenderer wqy = Minecraft.func_71410_x().field_71466_p;
            FontRenderer sans = Minecraft.func_71410_x().field_71466_p;
            float width1 = wqy.func_78256_a(MusicManager.INSTANCE.getCurrentTrack().name);
            float width2 = sans.func_78256_a("Now playing");
            float allWidth = Math.max(Math.max(width1, width2), 150.0f);
            RenderUtils.drawRect((float)sr.func_78326_a() - this.animation, 5.0f, (float)sr.func_78326_a(), 40.0f, CustomTextField.reAlpha(Color.BLACK.getRGB(), 0.7f));
            if (MusicManager.INSTANCE.circleLocations.containsKey(MusicManager.INSTANCE.getCurrentTrack().id)) {
                GL11.glPushMatrix();
                GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                ResourceLocation icon = MusicManager.INSTANCE.circleLocations.get(MusicManager.INSTANCE.getCurrentTrack().id);
                RenderUtils.drawImage2(icon, (int)((float)sr.func_78326_a() - this.animation + 5.0f), 8, 28, 28);
                GL11.glPopMatrix();
            } else {
                MusicManager.INSTANCE.getCircle(MusicManager.INSTANCE.getCurrentTrack());
            }
            RenderUtils.drawArc((float)sr.func_78326_a() - this.animation - 31.0f + 50.0f, 22.0f, 14.0, Color.WHITE.getRGB(), 0, 360.0, 2);
            sans.func_78276_b("Now playing", (int)((float)sr.func_78326_a() - this.animation - 12.0f + 50.0f), 8, Color.WHITE.getRGB());
            wqy.func_78276_b(MusicManager.INSTANCE.getCurrentTrack().name, (int)((float)sr.func_78326_a() - this.animation - 12.0f + 50.0f), 26, Color.WHITE.getRGB());
            if (this.timer.hasTimePassed(5000L)) {
                this.animation = (float)RenderUtils.getAnimationStateSmooth(0.0, this.animation, 10.0f / (float)Minecraft.func_175610_ah());
                if (this.animation <= 0.0f) {
                    MusicManager.showMsg = false;
                    this.firstTime = true;
                }
            } else {
                this.animation = (float)RenderUtils.getAnimationStateSmooth(allWidth, this.animation, 10.0f / (float)Minecraft.func_175610_ah());
            }
        }
        GlStateManager.func_179117_G();
    }

    public String formatSeconds(int seconds) {
        String rstl = "";
        int mins = seconds / 60;
        if (mins < 10) {
            rstl = rstl + "0";
        }
        rstl = rstl + mins + ":";
        if ((seconds %= 60) < 10) {
            rstl = rstl + "0";
        }
        rstl = rstl + seconds;
        return rstl;
    }
}

