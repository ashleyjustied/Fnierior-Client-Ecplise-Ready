/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.Packet
 *  net.minecraft.network.PacketBuffer
 *  net.minecraft.network.play.INetHandlerPlayServer
 *  net.minecraft.network.play.client.CPacketPlayerTryUseItem
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.math.BlockPos
 */
package co.uk.hexeption.utils;

import java.io.IOException;
import net.ccbluex.liquidbounce.api.minecraft.util.WBlockPos;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

public class C08PacketPlayerBlockPlacement
extends CPacketPlayerTryUseItem
implements Packet<INetHandlerPlayServer> {
    private static final BlockPos field_179726_a = new BlockPos(-1, -1, -1);
    private BlockPos position;
    private WBlockPos position2;
    private int placedBlockDirection;
    private EnumHand stack;
    private ItemStack stack2;
    public float facingX;
    public float facingY;
    public float facingZ;

    public C08PacketPlayerBlockPlacement() {
    }

    public C08PacketPlayerBlockPlacement(EnumHand p_i45930_1_) {
        this(field_179726_a, 255, p_i45930_1_, 0.0f, 0.0f, 0.0f);
    }

    public C08PacketPlayerBlockPlacement(BlockPos p_i45931_1_, int p_i45931_2_, ItemStack p_i45931_3_, float p_i45931_4_, float p_i45931_5_, float p_i45931_6_) {
        this.position = p_i45931_1_;
        this.placedBlockDirection = p_i45931_2_;
        this.stack2 = p_i45931_3_ != null ? p_i45931_3_.func_77946_l() : null;
        this.facingX = p_i45931_4_;
        this.facingY = p_i45931_5_;
        this.facingZ = p_i45931_6_;
    }

    public C08PacketPlayerBlockPlacement(WBlockPos p_i45931_1_, int p_i45931_2_, EnumHand p_i46858_3_, float p_i45931_4_, float p_i45931_5_, float p_i45931_6_) {
        this.position2 = p_i45931_1_;
        this.placedBlockDirection = p_i45931_2_;
        this.stack = p_i46858_3_;
        this.facingX = p_i45931_4_;
        this.facingY = p_i45931_5_;
        this.facingZ = p_i45931_6_;
    }

    public C08PacketPlayerBlockPlacement(BlockPos p_i45931_1_, int p_i45931_2_, EnumHand p_i46858_3_, float p_i45931_4_, float p_i45931_5_, float p_i45931_6_) {
        this.position = p_i45931_1_;
        this.placedBlockDirection = p_i45931_2_;
        this.stack = p_i46858_3_;
        this.facingX = p_i45931_4_;
        this.facingY = p_i45931_5_;
        this.facingZ = p_i45931_6_;
    }

    public void func_148837_a(PacketBuffer p_readPacketData_1_) throws IOException {
        this.position = p_readPacketData_1_.func_179259_c();
        this.placedBlockDirection = p_readPacketData_1_.readUnsignedByte();
        this.stack = (EnumHand)p_readPacketData_1_.func_179257_a(EnumHand.class);
        this.facingX = (float)p_readPacketData_1_.readUnsignedByte() / 16.0f;
        this.facingY = (float)p_readPacketData_1_.readUnsignedByte() / 16.0f;
        this.facingZ = (float)p_readPacketData_1_.readUnsignedByte() / 16.0f;
    }

    public void func_148840_b(PacketBuffer p_writePacketData_1_) throws IOException {
        p_writePacketData_1_.func_179255_a(this.position);
        p_writePacketData_1_.writeByte(this.placedBlockDirection);
        p_writePacketData_1_.func_179249_a((Enum)this.stack);
        p_writePacketData_1_.writeByte((int)(this.facingX * 16.0f));
        p_writePacketData_1_.writeByte((int)(this.facingY * 16.0f));
        p_writePacketData_1_.writeByte((int)(this.facingZ * 16.0f));
    }

    public void func_148833_a(INetHandlerPlayServer p_processPacket_1_) {
        p_processPacket_1_.func_147346_a((CPacketPlayerTryUseItem)this);
    }

    public BlockPos getPosition() {
        return this.position;
    }

    public int getPlacedBlockDirection() {
        return this.placedBlockDirection;
    }

    public EnumHand getStack() {
        return this.stack;
    }

    public float getPlacedBlockOffsetX() {
        return this.facingX;
    }

    public float getPlacedBlockOffsetY() {
        return this.facingY;
    }

    public float getPlacedBlockOffsetZ() {
        return this.facingZ;
    }
}

