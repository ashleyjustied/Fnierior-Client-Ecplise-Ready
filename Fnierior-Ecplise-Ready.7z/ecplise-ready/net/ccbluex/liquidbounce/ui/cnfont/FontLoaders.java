/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.util.ResourceLocation
 */
package net.ccbluex.liquidbounce.ui.cnfont;

import java.awt.Font;
import net.ccbluex.liquidbounce.ui.cnfont.FontDrawer;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;

public class FontLoaders {
    public static FontDrawer G30;
    public static FontDrawer G16;
    public static FontDrawer G35;
    public static FontDrawer G40;
    public static FontDrawer G45;
    public static FontDrawer G25;
    public static FontDrawer G20;

    public static void initFonts() {
        G20 = FontLoaders.getGenshin("genshin.ttf", 20, true);
        G25 = FontLoaders.getGenshin("genshin.ttf", 25, true);
        G30 = FontLoaders.getGenshin("genshin.ttf", 30, true);
        G35 = FontLoaders.getGenshin("genshin.ttf", 35, true);
        G40 = FontLoaders.getGenshin("genshin.ttf", 40, true);
        G16 = FontLoaders.getGenshin("genshin.ttf", 16, true);
        G45 = FontLoaders.getGenshin("genshin.ttf", 45, true);
    }

    public static FontDrawer getFont(String name, int size, boolean antiAliasing) {
        Font font;
        try {
            font = Font.createFont(0, Minecraft.func_71410_x().func_110442_L().func_110536_a(new ResourceLocation("pride/font" + name)).func_110527_b()).deriveFont(0, size);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Error loading font");
            font = new Font("default", 0, size);
        }
        return new FontDrawer(font, antiAliasing);
    }

    public static FontDrawer getGenshin(String name, int size, boolean antiAliasing) {
        Font font;
        try {
            font = Font.createFont(0, Minecraft.func_71410_x().func_110442_L().func_110536_a(new ResourceLocation("pride/font/genshin.ttf")).func_110527_b()).deriveFont(0, size);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Error loading font");
            font = new Font("default", 0, size);
        }
        return new FontDrawer(font, antiAliasing);
    }
}

