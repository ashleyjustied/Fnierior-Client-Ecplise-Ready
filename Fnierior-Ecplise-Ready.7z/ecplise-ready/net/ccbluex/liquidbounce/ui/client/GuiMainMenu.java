/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.ScaledResolution
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.util.ResourceLocation
 *  org.jetbrains.annotations.NotNull
 */
package net.ccbluex.liquidbounce.ui.client;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Calendar;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import me.ui.IGuiButton;
import net.ccbluex.liquidbounce.api.util.WrappedGuiScreen;
import net.ccbluex.liquidbounce.ui.client.GuiBackground;
import net.ccbluex.liquidbounce.ui.client.GuiContributors;
import net.ccbluex.liquidbounce.ui.client.GuiModsMenu;
import net.ccbluex.liquidbounce.ui.client.GuiServerStatus;
import net.ccbluex.liquidbounce.ui.client.altmanager.GuiAltManager;
import net.ccbluex.liquidbounce.ui.cnfont.FontDrawer;
import net.ccbluex.liquidbounce.ui.cnfont.FontLoaders;
import net.ccbluex.liquidbounce.utils.MinecraftInstance;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\u0010\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0010H\u0016J \u0010\u0011\u001a\u00020\u000e2\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u00132\u0006\u0010\u0015\u001a\u00020\u000bH\u0016J\b\u0010\u0016\u001a\u00020\u000eH\u0016R \u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0006\u0010\u0007\"\u0004\b\b\u0010\tR\u000e\u0010\n\u001a\u00020\u000bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u000bX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0017"}, d2={"Lnet/ccbluex/liquidbounce/ui/client/GuiMainMenu;", "Lnet/ccbluex/liquidbounce/api/util/WrappedGuiScreen;", "()V", "arrayList", "Ljava/util/ArrayList;", "Lme/ui/IGuiButton;", "getArrayList", "()Ljava/util/ArrayList;", "setArrayList", "(Ljava/util/ArrayList;)V", "currentX", "", "currentY", "actionPerformed", "", "button", "Lnet/ccbluex/liquidbounce/api/minecraft/client/gui/IGuiButton;", "drawScreen", "mouseX", "", "mouseY", "partialTicks", "initGui", "Fnierior"})
public final class GuiMainMenu
extends WrappedGuiScreen {
    private float currentX;
    private float currentY;
    @NotNull
    private ArrayList<IGuiButton> arrayList = new ArrayList();

    @NotNull
    public final ArrayList<IGuiButton> getArrayList() {
        return this.arrayList;
    }

    public final void setArrayList(@NotNull ArrayList<IGuiButton> arrayList) {
        Intrinsics.checkParameterIsNotNull(arrayList, "<set-?>");
        this.arrayList = arrayList;
    }

    @Override
    public void initGui() {
        double defaultHeight = (double)this.getRepresentedScreen().getHeight() / 4.5 + (double)18;
        this.getRepresentedScreen().getButtonList().add(MinecraftInstance.classProvider.createGuiButton(100, this.getRepresentedScreen().getWidth() - 120, (int)(defaultHeight + (double)96), 100, 20, "Alt Manager"));
        this.getRepresentedScreen().getButtonList().add(MinecraftInstance.classProvider.createGuiButton(102, this.getRepresentedScreen().getWidth() - 120, (int)(defaultHeight + (double)72), 100, 20, "Back Ground"));
        this.getRepresentedScreen().getButtonList().add(MinecraftInstance.classProvider.createGuiButton(1, this.getRepresentedScreen().getWidth() - 120, (int)(defaultHeight + (double)24), 100, 20, "Single Player"));
        this.getRepresentedScreen().getButtonList().add(MinecraftInstance.classProvider.createGuiButton(2, this.getRepresentedScreen().getWidth() - 120, (int)(defaultHeight + (double)48), 100, 20, "Multi Player"));
        this.getRepresentedScreen().getButtonList().add(MinecraftInstance.classProvider.createGuiButton(0, this.getRepresentedScreen().getWidth() - 120, (int)(defaultHeight + (double)120), 100, 20, "MC Options"));
        this.getRepresentedScreen().getButtonList().add(MinecraftInstance.classProvider.createGuiButton(4, this.getRepresentedScreen().getWidth() - 120, (int)(defaultHeight + (double)144), 100, 20, "Quit Game"));
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        int h = this.getRepresentedScreen().getHeight();
        int w = this.getRepresentedScreen().getWidth();
        ScaledResolution res = new ScaledResolution(MinecraftInstance.mc2);
        float xDiff = ((float)(mouseX - h / 2) - this.currentX) / (float)res.func_78325_e();
        float yDiff = ((float)(mouseY - w / 2) - this.currentY) / (float)res.func_78325_e();
        this.currentX += xDiff * 0.3f;
        this.currentY += yDiff * 0.3f;
        Calendar cal = Calendar.getInstance();
        int hour = cal.get(11);
        int minute = cal.get(12);
        int minuteOfDay = hour * 60 + minute;
        boolean start = false;
        int end = 960;
        GlStateManager.func_179109_b((float)(this.currentX / 30.0f), (float)(this.currentY / 15.0f), (float)0.0f);
        if (minuteOfDay >= 0 && minuteOfDay <= end) {
            ResourceLocation tex = new ResourceLocation("pride/bg-morning.png");
            RenderUtils.drawImage2(tex, -30, -30, res.func_78326_a() + 60, res.func_78328_b() + 60);
        } else {
            ResourceLocation tex = new ResourceLocation("pride/bg-night.png");
            RenderUtils.drawImage2(tex, -30, -30, res.func_78326_a() + 60, res.func_78328_b() + 60);
        }
        GlStateManager.func_179109_b((float)(-this.currentX / 30.0f), (float)(-this.currentY / 15.0f), (float)0.0f);
        RenderUtils.drawRectJiaoao(this.getRepresentedScreen().getWidth() - 142, 0, this.getRepresentedScreen().getWidth(), this.getRepresentedScreen().getHeight(), new Color(0, 0, 0, 80).getRGB());
        float f = (float)((double)(47 - FontLoaders.G30.getStringWidth("Fnierior") / 2 + this.getRepresentedScreen().getWidth()) - 70.5);
        float f2 = (float)this.getRepresentedScreen().getHeight() / 6.0f;
        Color color = Color.WHITE;
        Intrinsics.checkExpressionValueIsNotNull(color, "Color.WHITE");
        FontLoaders.G30.drawCenteredString("Fnierior", f, f2, color.getRGB(), true);
        FontDrawer fontDrawer = FontLoaders.G16;
        Intrinsics.checkExpressionValueIsNotNull(fontDrawer, "FontLoaders.G16");
        int n = h - fontDrawer.getHeight();
        Color color2 = Color.WHITE;
        Intrinsics.checkExpressionValueIsNotNull(color2, "Color.WHITE");
        FontLoaders.G16.drawString(" \u4e00\u5b9a\u662f\u7b26\u6faa\u5e72\u7684\uff01", 2, n, color2.getRGB());
        this.getRepresentedScreen().superDrawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    public void actionPerformed(@NotNull net.ccbluex.liquidbounce.api.minecraft.client.gui.IGuiButton button) {
        Intrinsics.checkParameterIsNotNull(button, "button");
        switch (button.getId()) {
            case 0: {
                MinecraftInstance.mc.displayGuiScreen(MinecraftInstance.classProvider.createGuiOptions(this.getRepresentedScreen(), MinecraftInstance.mc.getGameSettings()));
                break;
            }
            case 1: {
                MinecraftInstance.mc.displayGuiScreen(MinecraftInstance.classProvider.createGuiSelectWorld(this.getRepresentedScreen()));
                break;
            }
            case 2: {
                MinecraftInstance.mc.displayGuiScreen(MinecraftInstance.classProvider.createGuiMultiplayer(this.getRepresentedScreen()));
                break;
            }
            case 4: {
                MinecraftInstance.mc.shutdown();
                break;
            }
            case 100: {
                MinecraftInstance.mc.displayGuiScreen(MinecraftInstance.classProvider.wrapGuiScreen(new GuiAltManager(this.getRepresentedScreen())));
                break;
            }
            case 101: {
                MinecraftInstance.mc.displayGuiScreen(MinecraftInstance.classProvider.wrapGuiScreen(new GuiServerStatus(this.getRepresentedScreen())));
                break;
            }
            case 102: {
                MinecraftInstance.mc.displayGuiScreen(MinecraftInstance.classProvider.wrapGuiScreen(new GuiBackground(this.getRepresentedScreen())));
                break;
            }
            case 103: {
                MinecraftInstance.mc.displayGuiScreen(MinecraftInstance.classProvider.wrapGuiScreen(new GuiModsMenu(this.getRepresentedScreen())));
                break;
            }
            case 108: {
                MinecraftInstance.mc.displayGuiScreen(MinecraftInstance.classProvider.wrapGuiScreen(new GuiContributors(this.getRepresentedScreen())));
                break;
            }
        }
    }
}

