/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  org.jetbrains.annotations.NotNull
 *  org.lwjgl.opengl.GL11
 */
package net.ccbluex.liquidbounce.ui.client.hud.element.elements;

import java.awt.Color;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import kotlin.Metadata;
import kotlin.TypeCastException;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.StringCompanionObject;
import me.utils.render.RoundedUtil;
import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.api.minecraft.client.gui.IFontRenderer;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.modules.color.Gident;
import net.ccbluex.liquidbounce.features.module.modules.render.ClickGUI;
import net.ccbluex.liquidbounce.features.module.modules.render.HUD;
import net.ccbluex.liquidbounce.ui.client.hud.element.Border;
import net.ccbluex.liquidbounce.ui.client.hud.element.Element;
import net.ccbluex.liquidbounce.ui.client.hud.element.ElementInfo;
import net.ccbluex.liquidbounce.ui.client.hud.element.Side;
import net.ccbluex.liquidbounce.ui.client.hud.element.elements.InfosUtils.Recorder;
import net.ccbluex.liquidbounce.ui.font.Fonts;
import net.ccbluex.liquidbounce.utils.DrRenderUtils;
import net.ccbluex.liquidbounce.utils.blur.BlurBuffer;
import net.ccbluex.liquidbounce.utils.blur.StencilUtil;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import net.ccbluex.liquidbounce.value.BoolValue;
import net.ccbluex.liquidbounce.value.FloatValue;
import net.ccbluex.liquidbounce.value.FontValue;
import net.ccbluex.liquidbounce.value.IntegerValue;
import net.ccbluex.liquidbounce.value.ListValue;
import net.minecraft.client.Minecraft;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.opengl.GL11;

@ElementInfo(name="Session Info")
@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u0000|\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0006\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\t\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0015\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B-\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0006\u0012\b\b\u0002\u0010\u0007\u001a\u00020\b\u00a2\u0006\u0002\u0010\tJ\u0018\u0010<\u001a\u00020=2\u0006\u0010>\u001a\u00020\u00062\u0006\u0010\u0004\u001a\u00020\u0006H\u0002J\b\u0010?\u001a\u00020@H\u0016J\u0006\u0010A\u001a\u00020#J\u0006\u0010B\u001a\u00020#J\b\u0010C\u001a\u00020DH\u0002J\b\u0010E\u001a\u00020\u0019H\u0002J\u0006\u0010F\u001a\u00020=R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u000eX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u000eX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u000eX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0011\u0010\u0013\u001a\u00020\u0014\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0016R\u000e\u0010\u0017\u001a\u00020\u0014X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u0018\u001a\u00020\u0019X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u001a\u0010\u001b\"\u0004\b\u001c\u0010\u001dR\u0011\u0010\u001e\u001a\u00020\u001f\u00a2\u0006\b\n\u0000\u001a\u0004\b \u0010!R\u0016\u0010\"\u001a\n $*\u0004\u0018\u00010#0#X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0016\u0010%\u001a\n $*\u0004\u0018\u00010#0#X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0016\u0010&\u001a\n $*\u0004\u0018\u00010#0#X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0016\u0010'\u001a\n $*\u0004\u0018\u00010#0#X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010(\u001a\u00020\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010)\u001a\b\u0012\u0004\u0012\u00020+0*X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010,\u001a\u00020\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010-\u001a\u00020\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010.\u001a\u00020\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010/\u001a\u00020\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u00100\u001a\u00020\u0014X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u00101\u001a\u00020\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u00102\u001a\u00020\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u00103\u001a\u000204X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u00105\u001a\u00020\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u00106\u001a\u00020\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u00107\u001a\u00020\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u00108\u001a\u00020\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001a\u00109\u001a\u00020\u0019X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b:\u0010\u001b\"\u0004\b;\u0010\u001d\u00a8\u0006G"}, d2={"Lnet/ccbluex/liquidbounce/ui/client/hud/element/elements/SessionInfo;", "Lnet/ccbluex/liquidbounce/ui/client/hud/element/Element;", "x", "", "y", "scale", "", "side", "Lnet/ccbluex/liquidbounce/ui/client/hud/element/Side;", "(DDFLnet/ccbluex/liquidbounce/ui/client/hud/element/Side;)V", "Shadow", "Lnet/ccbluex/liquidbounce/value/BoolValue;", "animatedPlaytime", "bgalphaValue", "Lnet/ccbluex/liquidbounce/value/IntegerValue;", "bgblueValue", "bggreenValue", "bgredValue", "blur", "colorMode", "Lnet/ccbluex/liquidbounce/value/ListValue;", "getColorMode", "()Lnet/ccbluex/liquidbounce/value/ListValue;", "degree", "endTime", "", "getEndTime", "()J", "setEndTime", "(J)V", "fontValue", "Lnet/ccbluex/liquidbounce/value/FontValue;", "getFontValue", "()Lnet/ccbluex/liquidbounce/value/FontValue;", "gradientColor1", "Ljava/awt/Color;", "kotlin.jvm.PlatformType", "gradientColor2", "gradientColor3", "gradientColor4", "hourYAnimation", "linesLeft", "", "", "minuteSeparateWidthAnim1", "minuteSeparateWidthAnim2", "minuteYAnimation1", "minuteYAnimation2", "modeValue", "outline", "playtimeWidth", "radiusValue", "Lnet/ccbluex/liquidbounce/value/FloatValue;", "secondYAnimation1", "secondYAnimation2", "secondsSeparateWidthAnim1", "secondsSeparateWidthAnim2", "startTime", "getStartTime", "setStartTime", "drawAnimatedPlaytime", "", "playtimeX", "drawElement", "Lnet/ccbluex/liquidbounce/ui/client/hud/element/Border;", "getAlternateClientColor", "getClientColor", "getPlayTime", "", "getTimeDiff", "reset", "Fnierior"})
public final class SessionInfo
extends Element {
    private final ListValue modeValue;
    private final BoolValue blur;
    private final BoolValue Shadow;
    private final FloatValue radiusValue;
    private final IntegerValue bgredValue;
    private final IntegerValue bggreenValue;
    private final IntegerValue bgblueValue;
    private final IntegerValue bgalphaValue;
    private final BoolValue outline;
    private long startTime;
    private long endTime;
    private final List<String> linesLeft;
    private final BoolValue animatedPlaytime;
    @NotNull
    private final ListValue colorMode;
    private final ListValue degree;
    private float playtimeWidth;
    private Color gradientColor1;
    private Color gradientColor2;
    private Color gradientColor3;
    private Color gradientColor4;
    @NotNull
    private final FontValue fontValue;
    private float hourYAnimation;
    private float minuteYAnimation1;
    private float minuteYAnimation2;
    private float secondYAnimation2;
    private float secondYAnimation1;
    private float secondsSeparateWidthAnim1;
    private float secondsSeparateWidthAnim2;
    private float minuteSeparateWidthAnim1;
    private float minuteSeparateWidthAnim2;

    public final long getStartTime() {
        return this.startTime;
    }

    public final void setStartTime(long l) {
        this.startTime = l;
    }

    public final long getEndTime() {
        return this.endTime;
    }

    public final void setEndTime(long l) {
        this.endTime = l;
    }

    @NotNull
    public final ListValue getColorMode() {
        return this.colorMode;
    }

    @NotNull
    public final FontValue getFontValue() {
        return this.fontValue;
    }

    public final void reset() {
        this.startTime = System.currentTimeMillis();
        this.endTime = -1L;
    }

    @NotNull
    public final Color getClientColor() {
        return new Color(((Number)Gident.redValue.get()).intValue(), ((Number)Gident.greenValue.get()).intValue(), ((Number)Gident.blueValue.get()).intValue());
    }

    @NotNull
    public final Color getAlternateClientColor() {
        return new Color(((Number)Gident.redValue2.get()).intValue(), ((Number)Gident.greenValue2.get()).intValue(), ((Number)Gident.blueValue2.get()).intValue());
    }

    /*
     * WARNING - void declaration
     */
    private final void drawAnimatedPlaytime(float playtimeX, float y) {
        int[] playTime = this.getPlayTime();
        RoundedUtil.drawRoundOutline(playtimeX, y + (float)21, this.playtimeWidth, 13.0f, 6.0f, 0.5f, DrRenderUtils.applyOpacity(Color.WHITE, 0.0f), Color.WHITE);
        StencilUtil.initStencilToWrite();
        RoundedUtil.drawRound(playtimeX, y + (float)22, this.playtimeWidth, 11.0f, 6.0f, new Color(30, 30, 30));
        StencilUtil.readStencilBuffer(1);
        float secondX = playtimeX + this.playtimeWidth - (float)7;
        Fonts.font35.drawString("s", secondX, y + (float)24, -1);
        int secondsFirstPlace = playTime[2] % 10;
        this.secondYAnimation2 = (float)DrRenderUtils.animate(20 * secondsFirstPlace, this.secondYAnimation2, 0.02);
        this.secondsSeparateWidthAnim1 = (float)DrRenderUtils.animate(Fonts.font35.getStringWidth(String.valueOf(secondsFirstPlace)), this.secondsSeparateWidthAnim1, 0.05);
        secondX -= (float)((double)this.secondsSeparateWidthAnim1 + 0.5);
        int n = 0;
        int n2 = 9;
        while (n <= n2) {
            void i;
            Fonts.font35.drawString(String.valueOf((int)i), secondX, y + (float)24 + (float)(i * 20) - this.secondYAnimation2, -1);
            ++i;
        }
        int secondsSecondPlace = Math.floorDiv(playTime[2], 10);
        this.secondYAnimation1 = (float)DrRenderUtils.animate(20 * secondsSecondPlace, this.secondYAnimation1, 0.02);
        this.secondsSeparateWidthAnim2 = (float)DrRenderUtils.animate(Fonts.font35.getStringWidth(String.valueOf(secondsSecondPlace)), this.secondsSeparateWidthAnim2, 0.05);
        secondX -= (float)((double)this.secondsSeparateWidthAnim2 + 0.5);
        n2 = 0;
        int n3 = 9;
        while (n2 <= n3) {
            void i;
            Fonts.font35.drawString(String.valueOf((int)i), secondX, y + (float)24 + (float)(i * 20) - this.secondYAnimation1, -1);
            ++i;
        }
        if (playTime[1] > 0) {
            int i;
            float minuteX = playtimeX + this.playtimeWidth - (float)27;
            Fonts.font35.drawString("m", minuteX, y + (float)24, -1);
            int minuteFirstPlace = playTime[1] % 10;
            this.minuteYAnimation1 = (float)DrRenderUtils.animate(20 * minuteFirstPlace, this.minuteYAnimation1, 0.02);
            this.minuteSeparateWidthAnim1 = (float)DrRenderUtils.animate(Fonts.font35.getStringWidth(String.valueOf(minuteFirstPlace)), this.minuteSeparateWidthAnim1, 0.05);
            minuteX -= (float)((double)this.minuteSeparateWidthAnim1 + 0.5);
            int n4 = 0;
            int n5 = 9;
            while (n4 <= n5) {
                void i2;
                Fonts.font35.drawString(String.valueOf((int)i2), minuteX, y + (float)24 + (float)(i2 * 20) - this.minuteYAnimation1, -1);
                ++i2;
            }
            int minuteSecondPlace = Math.floorDiv(playTime[1], 10);
            this.minuteYAnimation2 = (float)DrRenderUtils.animate(20 * minuteSecondPlace, this.minuteYAnimation2, 0.02);
            this.minuteSeparateWidthAnim2 = (float)DrRenderUtils.animate(Fonts.font35.getStringWidth(String.valueOf(minuteSecondPlace)), this.minuteSeparateWidthAnim2, 0.05);
            minuteX -= (float)((double)this.minuteSeparateWidthAnim2 + 0.5);
            n5 = 0;
            int n6 = 9;
            while (n5 <= n6) {
                Fonts.font35.drawString(String.valueOf(i), minuteX, y + (float)24 + (float)(i * 20) - this.minuteYAnimation2, -1);
                ++i;
            }
            if (playTime[0] > 0) {
                this.hourYAnimation = (float)DrRenderUtils.animate(20 * (playTime[0] % 10), this.hourYAnimation, 0.02);
                Fonts.font35.drawString("h", playtimeX + this.playtimeWidth - (float)44, y + (float)24, -1);
                n6 = 9;
                for (i = 0; i <= n6; ++i) {
                    Fonts.font35.drawString(String.valueOf(i), playtimeX + this.playtimeWidth - (float)49, y + (float)24 + (float)(i * 20) - this.hourYAnimation, -1);
                }
            }
        }
        StencilUtil.uninitStencilBuffer();
    }

    private final int[] getPlayTime() {
        long diff = this.getTimeDiff();
        long diffSeconds = 0L;
        long diffMinutes = 0L;
        long diffHours = 0L;
        if (diff > 0L) {
            diffSeconds = diff / (long)1000 % (long)60;
            diffMinutes = diff / (long)60000 % (long)60;
            diffHours = diff / (long)3600000 % (long)24;
        }
        return new int[]{(int)diffHours, (int)diffMinutes, (int)diffSeconds};
    }

    private final long getTimeDiff() {
        return (this.endTime == -1L ? System.currentTimeMillis() : this.endTime) - this.startTime;
    }

    /*
     * WARNING - void declaration
     */
    @Override
    @NotNull
    public Border drawElement() {
        String string = (String)this.modeValue.get();
        boolean bl = false;
        String string2 = string;
        if (string2 == null) {
            throw new TypeCastException("null cannot be cast to non-null type java.lang.String");
        }
        String string3 = string2.toLowerCase();
        Intrinsics.checkExpressionValueIsNotNull(string3, "(this as java.lang.String).toLowerCase()");
        switch (string3) {
            case "normal": {
                String string4;
                IFontRenderer fontRenderer = (IFontRenderer)this.fontValue.get();
                float y2 = (float)(fontRenderer.getFontHeight() * 5) + 11.0f + 3.0f;
                float x2 = 120.0f;
                float floatX = (float)this.getRenderX();
                float floatY = (float)this.getRenderY();
                if (((Boolean)this.blur.get()).booleanValue()) {
                    GL11.glTranslated((double)(-this.getRenderX()), (double)(-this.getRenderY()), (double)0.0);
                    GL11.glPushMatrix();
                    BlurBuffer.blurRoundArea(floatX, floatY, x2, y2, (int)((Number)this.radiusValue.get()).floatValue());
                    GL11.glPopMatrix();
                    GL11.glTranslated((double)this.getRenderX(), (double)this.getRenderY(), (double)0.0);
                }
                if (((Boolean)this.Shadow.get()).booleanValue()) {
                    RenderUtils.drawShadowWithCustomAlpha(0.0f, 0.0f, x2, y2, 255.0f);
                }
                String time = null;
                Minecraft minecraft = Minecraft.func_71410_x();
                Intrinsics.checkExpressionValueIsNotNull(minecraft, "Minecraft.getMinecraft()");
                if (minecraft.func_71356_B()) {
                    string4 = "SinglePlayer";
                } else {
                    long durationInMillis = System.currentTimeMillis() - Recorder.INSTANCE.getStartTime();
                    long second = durationInMillis / (long)1000 % (long)60;
                    long minute = durationInMillis / (long)60000 % (long)60;
                    long hour = durationInMillis / (long)3600000 % (long)24;
                    StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
                    String string5 = "%02d:%02d:%02d";
                    Object[] objectArray = new Object[]{hour, minute, second};
                    boolean bl2 = false;
                    String string6 = String.format(string5, Arrays.copyOf(objectArray, objectArray.length));
                    string4 = string6;
                    Intrinsics.checkExpressionValueIsNotNull(string6, "java.lang.String.format(format, *args)");
                }
                time = string4;
                RoundedUtil.drawRound(0.0f, 0.0f, x2, y2, ((Number)this.radiusValue.get()).floatValue(), new Color(((Number)this.bgredValue.get()).intValue(), ((Number)this.bggreenValue.get()).intValue(), ((Number)this.bgblueValue.get()).intValue(), ((Number)this.bgalphaValue.get()).intValue()));
                RenderUtils.drawGradientSideways(2.22, (double)fontRenderer.getFontHeight() + 2.5 + 0.0 - 1.0, (double)x2 - 2.22, (double)fontRenderer.getFontHeight() + 2.5 + (double)1.16f - 1.0, new Color(((Number)Gident.redValue.get()).intValue(), ((Number)Gident.greenValue.get()).intValue(), ((Number)Gident.blueValue.get()).intValue()).getRGB(), new Color(((Number)Gident.redValue2.get()).intValue(), ((Number)Gident.greenValue2.get()).intValue(), ((Number)Gident.blueValue2.get()).intValue()).getRGB());
                float f = x2 / 2.0f;
                Color color = Color.WHITE;
                Intrinsics.checkExpressionValueIsNotNull(color, "Color.WHITE");
                Fonts.font35.drawCenteredString("Session Info", f, 2.0f, color.getRGB(), false);
                if (((Boolean)this.outline.get()).booleanValue()) {
                    double d = x2;
                    double d2 = y2;
                    int n = new Color(0, 0, 0, 30).getRGB();
                    Color color2 = RenderUtils.getGradientOffset(new Color(((Number)Gident.redValue.get()).intValue(), ((Number)Gident.greenValue.get()).intValue(), ((Number)Gident.blueValue.get()).intValue()), new Color(((Number)Gident.redValue2.get()).intValue(), ((Number)Gident.greenValue2.get()).intValue(), ((Number)Gident.blueValue2.get()).intValue()), 100.0);
                    Intrinsics.checkExpressionValueIsNotNull(color2, "RenderUtils.getGradientO\u2026                        )");
                    RenderUtils.rectangleBordered(0.0, 0.0, d, d2, 0.55, n, color2.getRGB());
                }
                int n = fontRenderer.getFontHeight() + 6;
                Color color3 = Color.WHITE;
                Intrinsics.checkExpressionValueIsNotNull(color3, "Color.WHITE");
                fontRenderer.drawString("Play Time:", 2, n, color3.getRGB());
                String string7 = String.valueOf(time);
                float f2 = 120.0f - (float)fontRenderer.getStringWidth(String.valueOf(time));
                float f3 = (float)fontRenderer.getFontHeight() + 6.0f;
                Color color4 = Color.WHITE;
                Intrinsics.checkExpressionValueIsNotNull(color4, "Color.WHITE");
                fontRenderer.drawString(string7, f2, f3, color4.getRGB());
                int n2 = fontRenderer.getFontHeight() * 2 + 8;
                Color color5 = Color.WHITE;
                Intrinsics.checkExpressionValueIsNotNull(color5, "Color.WHITE");
                fontRenderer.drawString("Games Won", 2, n2, color5.getRGB());
                String string8 = String.valueOf(Recorder.INSTANCE.getWin());
                float f4 = 120.0f - (float)fontRenderer.getStringWidth(String.valueOf(Recorder.INSTANCE.getWin()));
                float f5 = (float)(fontRenderer.getFontHeight() * 2) + 8.0f;
                Color color6 = Color.WHITE;
                Intrinsics.checkExpressionValueIsNotNull(color6, "Color.WHITE");
                fontRenderer.drawString(string8, f4, f5, color6.getRGB());
                int n3 = fontRenderer.getFontHeight() * 3 + 10;
                Color color7 = Color.WHITE;
                Intrinsics.checkExpressionValueIsNotNull(color7, "Color.WHITE");
                fontRenderer.drawString("Players Killed", 2, n3, color7.getRGB());
                String string9 = String.valueOf(Recorder.INSTANCE.getKillCounts());
                float f6 = 120.0f - (float)fontRenderer.getStringWidth(String.valueOf(Recorder.INSTANCE.getKillCounts()));
                float f7 = (float)(fontRenderer.getFontHeight() * 3) + 10.0f;
                Color color8 = Color.WHITE;
                Intrinsics.checkExpressionValueIsNotNull(color8, "Color.WHITE");
                fontRenderer.drawString(string9, f6, f7, color8.getRGB());
                int n4 = fontRenderer.getFontHeight() * 4 + 12;
                Color color9 = Color.WHITE;
                Intrinsics.checkExpressionValueIsNotNull(color9, "Color.WHITE");
                fontRenderer.drawString("Banned", 2, n4, color9.getRGB());
                float f8 = 120.0f - (float)fontRenderer.getStringWidth("0");
                float f9 = (float)(fontRenderer.getFontHeight() * 4) + 12.0f;
                Color color10 = Color.WHITE;
                Intrinsics.checkExpressionValueIsNotNull(color10, "Color.WHITE");
                fontRenderer.drawString("0", f8, f9, color10.getRGB());
                break;
            }
            case "tenacity": {
                float x = (float)this.getX();
                float y = (float)this.getY();
                float height = this.linesLeft.size() * (Fonts.font35.getFontHeight() + 6) + 24;
                float width = 140.0f;
                Module module = LiquidBounce.INSTANCE.getModuleManager().getModule(HUD.class);
                if (module == null) {
                    throw new TypeCastException("null cannot be cast to non-null type net.ccbluex.liquidbounce.features.module.modules.render.HUD");
                }
                HUD hudMod = (HUD)module;
                switch ((String)this.colorMode.get()) {
                    case "Sync": {
                        Color[] colors = new Color[]{ClickGUI.generateColor(), ClickGUI.generateColor()};
                        this.gradientColor1 = RenderUtils.interpolateColorsBackAndForth(15, 0, colors[0], colors[1], (Boolean)hudMod.getHueInterpolation().get());
                        this.gradientColor2 = RenderUtils.interpolateColorsBackAndForth(15, 90, colors[0], colors[1], (Boolean)hudMod.getHueInterpolation().get());
                        this.gradientColor3 = RenderUtils.interpolateColorsBackAndForth(15, 180, colors[0], colors[1], (Boolean)hudMod.getHueInterpolation().get());
                        this.gradientColor4 = RenderUtils.interpolateColorsBackAndForth(15, 270, colors[0], colors[1], (Boolean)hudMod.getHueInterpolation().get());
                        break;
                    }
                    case "Tenacity": {
                        this.gradientColor1 = RenderUtils.interpolateColorsBackAndForth(15, 0, this.getClientColor(), this.getAlternateClientColor(), (Boolean)hudMod.getHueInterpolation().get());
                        this.gradientColor2 = RenderUtils.interpolateColorsBackAndForth(15, 90, this.getClientColor(), this.getAlternateClientColor(), (Boolean)hudMod.getHueInterpolation().get());
                        this.gradientColor3 = RenderUtils.interpolateColorsBackAndForth(15, 180, this.getClientColor(), this.getAlternateClientColor(), (Boolean)hudMod.getHueInterpolation().get());
                        this.gradientColor4 = RenderUtils.interpolateColorsBackAndForth(15, 270, this.getClientColor(), this.getAlternateClientColor(), (Boolean)hudMod.getHueInterpolation().get());
                        break;
                    }
                    case "Gradient": {
                        this.gradientColor1 = RenderUtils.interpolateColorsBackAndForth(15, 0, ClickGUI.generateColor(), ClickGUI.generateColor(), (Boolean)hudMod.getHueInterpolation().get());
                        this.gradientColor2 = RenderUtils.interpolateColorsBackAndForth(15, 90, ClickGUI.generateColor(), ClickGUI.generateColor(), (Boolean)hudMod.getHueInterpolation().get());
                        this.gradientColor3 = RenderUtils.interpolateColorsBackAndForth(15, 180, ClickGUI.generateColor(), ClickGUI.generateColor(), (Boolean)hudMod.getHueInterpolation().get());
                        this.gradientColor4 = RenderUtils.interpolateColorsBackAndForth(15, 270, ClickGUI.generateColor(), ClickGUI.generateColor(), (Boolean)hudMod.getHueInterpolation().get());
                        break;
                    }
                    case "Analogous": {
                        int val = Intrinsics.areEqual((String)this.degree.get(), "30") ? 0 : 1;
                        Color analogous = RenderUtils.getAnalogousColor(ClickGUI.generateColor())[val];
                        this.gradientColor1 = RenderUtils.interpolateColorsBackAndForth(15, 0, ClickGUI.generateColor(), analogous, (Boolean)hudMod.getHueInterpolation().get());
                        this.gradientColor2 = RenderUtils.interpolateColorsBackAndForth(15, 90, ClickGUI.generateColor(), analogous, (Boolean)hudMod.getHueInterpolation().get());
                        this.gradientColor3 = RenderUtils.interpolateColorsBackAndForth(15, 180, ClickGUI.generateColor(), analogous, (Boolean)hudMod.getHueInterpolation().get());
                        this.gradientColor4 = RenderUtils.interpolateColorsBackAndForth(15, 270, ClickGUI.generateColor(), analogous, (Boolean)hudMod.getHueInterpolation().get());
                        break;
                    }
                    case "Modern": {
                        RoundedUtil.drawRoundOutline(x, y, width, height, 6.0f, 0.5f, new Color(10, 10, 10, 80), new Color(-2));
                        break;
                    }
                }
                boolean outlinedRadar = Intrinsics.areEqual((String)this.colorMode.get(), "Modern") ^ true;
                DrRenderUtils.setAlphaLimit(0.0f);
                if (outlinedRadar) {
                    if (((Boolean)this.blur.getValue()).booleanValue()) {
                        BlurBuffer.blurRoundArea(x, y, width, height, 6);
                    }
                    RoundedUtil.drawGradientRound(x, y, width, height, 6.0f, DrRenderUtils.applyOpacity(this.gradientColor4, 0.85f), this.gradientColor1, this.gradientColor3, this.gradientColor2);
                    double d = x - 1.0f;
                    double d3 = y + (float)15;
                    double d4 = width + (float)2;
                    Color color = DrRenderUtils.applyOpacity(Color.BLACK, 0.2f);
                    Intrinsics.checkExpressionValueIsNotNull(color, "DrRenderUtils.applyOpaci\u2026                        )");
                    int n = color.getRGB();
                    Color color11 = DrRenderUtils.applyOpacity(Color.BLACK, 0.0f);
                    Intrinsics.checkExpressionValueIsNotNull(color11, "DrRenderUtils.applyOpacity(Color.BLACK, 0f)");
                    DrRenderUtils.drawGradientRect2(d, d3, d4, 5.0, n, color11.getRGB());
                } else {
                    double d = x + 1.0f;
                    double d5 = y + (float)15;
                    double d6 = width - (float)2;
                    Color color = DrRenderUtils.applyOpacity(Color.BLACK, 0.2f);
                    Intrinsics.checkExpressionValueIsNotNull(color, "DrRenderUtils.applyOpaci\u2026                        )");
                    int n = color.getRGB();
                    Color color12 = DrRenderUtils.applyOpacity(Color.BLACK, 0.0f);
                    Intrinsics.checkExpressionValueIsNotNull(color12, "DrRenderUtils.applyOpacity(Color.BLACK, 0f)");
                    DrRenderUtils.drawGradientRect2(d, d5, d6, 5.0, n, color12.getRGB());
                }
                Fonts.font40.drawCenteredString("Statistics", (float)((double)(x + width / (float)2)), (float)((double)(y + (float)(Intrinsics.areEqual((String)this.colorMode.get(), "Modern") ? 3 : 2))), -1);
                int val = 0;
                int analogous = ((Collection)this.linesLeft).size();
                while (val < analogous) {
                    void i;
                    void offset = i * (Fonts.font35.getFontHeight() + 6);
                    Fonts.font35.drawString(this.linesLeft.get((int)i), x + (float)5, y + (float)offset + (i == false ? 23.5f : 25.0f), -1);
                    ++i;
                }
                int[] playTime = this.getPlayTime();
                this.playtimeWidth = (float)DrRenderUtils.animate(20.5 + (double)(playTime[1] > 0 ? 20 : 0) + (double)(playTime[0] > 0 ? 14 : 0), this.playtimeWidth, 0.008);
                float playtimeX = x + width - (this.playtimeWidth + (float)5);
                if (((Boolean)this.animatedPlaytime.get()).booleanValue()) {
                    this.drawAnimatedPlaytime(playtimeX, y);
                } else {
                    String playtimeString = String.valueOf(playTime[0]) + "h " + playTime[1] + "m " + playTime[2] + "s";
                    Fonts.font35.drawString(playtimeString, playtimeX + this.playtimeWidth - (float)Fonts.font35.getStringWidth(playtimeString), y + (float)24, -1);
                }
                List<String> linesRight = CollectionsKt.listOf(String.valueOf(Recorder.INSTANCE.getTotalPlayed()), String.valueOf(Recorder.INSTANCE.getKillCounts()));
                int n = 0;
                int n5 = ((Collection)linesRight).size();
                while (n < n5) {
                    void i;
                    void offset = (i + true) * (Fonts.font35.getFontHeight() + 6);
                    Fonts.font35.drawString(linesRight.get((int)i), x + width - (float)(Fonts.font35.getStringWidth(linesRight.get((int)i)) + 5), y + (float)offset + (float)25, -1);
                    ++i;
                }
                break;
            }
        }
        return new Border(-2.0f, -2.0f, 150.0f, 150.0f);
    }

    public SessionInfo(double x, double y, float scale, @NotNull Side side) {
        Intrinsics.checkParameterIsNotNull(side, "side");
        super(x, y, scale, side);
        this.modeValue = new ListValue("Mode", new String[]{"Normal", "Tenacity"}, "Tenacity");
        this.blur = new BoolValue("Blur", false);
        this.Shadow = new BoolValue("Normal-Shadow", true);
        this.radiusValue = new FloatValue("Normal-Radius", 0.0f, 0.0f, 10.0f);
        this.bgredValue = new IntegerValue("Normal-Bg-R", 0, 0, 255);
        this.bggreenValue = new IntegerValue("Normal-Bg-G", 0, 0, 255);
        this.bgblueValue = new IntegerValue("Normal-Bg-B", 0, 0, 255);
        this.bgalphaValue = new IntegerValue("Normal-Bg-Alpha", 0, 0, 255);
        this.outline = new BoolValue("Normal-Outline", false);
        this.startTime = System.currentTimeMillis();
        this.endTime = -1L;
        this.linesLeft = CollectionsKt.listOf("Play time", "Games played", "Kills");
        this.animatedPlaytime = new BoolValue("Tenacity-Animated counter", true);
        this.colorMode = new ListValue("Tenacity-Color", new String[]{"Sync", "Analogous", "Tenacity", "Gradient", "Modern"}, "Tenacity");
        this.degree = new ListValue("Tenacity-Degree", new String[]{"30", "-30"}, "-30");
        this.playtimeWidth = 20.5f;
        this.gradientColor1 = Color.WHITE;
        this.gradientColor2 = Color.WHITE;
        this.gradientColor3 = Color.WHITE;
        this.gradientColor4 = Color.WHITE;
        IFontRenderer iFontRenderer = Fonts.font30;
        Intrinsics.checkExpressionValueIsNotNull(iFontRenderer, "Fonts.font30");
        this.fontValue = new FontValue("Font", iFontRenderer);
    }

    public /* synthetic */ SessionInfo(double d, double d2, float f, Side side, int n, DefaultConstructorMarker defaultConstructorMarker) {
        if ((n & 1) != 0) {
            d = 15.0;
        }
        if ((n & 2) != 0) {
            d2 = 10.0;
        }
        if ((n & 4) != 0) {
            f = 1.0f;
        }
        if ((n & 8) != 0) {
            side = new Side(Side.Horizontal.LEFT, Side.Vertical.UP);
        }
        this(d, d2, f, side);
    }

    public SessionInfo() {
        this(0.0, 0.0, 0.0f, null, 15, null);
    }
}

