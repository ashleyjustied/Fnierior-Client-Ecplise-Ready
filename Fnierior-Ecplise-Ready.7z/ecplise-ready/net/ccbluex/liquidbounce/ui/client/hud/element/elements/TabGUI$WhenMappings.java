/*
 * Decompiled with CFR 0.152.
 */
package net.ccbluex.liquidbounce.ui.client.hud.element.elements;

import kotlin.Metadata;
import net.ccbluex.liquidbounce.ui.client.hud.element.elements.TabGUI;

@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=3)
public final class TabGUI$WhenMappings {
    public static final /* synthetic */ int[] $EnumSwitchMapping$0;

    static {
        $EnumSwitchMapping$0 = new int[TabGUI.Action.values().length];
        TabGUI$WhenMappings.$EnumSwitchMapping$0[TabGUI.Action.UP.ordinal()] = 1;
        TabGUI$WhenMappings.$EnumSwitchMapping$0[TabGUI.Action.DOWN.ordinal()] = 2;
        TabGUI$WhenMappings.$EnumSwitchMapping$0[TabGUI.Action.LEFT.ordinal()] = 3;
        TabGUI$WhenMappings.$EnumSwitchMapping$0[TabGUI.Action.RIGHT.ordinal()] = 4;
        TabGUI$WhenMappings.$EnumSwitchMapping$0[TabGUI.Action.TOGGLE.ordinal()] = 5;
    }
}

