/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.entity.player.EntityPlayer
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package net.ccbluex.liquidbounce.ui.client.hud.element.elements;

import java.awt.Color;
import java.text.SimpleDateFormat;
import java.util.Date;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntityLivingBase;
import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntityPlayerSP;
import net.ccbluex.liquidbounce.api.minecraft.client.gui.IFontRenderer;
import net.ccbluex.liquidbounce.features.module.modules.combat.KillAura;
import net.ccbluex.liquidbounce.ui.client.hud.element.Border;
import net.ccbluex.liquidbounce.ui.client.hud.element.Element;
import net.ccbluex.liquidbounce.ui.client.hud.element.ElementInfo;
import net.ccbluex.liquidbounce.ui.client.hud.element.elements.InfosUtils.Recorder;
import net.ccbluex.liquidbounce.ui.font.Fonts;
import net.ccbluex.liquidbounce.utils.EntityUtils;
import net.ccbluex.liquidbounce.utils.MinecraftInstance;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import net.ccbluex.liquidbounce.value.BoolValue;
import net.ccbluex.liquidbounce.value.FontValue;
import net.ccbluex.liquidbounce.value.IntegerValue;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@ElementInfo(name="GameInfo2")
@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u0000P\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0006\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B#\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\u0002\u0010\u0007J\u0006\u0010(\u001a\u00020\u0003J\b\u0010)\u001a\u00020*H\u0016R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001c\u0010\u000e\u001a\u0004\u0018\u00010\u000fX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0010\u0010\u0011\"\u0004\b\u0012\u0010\u0013R\u000e\u0010\u0014\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0016X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u001eX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001c\u0010\u001f\u001a\u0004\u0018\u00010 X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b!\u0010\"\"\u0004\b#\u0010$R\u000e\u0010%\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010'\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006+"}, d2={"Lnet/ccbluex/liquidbounce/ui/client/hud/element/elements/GameInfo2;", "Lnet/ccbluex/liquidbounce/ui/client/hud/element/Element;", "x", "", "y", "scale", "", "(DDF)V", "DATE_FORMAT", "Ljava/text/SimpleDateFormat;", "GameInfoRows", "", "alpha", "Lnet/ccbluex/liquidbounce/value/IntegerValue;", "aura", "Lnet/ccbluex/liquidbounce/features/module/modules/combat/KillAura;", "getAura", "()Lnet/ccbluex/liquidbounce/features/module/modules/combat/KillAura;", "setAura", "(Lnet/ccbluex/liquidbounce/features/module/modules/combat/KillAura;)V", "blueValue", "fontValue", "Lnet/ccbluex/liquidbounce/value/FontValue;", "greenValue", "ralpha", "rblueValue", "redValue", "rgreenValue", "rredValue", "shadowValue", "Lnet/ccbluex/liquidbounce/value/BoolValue;", "target", "Lnet/ccbluex/liquidbounce/api/minecraft/client/entity/IEntityLivingBase;", "getTarget", "()Lnet/ccbluex/liquidbounce/api/minecraft/client/entity/IEntityLivingBase;", "setTarget", "(Lnet/ccbluex/liquidbounce/api/minecraft/client/entity/IEntityLivingBase;)V", "textblueValue", "textgreenValue", "textredValue", "calculateBPS", "drawElement", "Lnet/ccbluex/liquidbounce/ui/client/hud/element/Border;", "Fnierior"})
public final class GameInfo2
extends Element {
    private final IntegerValue redValue;
    private final IntegerValue greenValue;
    private final IntegerValue blueValue;
    private final IntegerValue alpha;
    private final IntegerValue rredValue;
    private final IntegerValue rgreenValue;
    private final IntegerValue rblueValue;
    private final IntegerValue ralpha;
    private final IntegerValue textredValue;
    private final IntegerValue textgreenValue;
    private final IntegerValue textblueValue;
    private final BoolValue shadowValue;
    private final FontValue fontValue;
    private int GameInfoRows;
    private final SimpleDateFormat DATE_FORMAT;
    @Nullable
    private KillAura aura;
    @Nullable
    private IEntityLivingBase target;

    @Nullable
    public final KillAura getAura() {
        return this.aura;
    }

    public final void setAura(@Nullable KillAura killAura) {
        this.aura = killAura;
    }

    @Nullable
    public final IEntityLivingBase getTarget() {
        return this.target;
    }

    public final void setTarget(@Nullable IEntityLivingBase iEntityLivingBase) {
        this.target = iEntityLivingBase;
    }

    @Override
    @NotNull
    public Border drawElement() {
        IFontRenderer icon = Fonts.genshin;
        Color color = Color.WHITE;
        Intrinsics.checkExpressionValueIsNotNull(color, "Color.WHITE");
        int color2 = color.getRGB();
        int fontHeight = Fonts.font40.getFontHeight();
        IFontRenderer fontRenderer = (IFontRenderer)this.fontValue.get();
        if (((Boolean)this.shadowValue.get()).booleanValue()) {
            RenderUtils.drawShadowWithCustomAlpha(0.0f, 10.5f, 150.0f, 70.0f, 200.0f);
        }
        RenderUtils.drawRect(0.0f, (float)this.GameInfoRows * 18.0f + 20.0f, 150.0f, 80.0f, new Color(((Number)this.redValue.get()).intValue(), ((Number)this.greenValue.get()).intValue(), ((Number)this.blueValue.get()).intValue(), ((Number)this.alpha.get()).intValue()).getRGB());
        icon.drawString("c", 3.0f, 2.5f + (float)fontHeight + 6.0f, color2);
        icon.drawString("m", 3.0f, 15.9f + (float)fontHeight + 6.0f, color2);
        icon.drawString("f", 3.0f, 28.5f + (float)fontHeight + 6.0f, color2);
        icon.drawString("a", 3.0f, 39.5f + (float)fontHeight + 6.0f, color2);
        icon.drawString("x", 3.0f, 52.0f + (float)fontHeight + 6.0f, color2);
        Fonts.font40.drawStringWithShadow("Game Info", (int)(5.0f + (float)icon.getStringWidth("u")), (int)((float)this.GameInfoRows * 18.0f + (float)16), new Color(((Number)this.textredValue.get()).intValue(), ((Number)this.textgreenValue.get()).intValue(), ((Number)this.textblueValue.get()).intValue(), 255).getRGB());
        Fonts.font35.drawStringWithShadow("Ping:" + String.valueOf(EntityUtils.INSTANCE.getPing((EntityPlayer)MinecraftInstance.mc2.field_71439_g)), (int)(5.0f + (float)icon.getStringWidth("b")), (int)((float)this.GameInfoRows * 18.0f + (float)30), new Color(((Number)this.textredValue.get()).intValue(), ((Number)this.textgreenValue.get()).intValue(), ((Number)this.textblueValue.get()).intValue(), 255).getRGB());
        Fonts.font35.drawStringWithShadow("FPS: " + Minecraft.func_175610_ah(), (int)(5.0f + (float)icon.getStringWidth("e")), (int)((float)this.GameInfoRows * 18.0f + (float)43), new Color(((Number)this.textredValue.get()).intValue(), ((Number)this.textgreenValue.get()).intValue(), ((Number)this.textblueValue.get()).intValue(), 255).getRGB());
        Fonts.font35.drawStringWithShadow("Kills: " + Recorder.INSTANCE.getKillCounts(), (int)(5.0f + (float)icon.getStringWidth("G")), (int)((float)this.GameInfoRows * 18.0f + (float)54), new Color(((Number)this.textredValue.get()).intValue(), ((Number)this.textgreenValue.get()).intValue(), ((Number)this.textblueValue.get()).intValue(), 255).getRGB());
        Fonts.font35.drawStringWithShadow("Played Time: " + this.DATE_FORMAT.format(new Date(System.currentTimeMillis() - Recorder.INSTANCE.getStartTime() - 28800000L)), (int)(5.0f + (float)icon.getStringWidth("G")), (int)((float)this.GameInfoRows * 18.0f + (float)66), new Color(((Number)this.textredValue.get()).intValue(), ((Number)this.textgreenValue.get()).intValue(), ((Number)this.textblueValue.get()).intValue(), 255).getRGB());
        Fonts.font35.drawStringWithShadow("Grim Banned/Staff Banned: " + Recorder.INSTANCE.getBan() + "/" + Recorder.INSTANCE.getStaffban(), (int)(5.0f + (float)icon.getStringWidth("G")), (int)((float)this.GameInfoRows * 18.0f + (float)54), new Color(((Number)this.textredValue.get()).intValue(), ((Number)this.textgreenValue.get()).intValue(), ((Number)this.textblueValue.get()).intValue(), 255).getRGB());
        return new Border(0.0f, (float)this.GameInfoRows * 18.0f + 12.0f, 150.0f, 80.0f);
    }

    public final double calculateBPS() {
        if (MinecraftInstance.mc.getThePlayer() != null) {
            IEntityPlayerSP iEntityPlayerSP = MinecraftInstance.mc.getThePlayer();
            if (iEntityPlayerSP == null) {
                Intrinsics.throwNpe();
            }
            double d = iEntityPlayerSP.getPosX();
            IEntityPlayerSP iEntityPlayerSP2 = MinecraftInstance.mc.getThePlayer();
            if (iEntityPlayerSP2 == null) {
                Intrinsics.throwNpe();
            }
            double d2 = d - iEntityPlayerSP2.getPrevPosX();
            IEntityPlayerSP iEntityPlayerSP3 = MinecraftInstance.mc.getThePlayer();
            if (iEntityPlayerSP3 == null) {
                Intrinsics.throwNpe();
            }
            double d3 = iEntityPlayerSP3.getPosZ();
            IEntityPlayerSP iEntityPlayerSP4 = MinecraftInstance.mc.getThePlayer();
            if (iEntityPlayerSP4 == null) {
                Intrinsics.throwNpe();
            }
            double bps = Math.hypot(d2, d3 - iEntityPlayerSP4.getPrevPosZ()) * (double)MinecraftInstance.mc.getTimer().getTimerSpeed() * (double)20;
            return (double)Math.round(bps * 100.0) / 100.0;
        }
        return 0.0;
    }

    public GameInfo2(double x, double y, float scale) {
        super(x, y, scale, null, 8, null);
        this.redValue = new IntegerValue("BackgroundRed", 0, 0, 255);
        this.greenValue = new IntegerValue("BackgroundGreen", 0, 0, 255);
        this.blueValue = new IntegerValue("BackgroundBlue", 0, 0, 255);
        this.alpha = new IntegerValue("BackgroundAlpha", 155, 0, 255);
        this.rredValue = new IntegerValue("RectRed", 0, 0, 255);
        this.rgreenValue = new IntegerValue("RectGreen", 0, 0, 255);
        this.rblueValue = new IntegerValue("RectBlue", 0, 0, 255);
        this.ralpha = new IntegerValue("RectAlpha", 192, 0, 255);
        this.textredValue = new IntegerValue("TextRed", 255, 0, 255);
        this.textgreenValue = new IntegerValue("TextGreen", 244, 0, 255);
        this.textblueValue = new IntegerValue("TextBlue", 255, 0, 255);
        this.shadowValue = new BoolValue("Shadow", true);
        IFontRenderer iFontRenderer = Fonts.font35;
        Intrinsics.checkExpressionValueIsNotNull(iFontRenderer, "Fonts.font35");
        this.fontValue = new FontValue("Font", iFontRenderer);
        this.DATE_FORMAT = new SimpleDateFormat("HH:mm:ss");
        KillAura killAura = this.aura = (KillAura)LiquidBounce.INSTANCE.getModuleManager().getModule(KillAura.class);
        if (killAura == null) {
            Intrinsics.throwNpe();
        }
        this.target = killAura.getTarget();
    }

    public /* synthetic */ GameInfo2(double d, double d2, float f, int n, DefaultConstructorMarker defaultConstructorMarker) {
        if ((n & 1) != 0) {
            d = 5.0;
        }
        if ((n & 2) != 0) {
            d2 = 87.0;
        }
        if ((n & 4) != 0) {
            f = 1.0f;
        }
        this(d, d2, f);
    }

    public GameInfo2() {
        this(0.0, 0.0, 0.0f, 7, null);
    }
}

