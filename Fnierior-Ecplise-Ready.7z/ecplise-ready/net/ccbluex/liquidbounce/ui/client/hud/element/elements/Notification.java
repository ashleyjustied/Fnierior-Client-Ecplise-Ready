/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.NotNull
 *  org.lwjgl.opengl.GL11
 */
package net.ccbluex.liquidbounce.ui.client.hud.element.elements;

import java.awt.Color;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.api.minecraft.client.gui.IFontRenderer;
import net.ccbluex.liquidbounce.ui.client.hud.element.elements.FadeState;
import net.ccbluex.liquidbounce.ui.client.hud.element.elements.Notification$WhenMappings;
import net.ccbluex.liquidbounce.ui.client.hud.element.elements.NotifyType;
import net.ccbluex.liquidbounce.ui.cnfont.FontLoaders;
import net.ccbluex.liquidbounce.ui.font.Fonts;
import net.ccbluex.liquidbounce.utils.render.EaseUtils;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.opengl.GL11;

@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u0000@\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010\t\n\u0002\b\r\n\u0002\u0018\u0002\n\u0002\b\u0018\n\u0002\u0010\u0007\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0005\u0018\u00002\u00020\u0001B1\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\b\b\u0002\u0010\u0007\u001a\u00020\b\u0012\b\b\u0002\u0010\t\u001a\u00020\b\u00a2\u0006\u0002\u0010\nJ&\u0010:\u001a\u00020;2\u0006\u0010<\u001a\u00020\b2\u0006\u0010=\u001a\u0002052\u0006\u0010>\u001a\u0002052\u0006\u0010?\u001a\u000205R\u0011\u0010\t\u001a\u00020\b\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u001a\u0010\r\u001a\u00020\u000eX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u000f\u0010\u0010\"\u0004\b\u0011\u0010\u0012R\u001a\u0010\u0013\u001a\u00020\u000eX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0014\u0010\u0010\"\u0004\b\u0015\u0010\u0012R\u0011\u0010\u0004\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R\u001a\u0010\u0018\u001a\u00020\u000eX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0019\u0010\u0010\"\u0004\b\u001a\u0010\u0012R\u001a\u0010\u001b\u001a\u00020\u001cX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u001d\u0010\u001e\"\u0004\b\u001f\u0010 R\u0014\u0010!\u001a\u00020\bX\u0086D\u00a2\u0006\b\n\u0000\u001a\u0004\b\"\u0010\fR\u001a\u0010#\u001a\u00020\bX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b$\u0010\f\"\u0004\b%\u0010&R\u001a\u0010'\u001a\u00020\bX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b(\u0010\f\"\u0004\b)\u0010&R\u0010\u0010*\u001a\u0004\u0018\u00010\u0003X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001a\u0010+\u001a\u00020\bX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b,\u0010\f\"\u0004\b-\u0010&R\u0011\u0010\u0007\u001a\u00020\b\u00a2\u0006\b\n\u0000\u001a\u0004\b.\u0010\fR\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b/\u0010\u0017R\u0011\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b0\u00101R\u0011\u00102\u001a\u00020\b\u00a2\u0006\b\n\u0000\u001a\u0004\b3\u0010\fR\u001a\u00104\u001a\u000205X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b6\u00107\"\u0004\b8\u00109\u00a8\u0006@"}, d2={"Lnet/ccbluex/liquidbounce/ui/client/hud/element/elements/Notification;", "", "title", "", "content", "type", "Lnet/ccbluex/liquidbounce/ui/client/hud/element/elements/NotifyType;", "time", "", "animeTime", "(Ljava/lang/String;Ljava/lang/String;Lnet/ccbluex/liquidbounce/ui/client/hud/element/elements/NotifyType;II)V", "getAnimeTime", "()I", "animeXTime", "", "getAnimeXTime", "()J", "setAnimeXTime", "(J)V", "animeYTime", "getAnimeYTime", "setAnimeYTime", "getContent", "()Ljava/lang/String;", "displayTime", "getDisplayTime", "setDisplayTime", "fadeState", "Lnet/ccbluex/liquidbounce/ui/client/hud/element/elements/FadeState;", "getFadeState", "()Lnet/ccbluex/liquidbounce/ui/client/hud/element/elements/FadeState;", "setFadeState", "(Lnet/ccbluex/liquidbounce/ui/client/hud/element/elements/FadeState;)V", "height", "getHeight", "n2", "getN2", "setN2", "(I)V", "nowY", "getNowY", "setNowY", "s", "textLength", "getTextLength", "setTextLength", "getTime", "getTitle", "getType", "()Lnet/ccbluex/liquidbounce/ui/client/hud/element/elements/NotifyType;", "width", "getWidth", "x", "", "getX", "()F", "setX", "(F)V", "drawNotification", "", "index", "blurRadius", "y", "scale", "Fnierior"})
public final class Notification {
    private String s;
    private int n2;
    private int textLength;
    private final int width;
    private final int height = 30;
    @NotNull
    private FadeState fadeState;
    private int nowY;
    private long displayTime;
    private long animeXTime;
    private float x;
    private long animeYTime;
    @NotNull
    private final String title;
    @NotNull
    private final String content;
    @NotNull
    private final NotifyType type;
    private final int time;
    private final int animeTime;

    public final int getN2() {
        return this.n2;
    }

    public final void setN2(int n) {
        this.n2 = n;
    }

    public final int getTextLength() {
        return this.textLength;
    }

    public final void setTextLength(int n) {
        this.textLength = n;
    }

    public final int getWidth() {
        return this.width;
    }

    public final int getHeight() {
        return this.height;
    }

    @NotNull
    public final FadeState getFadeState() {
        return this.fadeState;
    }

    public final void setFadeState(@NotNull FadeState fadeState) {
        Intrinsics.checkParameterIsNotNull((Object)fadeState, "<set-?>");
        this.fadeState = fadeState;
    }

    public final int getNowY() {
        return this.nowY;
    }

    public final void setNowY(int n) {
        this.nowY = n;
    }

    public final long getDisplayTime() {
        return this.displayTime;
    }

    public final void setDisplayTime(long l) {
        this.displayTime = l;
    }

    public final long getAnimeXTime() {
        return this.animeXTime;
    }

    public final void setAnimeXTime(long l) {
        this.animeXTime = l;
    }

    public final float getX() {
        return this.x;
    }

    public final void setX(float f) {
        this.x = f;
    }

    public final long getAnimeYTime() {
        return this.animeYTime;
    }

    public final void setAnimeYTime(long l) {
        this.animeYTime = l;
    }

    public final boolean drawNotification(int index, float blurRadius, float y, float scale) {
        Color white;
        int n2;
        int n;
        String value;
        IFontRenderer com40;
        double pct;
        int realY = -(index + 1) * (this.height + 2);
        long nowTime = System.currentTimeMillis();
        double transY = this.nowY;
        if (this.nowY != realY) {
            pct = (double)(nowTime - this.animeYTime) / (double)this.animeTime;
            if (pct > 1.0) {
                this.nowY = realY;
                pct = 1.0;
            } else {
                pct = EaseUtils.easeOutQuart(pct);
            }
            GL11.glTranslated((double)0.0, (double)((double)(realY - this.nowY) * pct), (double)0.0);
        } else {
            this.animeYTime = nowTime;
        }
        GL11.glTranslated((double)1.0, (double)this.nowY, (double)0.0);
        pct = (double)(nowTime - this.animeXTime) / (double)this.animeTime;
        switch (Notification$WhenMappings.$EnumSwitchMapping$0[this.fadeState.ordinal()]) {
            case 1: {
                if (pct > 1.0) {
                    this.fadeState = FadeState.STAY;
                    this.animeXTime = nowTime;
                    pct = 1.0;
                }
                pct = EaseUtils.easeOutQuart(pct);
                transY += (double)(realY - this.nowY) * pct;
                break;
            }
            case 2: {
                pct = 1.0;
                if (nowTime - this.animeXTime <= (long)this.time) break;
                this.fadeState = FadeState.OUT;
                this.animeXTime = nowTime;
                break;
            }
            case 3: {
                if (pct > 1.0) {
                    this.fadeState = FadeState.END;
                    this.animeXTime = nowTime;
                    pct = 2.0;
                }
                pct = 1.0 - EaseUtils.easeInQuart(pct);
                break;
            }
            case 4: {
                return true;
            }
        }
        double transX = (double)this.width - (double)this.width * pct - (double)this.width;
        GL11.glTranslated((double)((double)this.width - (double)this.width * pct), (double)0.0, (double)0.0);
        GL11.glTranslatef((float)(-((float)this.width)), (float)0.0f, (float)0.0f);
        if (this.type == NotifyType.SUCCESS) {
            this.s = "SUCCESS";
        } else if (this.type == NotifyType.ERROR) {
            this.s = "ERROR";
        } else if (this.type == NotifyType.WARNING) {
            this.s = "WARNING";
        } else if (this.type == NotifyType.INFO) {
            this.s = "INFO";
        }
        int width2 = 137;
        int height2 = 35;
        if (Intrinsics.areEqual(this.s, "INFO")) {
            GL11.glScaled((double)pct, (double)pct, (double)pct);
            GL11.glTranslatef((float)(-((float)width2) / (float)2), (float)(-((float)height2) / (float)2), (float)0.0f);
            RenderUtils.drawImage(LiquidBounce.INSTANCE.getWrapper().getClassProvider().createResourceLocation("langya/notification/bg.png"), 0, 0, (int)((float)width2), (int)((float)height2));
            IFontRenderer iFontRenderer = Fonts.com40;
            Intrinsics.checkExpressionValueIsNotNull(iFontRenderer, "Fonts.com40");
            com40 = iFontRenderer;
            value = this.content;
            n = 15;
            n2 = 15;
            Color color = Color.WHITE;
            Intrinsics.checkExpressionValueIsNotNull(color, "Color.WHITE");
            white = color;
            Intrinsics.checkExpressionValueIsNotNull(white, "Color.WHITE");
            com40.drawString(value, n, n2, white.getRGB());
        }
        if (Intrinsics.areEqual(this.s, "WARNING")) {
            GL11.glScaled((double)pct, (double)pct, (double)pct);
            GL11.glTranslatef((float)(-((float)width2) / (float)2), (float)(-((float)height2) / (float)2), (float)0.0f);
            RenderUtils.drawImage(LiquidBounce.INSTANCE.getWrapper().getClassProvider().createResourceLocation("langya/notification/bg.png"), 0, 0, (int)((float)width2), (int)((float)height2));
            IFontRenderer iFontRenderer = Fonts.com40;
            Intrinsics.checkExpressionValueIsNotNull(iFontRenderer, "Fonts.com40");
            com40 = iFontRenderer;
            value = this.content;
            n = 15;
            n2 = 15;
            Color color = Color.WHITE;
            Intrinsics.checkExpressionValueIsNotNull(color, "Color.WHITE");
            white = color;
            Intrinsics.checkExpressionValueIsNotNull(white, "Color.WHITE");
            com40.drawString(value, n, n2, white.getRGB());
        }
        if (Intrinsics.areEqual(this.s, "SUCCESS")) {
            GL11.glScaled((double)pct, (double)pct, (double)pct);
            GL11.glTranslatef((float)(-((float)width2) / (float)2), (float)(-((float)height2) / (float)2), (float)0.0f);
            RenderUtils.drawImage(LiquidBounce.INSTANCE.getWrapper().getClassProvider().createResourceLocation("langya/notification/bg.png"), 0, 0, (int)((float)width2), (int)((float)height2));
            IFontRenderer iFontRenderer = Fonts.com40;
            Intrinsics.checkExpressionValueIsNotNull(iFontRenderer, "Fonts.com40");
            com40 = iFontRenderer;
            value = this.content;
            n = 15;
            n2 = 15;
            Color color = Color.WHITE;
            Intrinsics.checkExpressionValueIsNotNull(color, "Color.WHITE");
            white = color;
            Intrinsics.checkExpressionValueIsNotNull(white, "Color.WHITE");
            com40.drawString(value, n, n2, white.getRGB());
        }
        if (Intrinsics.areEqual(this.s, "ERROR")) {
            GL11.glScaled((double)pct, (double)pct, (double)pct);
            GL11.glTranslatef((float)(-((float)width2) / (float)2), (float)(-((float)height2) / (float)2), (float)0.0f);
            RenderUtils.drawImage(LiquidBounce.INSTANCE.getWrapper().getClassProvider().createResourceLocation("langya/notification/bg.png"), 0, 0, (int)((float)width2), (int)((float)height2));
            IFontRenderer iFontRenderer = Fonts.com40;
            Intrinsics.checkExpressionValueIsNotNull(iFontRenderer, "Fonts.com40");
            com40 = iFontRenderer;
            value = this.content;
            n = 15;
            n2 = 15;
            Color color = Color.WHITE;
            Intrinsics.checkExpressionValueIsNotNull(color, "Color.WHITE");
            white = color;
            Intrinsics.checkExpressionValueIsNotNull(white, "Color.WHITE");
            com40.drawString(value, n, n2, white.getRGB());
        }
        return false;
    }

    @NotNull
    public final String getTitle() {
        return this.title;
    }

    @NotNull
    public final String getContent() {
        return this.content;
    }

    @NotNull
    public final NotifyType getType() {
        return this.type;
    }

    public final int getTime() {
        return this.time;
    }

    public final int getAnimeTime() {
        return this.animeTime;
    }

    public Notification(@NotNull String title, @NotNull String content, @NotNull NotifyType type, int time, int animeTime) {
        Intrinsics.checkParameterIsNotNull(title, "title");
        Intrinsics.checkParameterIsNotNull(content, "content");
        Intrinsics.checkParameterIsNotNull((Object)type, "type");
        this.title = title;
        this.content = content;
        this.type = type;
        this.time = time;
        this.animeTime = animeTime;
        this.n2 = FontLoaders.G16.getStringWidth(this.content);
        this.textLength = Math.max(this.n2, 0);
        this.width = this.textLength + 12;
        this.height = 30;
        this.fadeState = FadeState.IN;
        this.nowY = -this.height;
        this.displayTime = System.currentTimeMillis();
        this.animeXTime = System.currentTimeMillis();
        this.animeYTime = System.currentTimeMillis();
    }

    public /* synthetic */ Notification(String string, String string2, NotifyType notifyType, int n, int n2, int n3, DefaultConstructorMarker defaultConstructorMarker) {
        if ((n3 & 8) != 0) {
            n = 1000;
        }
        if ((n3 & 0x10) != 0) {
            n2 = 350;
        }
        this(string, string2, notifyType, n, n2);
    }
}

