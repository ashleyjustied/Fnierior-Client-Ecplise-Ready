/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.GlStateManager
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package net.ccbluex.liquidbounce.ui.client.hud.element.elements;

import java.awt.Color;
import java.io.Closeable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import kotlin.Metadata;
import kotlin.TypeCastException;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.comparisons.ComparisonsKt;
import kotlin.io.CloseableKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import kotlin.text.StringsKt;
import me.utils.render.VisualUtils;
import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.api.minecraft.client.gui.IFontRenderer;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.modules.render.HUD;
import net.ccbluex.liquidbounce.ui.client.hud.element.Border;
import net.ccbluex.liquidbounce.ui.client.hud.element.Element;
import net.ccbluex.liquidbounce.ui.client.hud.element.ElementInfo;
import net.ccbluex.liquidbounce.ui.client.hud.element.Side;
import net.ccbluex.liquidbounce.ui.client.hud.element.elements.Arraylist2$WhenMappings;
import net.ccbluex.liquidbounce.ui.font.AWTFontRenderer;
import net.ccbluex.liquidbounce.ui.font.Fonts;
import net.ccbluex.liquidbounce.utils.Colors;
import net.ccbluex.liquidbounce.utils.MinecraftInstance;
import net.ccbluex.liquidbounce.utils.render.AnimationUtils;
import net.ccbluex.liquidbounce.utils.render.ColorUtils;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import net.ccbluex.liquidbounce.utils.render.shader.shaders.RainbowFontShader;
import net.ccbluex.liquidbounce.utils.render.shader.shaders.RainbowShader;
import net.ccbluex.liquidbounce.value.BoolValue;
import net.ccbluex.liquidbounce.value.FloatValue;
import net.ccbluex.liquidbounce.value.FontValue;
import net.ccbluex.liquidbounce.value.IntegerValue;
import net.ccbluex.liquidbounce.value.ListValue;
import net.minecraft.client.renderer.GlStateManager;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@ElementInfo(name="Arraylist2", single=true)
@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u0000b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0006\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0011\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B-\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0006\u0012\b\b\u0002\u0010\u0007\u001a\u00020\b\u00a2\u0006\u0002\u0010\tJ\n\u00109\u001a\u0004\u0018\u00010:H\u0016J\b\u0010;\u001a\u00020<H\u0016R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u000fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u000fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0019X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u000fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020\u0019X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010 \u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\"X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010#\u001a\b\u0012\u0004\u0012\u00020%0$X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020\u000fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010'\u001a\u00020\u000fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010(\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010*\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010+\u001a\u00020\u0019X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010,\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010-\u001a\u00020\u0019X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010.\u001a\u00020\u000fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010/\u001a\u00020\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u00100\u001a\u00020\u000fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u00101\u001a\u00020\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u00102\u001a\u00020\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u00103\u001a\u00020\u000fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u00104\u001a\u00020\u000fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u00105\u001a\u00020\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u00106\u001a\u000207X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u00108\u001a\u00020\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006="}, d2={"Lnet/ccbluex/liquidbounce/ui/client/hud/element/elements/Arraylist2;", "Lnet/ccbluex/liquidbounce/ui/client/hud/element/Element;", "x", "", "y", "scale", "", "side", "Lnet/ccbluex/liquidbounce/ui/client/hud/element/Side;", "(DDFLnet/ccbluex/liquidbounce/ui/client/hud/element/Side;)V", "Breakchange", "Lnet/ccbluex/liquidbounce/value/BoolValue;", "Rianbowb", "Lnet/ccbluex/liquidbounce/value/IntegerValue;", "RianbowbValue", "Lnet/ccbluex/liquidbounce/value/FloatValue;", "Rianbowg", "Rianbowr", "RianbowsValue", "RianbowspeedValue", "TwoRainbow", "backgroundColorAlphaValue", "backgroundColorBlueValue", "backgroundColorGreenValue", "backgroundColorModeValue", "Lnet/ccbluex/liquidbounce/value/ListValue;", "backgroundColorRedValue", "backgroundwidth", "brightnessValue", "colorBlueValue", "colorGreenValue", "colorModeValue", "colorRedValue", "fontValue", "Lnet/ccbluex/liquidbounce/value/FontValue;", "modules", "", "Lnet/ccbluex/liquidbounce/features/module/Module;", "rainbowX", "rainbowY", "rectColorBlueAlpha", "rectColorBlueValue", "rectColorGreenValue", "rectColorModeValue", "rectColorRedValue", "rectValue", "saturationValue", "shadow", "spaceValue", "tags", "tagsArrayColor", "textHeightValue", "textYValue", "upperCaseValue", "x2", "", "y2", "drawElement", "Lnet/ccbluex/liquidbounce/ui/client/hud/element/Border;", "updateElement", "", "Fnierior"})
public final class Arraylist2
extends Element {
    private final IntegerValue RianbowspeedValue;
    private final FloatValue RianbowbValue;
    private final FloatValue RianbowsValue;
    private final IntegerValue Rianbowr;
    private final IntegerValue Rianbowb;
    private final IntegerValue Rianbowg;
    private final FloatValue rainbowX;
    private final FloatValue rainbowY;
    private final ListValue colorModeValue;
    private final IntegerValue colorRedValue;
    private final IntegerValue colorGreenValue;
    private final IntegerValue colorBlueValue;
    private final FloatValue TwoRainbow;
    private final ListValue rectColorModeValue;
    private final IntegerValue rectColorRedValue;
    private final IntegerValue rectColorGreenValue;
    private final IntegerValue rectColorBlueValue;
    private final IntegerValue rectColorBlueAlpha;
    private final FloatValue saturationValue;
    private final FloatValue brightnessValue;
    private final BoolValue tags;
    private final BoolValue shadow;
    private final ListValue backgroundColorModeValue;
    private final IntegerValue backgroundColorRedValue;
    private final IntegerValue backgroundColorGreenValue;
    private final IntegerValue backgroundColorBlueValue;
    private final IntegerValue backgroundColorAlphaValue;
    private final IntegerValue backgroundwidth;
    private final ListValue rectValue;
    private final BoolValue upperCaseValue;
    private final FloatValue spaceValue;
    private final FloatValue textHeightValue;
    private final FloatValue textYValue;
    private final BoolValue tagsArrayColor;
    private final BoolValue Breakchange;
    private final FontValue fontValue;
    private int x2;
    private float y2;
    private List<? extends Module> modules;

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * WARNING - void declaration
     */
    @Override
    @Nullable
    public Border drawElement() {
        IFontRenderer fontRenderer = (IFontRenderer)this.fontValue.get();
        AWTFontRenderer.Companion.setAssumeNonVolatile(true);
        int delta = RenderUtils.deltaTime;
        for (Module module : LiquidBounce.INSTANCE.getModuleManager().getModules()) {
            String displayString;
            if (!module.getArray() || !module.getState() && module.getSlide() == 0.0f) continue;
            String string = (Boolean)this.tags.get() == false ? module.getName() : (displayString = (Boolean)this.tagsArrayColor.get() != false ? module.getColorlessTagName() : module.getTagName());
            if (((Boolean)this.upperCaseValue.get()).booleanValue()) {
                String string2 = displayString;
                boolean bl = false;
                String string3 = string2;
                if (string3 == null) {
                    throw new TypeCastException("null cannot be cast to non-null type java.lang.String");
                }
                String string4 = string3.toUpperCase();
                Intrinsics.checkExpressionValueIsNotNull(string4, "(this as java.lang.String).toUpperCase()");
                displayString = string4;
            }
            int width = fontRenderer.getStringWidth(displayString);
            if (module.getState()) {
                if (module.getSlide() < (float)width) {
                    module.setSlide(AnimationUtils.easeOut(module.getSlideStep(), width) * (float)width);
                    Module module2 = module;
                    module2.setSlideStep(module2.getSlideStep() + (float)delta / 4.0f);
                }
            } else if (module.getSlide() > 0.0f) {
                module.setSlide(AnimationUtils.easeOut(module.getSlideStep(), width) * (float)width);
                Module module3 = module;
                module3.setSlideStep(module3.getSlideStep() - (float)delta / 4.0f);
            }
            module.setSlide(RangesKt.coerceIn(module.getSlide(), 0.0f, (float)width));
            module.setSlideStep(RangesKt.coerceIn(module.getSlideStep(), 0.0f, (float)width));
        }
        int[] counter = new int[]{0};
        boolean cou = false;
        String colorMode = (String)this.colorModeValue.get();
        String rectColorMode = (String)this.rectColorModeValue.get();
        String backgroundColorMode = (String)this.backgroundColorModeValue.get();
        int customColor = new Color(((Number)this.colorRedValue.get()).intValue(), ((Number)this.colorGreenValue.get()).intValue(), ((Number)this.colorBlueValue.get()).intValue(), 1).getRGB();
        int rectCustomColor = new Color(((Number)this.rectColorRedValue.get()).intValue(), ((Number)this.rectColorGreenValue.get()).intValue(), ((Number)this.rectColorBlueValue.get()).intValue(), ((Number)this.rectColorBlueAlpha.get()).intValue()).getRGB();
        float space = ((Number)this.spaceValue.get()).floatValue();
        float textHeight = ((Number)this.textHeightValue.get()).floatValue();
        float textY = ((Number)this.textYValue.get()).floatValue();
        String rectMode = (String)this.rectValue.get();
        int backgroundCustomColor = new Color(((Number)this.backgroundColorRedValue.get()).intValue(), ((Number)this.backgroundColorGreenValue.get()).intValue(), ((Number)this.backgroundColorBlueValue.get()).intValue(), ((Number)this.backgroundColorAlphaValue.get()).intValue()).getRGB();
        int alpha = new Color(((Number)this.backgroundColorRedValue.get()).intValue(), ((Number)this.backgroundColorRedValue.get()).intValue(), ((Number)this.backgroundColorRedValue.get()).intValue(), 150).getRGB();
        boolean textShadow = (Boolean)this.shadow.get();
        float textSpacer = textHeight + space;
        float saturation = ((Number)this.saturationValue.get()).floatValue();
        float brightness = ((Number)this.brightnessValue.get()).floatValue();
        float Rsaturation = ((Number)this.RianbowbValue.get()).floatValue();
        float Rbrightness = ((Number)this.RianbowsValue.get()).floatValue();
        switch (Arraylist2$WhenMappings.$EnumSwitchMapping$0[this.getSide().getHorizontal().ordinal()]) {
            case 1: 
            case 2: {
                String string;
                String displayString;
                Module module;
                int index;
                int n;
                boolean bl;
                int n2;
                Iterable iterable = this.modules;
                boolean $i$f$forEachIndexed = false;
                int index$iv = 0;
                for (Object item$iv : iterable) {
                    Integer LiquidSlowly;
                    n2 = index$iv++;
                    bl = false;
                    if (n2 < 0) {
                        CollectionsKt.throwIndexOverflow();
                    }
                    n = n2;
                    Module module4 = (Module)item$iv;
                    index = n;
                    boolean bl2 = false;
                    displayString = (Boolean)this.tags.get() == false ? module.getName() : ((Boolean)this.tagsArrayColor.get() != false ? module.getColorlessTagName() : module.getTagName());
                    module.setBreakName((Boolean)this.Breakchange.get());
                    if (((Boolean)this.upperCaseValue.get()).booleanValue()) {
                        String string5 = displayString;
                        boolean bl3 = false;
                        String string6 = string5;
                        if (string6 == null) {
                            throw new TypeCastException("null cannot be cast to non-null type java.lang.String");
                        }
                        Intrinsics.checkExpressionValueIsNotNull(string6.toUpperCase(), "(this as java.lang.String).toUpperCase()");
                        displayString = string;
                    }
                    float xPos = -module.getSlide() - (float)2;
                    float yPos = (this.getSide().getVertical() == Side.Vertical.DOWN ? -textSpacer : textSpacer) * (float)(this.getSide().getVertical() == Side.Vertical.DOWN ? index + 1 : index);
                    Color color = Color.getHSBColor(module.getHue(), saturation, brightness);
                    Intrinsics.checkExpressionValueIsNotNull(color, "Color.getHSBColor(module\u2026, saturation, brightness)");
                    int moduleColor = color.getRGB();
                    Color color2 = ColorUtils.LiquidSlowly(System.nanoTime(), index * ((Number)this.RianbowspeedValue.get()).intValue(), Rsaturation, Rbrightness);
                    Integer n3 = LiquidSlowly = color2 != null ? Integer.valueOf(color2.getRGB()) : null;
                    if (n3 == null) {
                        Intrinsics.throwNpe();
                    }
                    int c = n3;
                    Color col = new Color(c);
                    int braibow = new Color(((Number)this.Rianbowr.get()).intValue(), col.getGreen() / 2 + ((Number)this.Rianbowb.get()).intValue(), col.getGreen() / 2 + ((Number)this.Rianbowb.get()).intValue() + ((Number)this.Rianbowg.get()).intValue()).getRGB();
                    boolean backgroundRectRainbow = StringsKt.equals(backgroundColorMode, "Rainbow", true);
                    float size = (float)this.modules.size() * 0.02f;
                    if (module.getState()) {
                        if (module.getHigt() < yPos) {
                            Module module5 = module;
                            module5.setHigt(module5.getHigt() + (size - Math.min(module.getHigt() * 0.002f, size - module.getHigt() * 1.0E-4f)) * (float)delta);
                            module.setHigt(Math.min(yPos, module.getHigt()));
                        } else {
                            Module module6 = module;
                            module6.setHigt(module6.getHigt() - (size - Math.min(module.getHigt() * 0.002f, size - module.getHigt() * 1.0E-4f)) * (float)delta);
                            module.setHigt(Math.max(module.getHigt(), yPos));
                        }
                    }
                    RainbowShader.Companion companion = RainbowShader.Companion;
                    float f = ((Number)this.rainbowX.get()).floatValue() == 0.0f ? 0.0f : 1.0f / ((Number)this.rainbowX.get()).floatValue();
                    float f2 = ((Number)this.rainbowY.get()).floatValue() == 0.0f ? 0.0f : 1.0f / ((Number)this.rainbowY.get()).floatValue();
                    float offset$iv = (float)(System.currentTimeMillis() % (long)10000) / 10000.0f;
                    boolean $i$f$begin = false;
                    RainbowShader instance$iv = RainbowShader.INSTANCE;
                    if (backgroundRectRainbow) {
                        void y$iv;
                        void x$iv;
                        instance$iv.setStrengthX((float)x$iv);
                        instance$iv.setStrengthY((float)y$iv);
                        instance$iv.setOffset(offset$iv);
                        instance$iv.startShader();
                    }
                    Closeable this_$iv = instance$iv;
                    boolean x$iv = false;
                    Throwable y$iv = null;
                    try {
                        Object it = (RainbowShader)this_$iv;
                        boolean bl4 = false;
                        RenderUtils.drawRect(xPos - (float)(StringsKt.equals(rectMode, "right", true) ? 5 : 2), module.getHigt(), StringsKt.equals(rectMode, "right", true) ? -3.0f : 0.0f, module.getHigt() + textHeight, backgroundRectRainbow ? -16777216 : (StringsKt.equals(backgroundColorMode, "Random", true) ? moduleColor : (StringsKt.equals(backgroundColorMode, "OtherRainbow", true) ? Colors.getRainbow(-2000, (int)(yPos * (float)8)) : (StringsKt.equals(backgroundColorMode, "ALLRainbow", true) ? ColorUtils.ALLColor(400000000L * (long)index).getRGB() : (StringsKt.equals(backgroundColorMode, "Bainbow", true) ? braibow : (StringsKt.equals(backgroundColorMode, "TwoRainbow", true) ? ColorUtils.TwoRainbow(400000000L * (long)index, ((Number)this.TwoRainbow.get()).floatValue()).getRGB() : (StringsKt.equals(backgroundColorMode, "OriginalRainbow", true) ? ColorUtils.originalrainbow(400000000L * (long)index).getRGB() : (StringsKt.equals(backgroundColorMode, "LRainbow", true) ? Colors.getRainbow(-2000, (int)(yPos * (float)8)) : backgroundCustomColor))))))));
                        it = Unit.INSTANCE;
                    }
                    catch (Throwable it) {
                        y$iv = it;
                        throw it;
                    }
                    finally {
                        CloseableKt.closeFinally(this_$iv, y$iv);
                    }
                    boolean rainbow = StringsKt.equals(colorMode, "Rainbow", true);
                    Module module7 = LiquidBounce.INSTANCE.getModuleManager().getModule(HUD.class);
                    if (module7 == null) {
                        throw new TypeCastException("null cannot be cast to non-null type net.ccbluex.liquidbounce.features.module.modules.render.HUD");
                    }
                    HUD hud = (HUD)module7;
                    Color color3 = VisualUtils.getGradientOffset(new Color(((Number)hud.getRedValue().get()).intValue(), ((Number)hud.getGreenValue().get()).intValue(), ((Number)hud.getBlueValue().get()).intValue(), 1), new Color(((Number)hud.getRedValue().get()).intValue(), ((Number)hud.getGreenValue().get()).intValue(), ((Number)hud.getBlueValue().get()).intValue(), 1), Math.abs((double)System.currentTimeMillis() / (double)814 + (double)(module.getHigt() / (float)fontRenderer.getFontHeight())) / (double)10);
                    Intrinsics.checkExpressionValueIsNotNull(color3, "VisualUtils.getGradientO\u2026                 ) / 10))");
                    int color32 = color3.getRGB();
                    float it = ((Number)this.rainbowX.get()).floatValue() == 0.0f ? 0.0f : 1.0f / ((Number)this.rainbowX.get()).floatValue();
                    float bl4 = ((Number)this.rainbowY.get()).floatValue() == 0.0f ? 0.0f : 1.0f / ((Number)this.rainbowY.get()).floatValue();
                    float offset$iv32422 = (float)(System.currentTimeMillis() % (long)10000) / 10000.0f;
                    boolean $i$f$begin2 = false;
                    if (rainbow) {
                        void y$iv232;
                        void x$iv2;
                        RainbowFontShader.INSTANCE.setStrengthX((float)x$iv2);
                        RainbowFontShader.INSTANCE.setStrengthY((float)y$iv232);
                        RainbowFontShader.INSTANCE.setOffset(offset$iv32422);
                        RainbowFontShader.INSTANCE.startShader();
                    }
                    Closeable x$iv2 = RainbowFontShader.INSTANCE;
                    boolean y$iv232 = false;
                    Throwable offset$iv32422 = null;
                    try {
                        RainbowFontShader it232 = (RainbowFontShader)x$iv2;
                        boolean bl5 = false;
                        int it232 = fontRenderer.drawString(displayString, xPos - (float)(StringsKt.equals(rectMode, "right", true) ? 3 : 0), module.getHigt() + textY, rainbow ? 0 : (StringsKt.equals(colorMode, "Random", true) ? moduleColor : (StringsKt.equals(colorMode, "OtherRainbow", true) ? Colors.getRainbow(-2000, (int)(yPos * (float)8)) : (StringsKt.equals(colorMode, "ALLRainbow", true) ? ColorUtils.ALLColor(400000000L * (long)index).getRGB() : (StringsKt.equals(colorMode, "Bainbow", true) ? braibow : (StringsKt.equals(colorMode, "TwoRainbow", true) ? ColorUtils.TwoRainbow(400000000L * (long)index, ((Number)this.TwoRainbow.get()).floatValue()).getRGB() : (StringsKt.equals(colorMode, "OriginalRainbow", true) ? ColorUtils.originalrainbow(400000000L * (long)index).getRGB() : (StringsKt.equals(colorMode, "LRainbow", true) ? Colors.getRainbow(-2000, (int)(yPos * (float)8)) : (StringsKt.equals(colorMode, "NovoRainbow", true) ? color32 : customColor)))))))), textShadow);
                    }
                    catch (Throwable it232) {
                        offset$iv32422 = it232;
                        throw it232;
                    }
                    finally {
                        CloseableKt.closeFinally(x$iv2, offset$iv32422);
                    }
                    if (StringsKt.equals(rectMode, "none", true)) continue;
                    boolean rectRainbow = StringsKt.equals(rectColorMode, "Rainbow", true);
                    RainbowShader.Companion y$iv232 = RainbowShader.Companion;
                    float offset$iv32422 = ((Number)this.rainbowX.get()).floatValue() == 0.0f ? 0.0f : 1.0f / ((Number)this.rainbowX.get()).floatValue();
                    float it232 = ((Number)this.rainbowY.get()).floatValue() == 0.0f ? 0.0f : 1.0f / ((Number)this.rainbowY.get()).floatValue();
                    float offset$iv2 = (float)(System.currentTimeMillis() % (long)10000) / 10000.0f;
                    boolean $i$f$begin3 = false;
                    RainbowShader instance$iv2 = RainbowShader.INSTANCE;
                    if (rectRainbow) {
                        void y$iv3;
                        void x$iv3;
                        instance$iv2.setStrengthX((float)x$iv3);
                        instance$iv2.setStrengthY((float)y$iv3);
                        instance$iv2.setOffset(offset$iv2);
                        instance$iv2.startShader();
                    }
                    Closeable this_$iv2 = instance$iv2;
                    boolean x$iv3 = false;
                    Throwable y$iv3 = null;
                    try {
                        Object it2 = (RainbowShader)this_$iv2;
                        boolean bl6 = false;
                        int rectColor = rectRainbow ? 0 : (StringsKt.equals(rectColorMode, "Random", true) ? moduleColor : (StringsKt.equals(rectColorMode, "OtherRainbow", true) ? Colors.getRainbow(-2000, (int)(yPos * (float)8)) : (StringsKt.equals(rectColorMode, "ALLRainbow", true) ? ColorUtils.ALLColor(400000000L * (long)index).getRGB() : (StringsKt.equals(rectColorMode, "Bainbow", true) ? braibow : (StringsKt.equals(rectColorMode, "TwoRainbow", true) ? ColorUtils.TwoRainbow(400000000L * (long)index, ((Number)this.TwoRainbow.get()).floatValue()).getRGB() : (StringsKt.equals(rectColorMode, "OriginalRainbow", true) ? ColorUtils.originalrainbow(400000000L * (long)index).getRGB() : (StringsKt.equals(rectColorMode, "LRainbow", true) ? Colors.getRainbow(-2000, (int)(yPos * (float)8)) : rectCustomColor)))))));
                        if (StringsKt.equals(rectMode, "left", true)) {
                            RenderUtils.drawRect(xPos - (float)3, module.getHigt(), xPos - (float)2, module.getHigt() + textHeight, rectColor);
                        } else if (StringsKt.equals(rectMode, "right", true)) {
                            RenderUtils.drawRect(-3.0f, module.getHigt(), 1.0f, module.getHigt() + textHeight, rectColor);
                        }
                        if (StringsKt.equals(rectMode, "outline", true)) {
                            RenderUtils.drawRect(xPos - 1.0f - ((Number)this.backgroundwidth.get()).floatValue(), module.getHigt(), xPos - 0.0f - ((Number)this.backgroundwidth.get()).floatValue(), module.getHigt() + textHeight + 0.5f, rectColor);
                            if (Intrinsics.areEqual(module, this.modules.get(0)) ^ true) {
                                String displayStrings;
                                String string7 = (Boolean)this.tags.get() == false ? this.modules.get(index - 1).getName() : (displayStrings = (Boolean)this.tagsArrayColor.get() != false ? this.modules.get(index - 1).getColorlessTagName() : this.modules.get(index - 1).getTagName());
                                if (((Boolean)this.upperCaseValue.get()).booleanValue()) {
                                    String string8 = displayStrings;
                                    boolean bl5 = false;
                                    String string9 = string8;
                                    if (string9 == null) {
                                        throw new TypeCastException("null cannot be cast to non-null type java.lang.String");
                                    }
                                    String string10 = string9.toUpperCase();
                                    Intrinsics.checkExpressionValueIsNotNull(string10, "(this as java.lang.String).toUpperCase()");
                                    displayStrings = string10;
                                }
                                RenderUtils.drawRect(xPos - 1.0f - ((Number)this.backgroundwidth.get()).floatValue() - (float)(fontRenderer.getStringWidth(displayStrings) - fontRenderer.getStringWidth(displayString)), module.getHigt(), xPos - 1.0f - ((Number)this.backgroundwidth.get()).floatValue(), module.getHigt() + 1.0f, rectColor);
                            }
                            if (Intrinsics.areEqual(module, this.modules.get(this.modules.size() - 1))) {
                                RenderUtils.drawRect(xPos - 1.0f - ((Number)this.backgroundwidth.get()).floatValue(), module.getHigt() + textHeight, 0.0f, module.getHigt() + textHeight + 1.0f, rectColor);
                            }
                        }
                        it2 = Unit.INSTANCE;
                    }
                    catch (Throwable it2) {
                        y$iv3 = it2;
                        throw it2;
                    }
                    finally {
                        CloseableKt.closeFinally(this_$iv2, y$iv3);
                    }
                }
                break;
            }
            case 3: {
                String string;
                String displayString;
                Module module;
                int index;
                int n;
                boolean bl;
                int n2;
                Iterable iterable = this.modules;
                boolean $i$f$forEachIndexed = false;
                int index$iv = 0;
                for (Object item$iv : iterable) {
                    Integer LiquidSlowly;
                    n2 = index$iv++;
                    bl = false;
                    if (n2 < 0) {
                        CollectionsKt.throwIndexOverflow();
                    }
                    n = n2;
                    module = (Module)item$iv;
                    index = n;
                    boolean bl8 = false;
                    String string11 = (Boolean)this.tags.get() == false ? module.getName() : (displayString = (Boolean)this.tagsArrayColor.get() != false ? module.getColorlessTagName() : module.getTagName());
                    if (((Boolean)this.upperCaseValue.get()).booleanValue()) {
                        String xPos = displayString;
                        boolean yPos = false;
                        String string12 = xPos;
                        if (string12 == null) {
                            throw new TypeCastException("null cannot be cast to non-null type java.lang.String");
                        }
                        Intrinsics.checkExpressionValueIsNotNull(string12.toUpperCase(), "(this as java.lang.String).toUpperCase()");
                        displayString = string;
                    }
                    int width = fontRenderer.getStringWidth(displayString);
                    float xPos = -((float)width - module.getSlide()) + (float)(StringsKt.equals(rectMode, "left", true) ? 5 : 2);
                    float yPos = (this.getSide().getVertical() == Side.Vertical.DOWN ? -textSpacer : textSpacer) * (float)(this.getSide().getVertical() == Side.Vertical.DOWN ? index + 1 : index);
                    Color color = Color.getHSBColor(module.getHue(), saturation, brightness);
                    Intrinsics.checkExpressionValueIsNotNull(color, "Color.getHSBColor(module\u2026, saturation, brightness)");
                    int moduleColor = color.getRGB();
                    Color color4 = ColorUtils.LiquidSlowly(System.nanoTime(), index * ((Number)this.RianbowspeedValue.get()).intValue(), Rsaturation, Rbrightness);
                    Integer n4 = LiquidSlowly = color4 != null ? Integer.valueOf(color4.getRGB()) : null;
                    if (n4 == null) {
                        Intrinsics.throwNpe();
                    }
                    int c = n4;
                    Color col = new Color(c);
                    int braibow = new Color(((Number)this.Rianbowr.get()).intValue(), col.getGreen() / 2 + ((Number)this.Rianbowb.get()).intValue(), col.getGreen() / 2 + ((Number)this.Rianbowb.get()).intValue() + ((Number)this.Rianbowg.get()).intValue()).getRGB();
                    boolean backgroundRectRainbow = StringsKt.equals(backgroundColorMode, "Rainbow", true);
                    float size = (float)this.modules.size() * 0.02f;
                    if (module.getState()) {
                        if (module.getHigt() < yPos) {
                            Module module8 = module;
                            module8.setHigt(module8.getHigt() + (size - Math.min(module.getHigt() * 0.002f, size - module.getHigt() * 1.0E-4f)) * (float)delta);
                            module.setHigt(Math.min(yPos, module.getHigt()));
                        } else {
                            Module module9 = module;
                            module9.setHigt(module9.getHigt() - (size - Math.min(module.getHigt() * 0.002f, size - module.getHigt() * 1.0E-4f)) * (float)delta);
                            module.setHigt(Math.max(module.getHigt(), yPos));
                        }
                    }
                    RainbowShader.Companion hud = RainbowShader.Companion;
                    float color32 = ((Number)this.rainbowX.get()).floatValue() == 0.0f ? 0.0f : 1.0f / ((Number)this.rainbowX.get()).floatValue();
                    float rectRainbow = ((Number)this.rainbowY.get()).floatValue() == 0.0f ? 0.0f : 1.0f / ((Number)this.rainbowY.get()).floatValue();
                    float offset$iv = (float)(System.currentTimeMillis() % (long)10000) / 10000.0f;
                    boolean $i$f$begin = false;
                    RainbowShader instance$iv = RainbowShader.INSTANCE;
                    if (backgroundRectRainbow) {
                        void y$iv332;
                        void x$iv232;
                        instance$iv.setStrengthX((float)x$iv232);
                        instance$iv.setStrengthY((float)y$iv332);
                        instance$iv.setOffset(offset$iv);
                        instance$iv.startShader();
                    }
                    Closeable this_$iv = instance$iv;
                    boolean x$iv232 = false;
                    Throwable y$iv332 = null;
                    try {
                        Object it = (RainbowShader)this_$iv;
                        boolean bl9 = false;
                        RenderUtils.drawRect(0.0f, module.getHigt(), xPos + (float)width + (float)(StringsKt.equals(rectMode, "right", true) ? 5 : 2), module.getHigt() + textHeight, backgroundRectRainbow ? 0 : (StringsKt.equals(backgroundColorMode, "Random", true) ? moduleColor : backgroundCustomColor));
                        it = Unit.INSTANCE;
                    }
                    catch (Throwable it) {
                        y$iv332 = it;
                        throw it;
                    }
                    finally {
                        CloseableKt.closeFinally(this_$iv, y$iv332);
                    }
                    boolean rainbow = StringsKt.equals(colorMode, "Rainbow", true);
                    float x$iv232 = ((Number)this.rainbowX.get()).floatValue() == 0.0f ? 0.0f : 1.0f / ((Number)this.rainbowX.get()).floatValue();
                    float y$iv332 = ((Number)this.rainbowY.get()).floatValue() == 0.0f ? 0.0f : 1.0f / ((Number)this.rainbowY.get()).floatValue();
                    float offset$iv4422 = (float)(System.currentTimeMillis() % (long)10000) / 10000.0f;
                    $i$f$begin = false;
                    if (rainbow) {
                        void y$iv432;
                        void x$iv;
                        RainbowFontShader.INSTANCE.setStrengthX((float)x$iv);
                        RainbowFontShader.INSTANCE.setStrengthY((float)y$iv432);
                        RainbowFontShader.INSTANCE.setOffset(offset$iv4422);
                        RainbowFontShader.INSTANCE.startShader();
                    }
                    Closeable x$iv = RainbowFontShader.INSTANCE;
                    boolean y$iv432 = false;
                    Throwable offset$iv4422 = null;
                    try {
                        RainbowFontShader it332 = (RainbowFontShader)x$iv;
                        boolean bl10 = false;
                        int it332 = fontRenderer.drawString(displayString, xPos, module.getHigt() + textY, rainbow ? 0 : (StringsKt.equals(colorMode, "Random", true) ? moduleColor : customColor), textShadow);
                    }
                    catch (Throwable it332) {
                        offset$iv4422 = it332;
                        throw it332;
                    }
                    finally {
                        CloseableKt.closeFinally(x$iv, offset$iv4422);
                    }
                    boolean rectColorRainbow = StringsKt.equals(rectColorMode, "Rainbow", true);
                    RainbowShader.Companion y$iv432 = RainbowShader.Companion;
                    float offset$iv4422 = ((Number)this.rainbowX.get()).floatValue() == 0.0f ? 0.0f : 1.0f / ((Number)this.rainbowX.get()).floatValue();
                    float it332 = ((Number)this.rainbowY.get()).floatValue() == 0.0f ? 0.0f : 1.0f / ((Number)this.rainbowY.get()).floatValue();
                    float offset$iv3 = (float)(System.currentTimeMillis() % (long)10000) / 10000.0f;
                    boolean $i$f$begin4 = false;
                    RainbowShader instance$iv3 = RainbowShader.INSTANCE;
                    if (rectColorRainbow) {
                        void y$iv;
                        void x$iv4;
                        instance$iv3.setStrengthX((float)x$iv4);
                        instance$iv3.setStrengthY((float)y$iv);
                        instance$iv3.setOffset(offset$iv3);
                        instance$iv3.startShader();
                    }
                    Closeable closeable = instance$iv3;
                    boolean bl6 = false;
                    Throwable throwable = null;
                    try {
                        RainbowShader it = (RainbowShader)closeable;
                        boolean bl12 = false;
                        if (!StringsKt.equals(rectMode, "none", true)) {
                            int rectColor = rectColorRainbow ? 0 : (StringsKt.equals(rectColorMode, "Random", true) ? moduleColor : rectCustomColor);
                            if (StringsKt.equals(rectMode, "left", true)) {
                                RenderUtils.drawRect(0.0f, module.getHigt() - 1.0f, 3.0f, module.getHigt() + textHeight, rectColor);
                            } else if (StringsKt.equals(rectMode, "right", true)) {
                                RenderUtils.drawRect(xPos + (float)width + (float)2, module.getHigt(), xPos + (float)width + (float)2 + (float)3, module.getHigt() + textHeight, rectColor);
                            }
                        }
                        Unit unit = Unit.INSTANCE;
                    }
                    catch (Throwable throwable2) {
                        throwable = throwable2;
                        throw throwable2;
                    }
                    finally {
                        CloseableKt.closeFinally(closeable, throwable);
                    }
                }
                break;
            }
        }
        if (MinecraftInstance.classProvider.isGuiHudDesigner(MinecraftInstance.mc.getCurrentScreen())) {
            this.x2 = Integer.MIN_VALUE;
            if (this.modules.isEmpty()) {
                return this.getSide().getHorizontal() == Side.Horizontal.LEFT ? new Border(0.0f, -1.0f, 20.0f, 20.0f) : new Border(0.0f, -1.0f, -20.0f, 20.0f);
            }
            for (Module module : this.modules) {
                switch (Arraylist2$WhenMappings.$EnumSwitchMapping$1[this.getSide().getHorizontal().ordinal()]) {
                    case 1: 
                    case 2: {
                        int xPos = -((int)module.getSlide()) - 2;
                        if (this.x2 != Integer.MIN_VALUE && xPos >= this.x2) break;
                        this.x2 = xPos;
                        break;
                    }
                    case 3: {
                        int xPos = (int)module.getSlide() + 14;
                        if (this.x2 != Integer.MIN_VALUE && xPos <= this.x2) break;
                        this.x2 = xPos;
                        break;
                    }
                }
            }
            this.y2 = (this.getSide().getVertical() == Side.Vertical.DOWN ? -textSpacer : textSpacer) * (float)this.modules.size();
            return new Border(0.0f, 0.0f, (float)this.x2 - 7.0f, this.y2 - (this.getSide().getVertical() == Side.Vertical.DOWN ? 1.0f : 0.0f));
        }
        AWTFontRenderer.Companion.setAssumeNonVolatile(false);
        GlStateManager.func_179117_G();
        return null;
    }

    /*
     * WARNING - void declaration
     */
    @Override
    public void updateElement() {
        void $this$sortedBy$iv;
        void $this$filterTo$iv$iv;
        Iterable $this$filter$iv;
        Iterable iterable = LiquidBounce.INSTANCE.getModuleManager().getModules();
        Arraylist2 arraylist2 = this;
        boolean $i$f$filter = false;
        void var3_4 = $this$filter$iv;
        Collection destination$iv$iv = new ArrayList();
        boolean $i$f$filterTo = false;
        for (Object element$iv$iv : $this$filterTo$iv$iv) {
            Module it = (Module)element$iv$iv;
            boolean bl = false;
            if (!(it.getArray() && it.getSlide() > 0.0f)) continue;
            destination$iv$iv.add(element$iv$iv);
        }
        List list = (List)destination$iv$iv;
        $this$filter$iv = list;
        boolean $i$f$sortedBy = false;
        var3_4 = $this$sortedBy$iv;
        boolean bl = false;
        Comparator comparator = new Comparator<T>(this){
            final /* synthetic */ Arraylist2 this$0;
            {
                this.this$0 = arraylist2;
            }

            public final int compare(T a, T b) {
                String string;
                String string2;
                String string3;
                boolean bl;
                IFontRenderer iFontRenderer;
                String string4;
                boolean bl2 = false;
                Module it = (Module)a;
                boolean bl3 = false;
                IFontRenderer iFontRenderer2 = (IFontRenderer)Arraylist2.access$getFontValue$p(this.this$0).get();
                if (((Boolean)Arraylist2.access$getUpperCaseValue$p(this.this$0).get()).booleanValue()) {
                    string4 = (Boolean)Arraylist2.access$getTags$p(this.this$0).get() == false ? it.getName() : ((Boolean)Arraylist2.access$getTagsArrayColor$p(this.this$0).get() != false ? it.getColorlessTagName() : it.getTagName());
                    iFontRenderer = iFontRenderer2;
                    bl = false;
                    String string5 = string4;
                    if (string5 == null) {
                        throw new TypeCastException("null cannot be cast to non-null type java.lang.String");
                    }
                    String string6 = string5.toUpperCase();
                    Intrinsics.checkExpressionValueIsNotNull(string6, "(this as java.lang.String).toUpperCase()");
                    string3 = string6;
                    iFontRenderer2 = iFontRenderer;
                    string2 = string3;
                } else {
                    string2 = (Boolean)Arraylist2.access$getTags$p(this.this$0).get() == false ? it.getName() : ((Boolean)Arraylist2.access$getTagsArrayColor$p(this.this$0).get() != false ? it.getColorlessTagName() : it.getTagName());
                }
                it = (Module)b;
                Comparable comparable = Integer.valueOf(-iFontRenderer2.getStringWidth(string2));
                bl3 = false;
                IFontRenderer iFontRenderer3 = (IFontRenderer)Arraylist2.access$getFontValue$p(this.this$0).get();
                if (((Boolean)Arraylist2.access$getUpperCaseValue$p(this.this$0).get()).booleanValue()) {
                    string4 = (Boolean)Arraylist2.access$getTags$p(this.this$0).get() == false ? it.getName() : ((Boolean)Arraylist2.access$getTagsArrayColor$p(this.this$0).get() != false ? it.getColorlessTagName() : it.getTagName());
                    iFontRenderer = iFontRenderer3;
                    bl = false;
                    String string7 = string4;
                    if (string7 == null) {
                        throw new TypeCastException("null cannot be cast to non-null type java.lang.String");
                    }
                    String string8 = string7.toUpperCase();
                    Intrinsics.checkExpressionValueIsNotNull(string8, "(this as java.lang.String).toUpperCase()");
                    string3 = string8;
                    iFontRenderer3 = iFontRenderer;
                    string = string3;
                } else {
                    string = (Boolean)Arraylist2.access$getTags$p(this.this$0).get() == false ? it.getName() : ((Boolean)Arraylist2.access$getTagsArrayColor$p(this.this$0).get() != false ? it.getColorlessTagName() : it.getTagName());
                }
                Integer n = -iFontRenderer3.getStringWidth(string);
                return ComparisonsKt.compareValues(comparable, (Comparable)n);
            }
        };
        list = CollectionsKt.sortedWith(var3_4, comparator);
        arraylist2.modules = list;
    }

    public Arraylist2(double x, double y, float scale, @NotNull Side side) {
        Intrinsics.checkParameterIsNotNull(side, "side");
        super(x, y, scale, side);
        this.RianbowspeedValue = new IntegerValue("BRainbowSpeed", 90, 1, 90);
        this.RianbowbValue = new FloatValue("BRainbow-Saturation", 1.0f, 0.0f, 1.0f);
        this.RianbowsValue = new FloatValue("BRainbow-Brightness", 1.0f, 0.0f, 1.0f);
        this.Rianbowr = new IntegerValue("BRainbow-R", 0, 0, 255);
        this.Rianbowb = new IntegerValue("BRainbow-B", 50, 0, 64);
        this.Rianbowg = new IntegerValue("BRainbow-G", 50, 0, 64);
        this.rainbowX = new FloatValue("Rainbow-X", -1000.0f, -2000.0f, 2000.0f);
        this.rainbowY = new FloatValue("Rainbow-Y", -1000.0f, -2000.0f, 2000.0f);
        this.colorModeValue = new ListValue("Text-Color", new String[]{"Custom", "Random", "Rainbow", "OtherRainbow", "ALLRainbow", "Bainbow", "TwoRainbow", "OriginalRainbow", "LRainbow"}, "Custom");
        this.colorRedValue = new IntegerValue("Text-R", 255, 0, 255);
        this.colorGreenValue = new IntegerValue("Text-G", 255, 0, 255);
        this.colorBlueValue = new IntegerValue("Text-B", 255, 0, 255);
        this.TwoRainbow = new FloatValue("TwoRainbow", 1.0f, 0.0f, 1.0f);
        this.rectColorModeValue = new ListValue("Rect-Color", new String[]{"Custom", "Random", "Rainbow", "OtherRainbow", "ALLRainbow", "Bainbow", "TwoRainbow", "OriginalRainbow", "LRainbow"}, "Rainbow");
        this.rectColorRedValue = new IntegerValue("Rect-R", 255, 0, 255);
        this.rectColorGreenValue = new IntegerValue("Rect-G", 255, 0, 255);
        this.rectColorBlueValue = new IntegerValue("Rect-B", 255, 0, 255);
        this.rectColorBlueAlpha = new IntegerValue("Rect-Alpha", 255, 0, 255);
        this.saturationValue = new FloatValue("Random-Saturation", 0.9f, 0.0f, 1.0f);
        this.brightnessValue = new FloatValue("Random-Brightness", 1.0f, 0.0f, 1.0f);
        this.tags = new BoolValue("Tags", true);
        this.shadow = new BoolValue("ShadowText", true);
        this.backgroundColorModeValue = new ListValue("Background-Color", new String[]{"Custom", "Random", "Rainbow", "OtherRainbow", "ALLRainbow", "Bainbow", "TwoRainbow", "OriginalRainbow", "LRainbow", "NovoRainbow"}, "Custom");
        this.backgroundColorRedValue = new IntegerValue("Background-R", 0, 0, 255);
        this.backgroundColorGreenValue = new IntegerValue("Background-G", 0, 0, 255);
        this.backgroundColorBlueValue = new IntegerValue("Background-B", 0, 0, 255);
        this.backgroundColorAlphaValue = new IntegerValue("Background-Alpha", 0, 0, 255);
        this.backgroundwidth = new IntegerValue("BackGroundWidth", 2, 0, 14);
        this.rectValue = new ListValue("Rect", new String[]{"None", "Left", "Right", "Outline"}, "None");
        this.upperCaseValue = new BoolValue("UpperCase", false);
        this.spaceValue = new FloatValue("Space", 0.0f, 0.0f, 5.0f);
        this.textHeightValue = new FloatValue("TextHeight", 11.0f, 1.0f, 20.0f);
        this.textYValue = new FloatValue("TextY", 1.0f, 0.0f, 20.0f);
        this.tagsArrayColor = new BoolValue("TagsArrayColor", false);
        this.Breakchange = new BoolValue("NameBreak", false);
        IFontRenderer iFontRenderer = Fonts.font40;
        Intrinsics.checkExpressionValueIsNotNull(iFontRenderer, "Fonts.font40");
        this.fontValue = new FontValue("Font", iFontRenderer);
        this.modules = CollectionsKt.emptyList();
    }

    public /* synthetic */ Arraylist2(double d, double d2, float f, Side side, int n, DefaultConstructorMarker defaultConstructorMarker) {
        if ((n & 1) != 0) {
            d = 1.0;
        }
        if ((n & 2) != 0) {
            d2 = 2.0;
        }
        if ((n & 4) != 0) {
            f = 1.0f;
        }
        if ((n & 8) != 0) {
            side = new Side(Side.Horizontal.RIGHT, Side.Vertical.UP);
        }
        this(d, d2, f, side);
    }

    public Arraylist2() {
        this(0.0, 0.0, 0.0f, null, 15, null);
    }

    public static final /* synthetic */ FontValue access$getFontValue$p(Arraylist2 $this) {
        return $this.fontValue;
    }

    public static final /* synthetic */ BoolValue access$getUpperCaseValue$p(Arraylist2 $this) {
        return $this.upperCaseValue;
    }

    public static final /* synthetic */ BoolValue access$getTags$p(Arraylist2 $this) {
        return $this.tags;
    }

    public static final /* synthetic */ BoolValue access$getTagsArrayColor$p(Arraylist2 $this) {
        return $this.tagsArrayColor;
    }
}

