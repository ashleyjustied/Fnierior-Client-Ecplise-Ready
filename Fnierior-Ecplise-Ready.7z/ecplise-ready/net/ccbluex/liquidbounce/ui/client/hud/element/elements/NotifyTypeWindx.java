/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.NotNull
 */
package net.ccbluex.liquidbounce.ui.client.hud.element.elements;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\u000e\n\u0002\b\n\b\u0086\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u000f\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004R\u001a\u0010\u0002\u001a\u00020\u0003X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0005\u0010\u0006\"\u0004\b\u0007\u0010\bj\u0002\b\tj\u0002\b\nj\u0002\b\u000bj\u0002\b\f\u00a8\u0006\r"}, d2={"Lnet/ccbluex/liquidbounce/ui/client/hud/element/elements/NotifyTypeWindx;", "", "icon", "", "(Ljava/lang/String;ILjava/lang/String;)V", "getIcon", "()Ljava/lang/String;", "setIcon", "(Ljava/lang/String;)V", "SUCCESS", "ERROR", "WARNING", "INFO", "Fnierior"})
public final class NotifyTypeWindx
extends Enum<NotifyTypeWindx> {
    public static final /* enum */ NotifyTypeWindx SUCCESS;
    public static final /* enum */ NotifyTypeWindx ERROR;
    public static final /* enum */ NotifyTypeWindx WARNING;
    public static final /* enum */ NotifyTypeWindx INFO;
    private static final /* synthetic */ NotifyTypeWindx[] $VALUES;
    @NotNull
    private String icon;

    static {
        NotifyTypeWindx[] notifyTypeWindxArray = new NotifyTypeWindx[4];
        NotifyTypeWindx[] notifyTypeWindxArray2 = notifyTypeWindxArray;
        notifyTypeWindxArray[0] = SUCCESS = new NotifyTypeWindx("/assets/minecraft/langya/notification/success.png");
        notifyTypeWindxArray[1] = ERROR = new NotifyTypeWindx("/assets/minecraft/langya/notification/new/error.png");
        notifyTypeWindxArray[2] = WARNING = new NotifyTypeWindx("/assets/minecraft/langya/notification/new/warning.png");
        notifyTypeWindxArray[3] = INFO = new NotifyTypeWindx("/assets/minecraft/langya/notification/new/info.png");
        $VALUES = notifyTypeWindxArray;
    }

    @NotNull
    public final String getIcon() {
        return this.icon;
    }

    public final void setIcon(@NotNull String string) {
        Intrinsics.checkParameterIsNotNull(string, "<set-?>");
        this.icon = string;
    }

    private NotifyTypeWindx(String icon) {
        this.icon = icon;
    }

    public static NotifyTypeWindx[] values() {
        return (NotifyTypeWindx[])$VALUES.clone();
    }

    public static NotifyTypeWindx valueOf(String string) {
        return Enum.valueOf(NotifyTypeWindx.class, string);
    }
}

