/*
 * Decompiled with CFR 0.152.
 */
package net.ccbluex.liquidbounce.ui.client.hud.element.elements;

import kotlin.Metadata;
import net.ccbluex.liquidbounce.ui.client.hud.element.Side;

@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=3)
public final class Arraylist2$WhenMappings {
    public static final /* synthetic */ int[] $EnumSwitchMapping$0;
    public static final /* synthetic */ int[] $EnumSwitchMapping$1;

    static {
        $EnumSwitchMapping$0 = new int[Side.Horizontal.values().length];
        Arraylist2$WhenMappings.$EnumSwitchMapping$0[Side.Horizontal.RIGHT.ordinal()] = 1;
        Arraylist2$WhenMappings.$EnumSwitchMapping$0[Side.Horizontal.MIDDLE.ordinal()] = 2;
        Arraylist2$WhenMappings.$EnumSwitchMapping$0[Side.Horizontal.LEFT.ordinal()] = 3;
        $EnumSwitchMapping$1 = new int[Side.Horizontal.values().length];
        Arraylist2$WhenMappings.$EnumSwitchMapping$1[Side.Horizontal.RIGHT.ordinal()] = 1;
        Arraylist2$WhenMappings.$EnumSwitchMapping$1[Side.Horizontal.MIDDLE.ordinal()] = 2;
        Arraylist2$WhenMappings.$EnumSwitchMapping$1[Side.Horizontal.LEFT.ordinal()] = 3;
    }
}

