/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.Gui
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.OpenGlHelper
 *  net.minecraft.entity.player.EntityPlayer
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 *  org.lwjgl.opengl.GL11
 */
package net.ccbluex.liquidbounce.ui.client.hud.element.elements;

import java.awt.Color;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.TypeCastException;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.ranges.IntProgression;
import kotlin.ranges.IntRange;
import kotlin.ranges.RangesKt;
import kotlin.text.StringsKt;
import me.utils.render.RoundedUtil;
import me.utils.render.ShadowUtils;
import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntityLivingBase;
import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntityPlayerSP;
import net.ccbluex.liquidbounce.api.minecraft.client.gui.IFontRenderer;
import net.ccbluex.liquidbounce.api.minecraft.client.network.INetworkPlayerInfo;
import net.ccbluex.liquidbounce.api.minecraft.client.render.texture.ITextureManager;
import net.ccbluex.liquidbounce.api.minecraft.util.IResourceLocation;
import net.ccbluex.liquidbounce.features.module.modules.color.Gident;
import net.ccbluex.liquidbounce.ui.client.hud.element.Border;
import net.ccbluex.liquidbounce.ui.client.hud.element.Element;
import net.ccbluex.liquidbounce.ui.client.hud.element.ElementInfo;
import net.ccbluex.liquidbounce.ui.client.hud.element.Side;
import net.ccbluex.liquidbounce.ui.client.hud.element.elements.Particle;
import net.ccbluex.liquidbounce.ui.client.hud.element.elements.ShapeType;
import net.ccbluex.liquidbounce.ui.client.hud.element.elements.Target2;
import net.ccbluex.liquidbounce.ui.font.Fonts;
import net.ccbluex.liquidbounce.utils.EntityUtils;
import net.ccbluex.liquidbounce.utils.MinecraftInstance;
import net.ccbluex.liquidbounce.utils.PlayerUtils;
import net.ccbluex.liquidbounce.utils.TenacityRectUtil;
import net.ccbluex.liquidbounce.utils.extensions.PlayerExtensionKt;
import net.ccbluex.liquidbounce.utils.misc.RandomUtils;
import net.ccbluex.liquidbounce.utils.render.BlendUtils;
import net.ccbluex.liquidbounce.utils.render.ColorUtil;
import net.ccbluex.liquidbounce.utils.render.ColorUtils;
import net.ccbluex.liquidbounce.utils.render.EaseUtils;
import net.ccbluex.liquidbounce.utils.render.Palette;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import net.ccbluex.liquidbounce.utils.render.Stencil;
import net.ccbluex.liquidbounce.value.BoolValue;
import net.ccbluex.liquidbounce.value.FloatValue;
import net.ccbluex.liquidbounce.value.FontValue;
import net.ccbluex.liquidbounce.value.IntegerValue;
import net.ccbluex.liquidbounce.value.ListValue;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.entity.player.EntityPlayer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.opengl.GL11;

@ElementInfo(name="TargetHUD")
@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u0000\u0098\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0010\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0015\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u000e\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0017\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b \n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\u0018\u0010g\u001a\u00020h2\u0006\u0010i\u001a\u00020P2\u0006\u0010j\u001a\u00020\u0004H\u0002J\u0018\u0010k\u001a\u00020h2\u0006\u0010i\u001a\u00020P2\u0006\u0010l\u001a\u00020\u0004H\u0002J\n\u0010m\u001a\u0004\u0018\u00010nH\u0016J\u0018\u0010o\u001a\u00020h2\u0006\u0010i\u001a\u00020P2\u0006\u0010j\u001a\u00020\u0004H\u0002JX\u0010p\u001a\u00020h2\u0006\u0010q\u001a\u00020r2\u0006\u0010s\u001a\u00020\u00042\u0006\u0010t\u001a\u00020\u00042\u0006\u0010u\u001a\u00020\u00042\u0006\u0010v\u001a\u00020w2\u0006\u0010x\u001a\u00020w2\u0006\u0010y\u001a\u00020\u00042\u0006\u0010z\u001a\u00020\u00042\u0006\u0010{\u001a\u00020\u00042\b\b\u0002\u0010|\u001a\u00020\u0004J<\u0010p\u001a\u00020h2\u0006\u0010q\u001a\u00020r2\b\b\u0002\u0010s\u001a\u00020w2\b\b\u0002\u0010t\u001a\u00020w2\u0006\u0010v\u001a\u00020w2\u0006\u0010x\u001a\u00020w2\b\b\u0002\u0010|\u001a\u00020\u0004J8\u0010}\u001a\u00020h2\u0006\u0010q\u001a\u00020r2\u0006\u0010s\u001a\u00020w2\u0006\u0010t\u001a\u00020w2\u0006\u0010v\u001a\u00020w2\u0006\u0010x\u001a\u00020w2\u0006\u0010|\u001a\u00020\u0004H\u0002J\u0018\u0010~\u001a\u00020h2\u0006\u0010i\u001a\u00020P2\u0006\u0010l\u001a\u00020\u0004H\u0002J\u0018\u0010\u007f\u001a\u00020h2\u0006\u0010i\u001a\u00020P2\u0006\u0010l\u001a\u00020\u0004H\u0002J\u0019\u0010\u0080\u0001\u001a\u00020h2\u0006\u0010i\u001a\u00020P2\u0006\u0010j\u001a\u00020\u0004H\u0002J\u001a\u0010\u0081\u0001\u001a\u00020h2\u0007\u0010\u0082\u0001\u001a\u00020P2\u0006\u0010l\u001a\u00020\u0004H\u0002J\u0019\u0010\u0083\u0001\u001a\u00020h2\u0006\u0010i\u001a\u00020P2\u0006\u0010l\u001a\u00020\u0004H\u0002J\u0019\u0010\u0084\u0001\u001a\u00020h2\u0006\u0010i\u001a\u00020P2\u0006\u0010l\u001a\u00020\u0004H\u0002J*\u0010\u0085\u0001\u001a\u00020h2\u0006\u0010q\u001a\u00020r2\u0006\u0010v\u001a\u00020w2\u0006\u0010x\u001a\u00020w2\u0007\u0010\u0086\u0001\u001a\u00020\u0004H\u0002J\u0019\u0010\u0087\u0001\u001a\u00020h2\u0006\u0010i\u001a\u00020P2\u0006\u0010l\u001a\u00020\u0004H\u0002J\u0019\u0010\u0088\u0001\u001a\u00020h2\u0006\u0010i\u001a\u00020P2\u0006\u0010l\u001a\u00020\u0004H\u0002J\u0019\u0010\u0089\u0001\u001a\u00020h2\u0006\u0010i\u001a\u00020P2\u0006\u0010l\u001a\u00020\u0004H\u0002J\u0019\u0010\u008a\u0001\u001a\u00020h2\u0006\u0010i\u001a\u00020P2\u0006\u0010l\u001a\u00020\u0004H\u0002J\u0019\u0010\u008b\u0001\u001a\u00020h2\u0006\u0010i\u001a\u00020P2\u0006\u0010l\u001a\u00020\u0004H\u0002J\u0019\u0010\u008c\u0001\u001a\u00020h2\u0006\u0010i\u001a\u00020P2\u0006\u0010l\u001a\u00020\u0004H\u0002J\u0019\u0010\u008d\u0001\u001a\u00020h2\u0006\u0010i\u001a\u00020P2\u0006\u0010l\u001a\u00020\u0004H\u0002J\u0019\u0010\u008e\u0001\u001a\u00020h2\u0006\u0010i\u001a\u00020P2\u0006\u0010l\u001a\u00020\u0004H\u0002J\u0010\u0010\u008f\u0001\u001a\u00020\u000f2\u0007\u0010\u0090\u0001\u001a\u00020\u000fJ\u0010\u0010\u008f\u0001\u001a\u00020\u000f2\u0007\u0010\u0090\u0001\u001a\u00020wJ\u0012\u0010\u0091\u0001\u001a\u00020w2\u0007\u0010\u0092\u0001\u001a\u00020wH\u0002J\u0007\u0010\u0093\u0001\u001a\u00020\u0004J\u0014\u0010\u0094\u0001\u001a\u00020\u00042\t\u0010\u0082\u0001\u001a\u0004\u0018\u00010PH\u0002J\u000b\u0010\u0095\u0001\u001a\u0004\u0018\u00010nH\u0002J\u0011\u0010\u0096\u0001\u001a\u00020h2\b\u0010\u0097\u0001\u001a\u00030\u0098\u0001R\u001a\u0010\u0003\u001a\u00020\u0004X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0005\u0010\u0006\"\u0004\b\u0007\u0010\bR\u000e\u0010\t\u001a\u00020\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0011\u0010\u000b\u001a\u00020\n\u00a2\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u001a\u0010\u000e\u001a\u00020\u000fX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0010\u0010\u0011\"\u0004\b\u0012\u0010\u0013R\u001a\u0010\u0014\u001a\u00020\u0004X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0015\u0010\u0006\"\u0004\b\u0016\u0010\bR\u000e\u0010\u0017\u001a\u00020\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u0019\u001a\u00020\u000fX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u001a\u0010\u0011\"\u0004\b\u001b\u0010\u0013R\u000e\u0010\u001c\u001a\u00020\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020 X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\"X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010#\u001a\u00020$X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010%\u001a\u00020&X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010'\u001a\u00020&X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010(\u001a\u00020)X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010*\u001a\u00020)X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010+\u001a\u00020\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010,\u001a\u00020\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010-\u001a\u00020.X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010/\u001a\u00020\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0011\u00100\u001a\u00020\n\u00a2\u0006\b\n\u0000\u001a\u0004\b1\u0010\rR\u000e\u00102\u001a\u00020\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u00103\u001a\u000204X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0011\u00105\u001a\u00020\n\u00a2\u0006\b\n\u0000\u001a\u0004\b6\u0010\rR\u0011\u00107\u001a\u00020\n\u00a2\u0006\b\n\u0000\u001a\u0004\b8\u0010\rR\u0011\u00109\u001a\u00020:\u00a2\u0006\b\n\u0000\u001a\u0004\b;\u0010<R\u000e\u0010=\u001a\u00020\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010>\u001a\u00020\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010?\u001a\u00020\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010@\u001a\u00020\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010A\u001a\u00020\"X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0011\u0010B\u001a\u00020 \u00a2\u0006\b\n\u0000\u001a\u0004\bC\u0010DR\u0011\u0010E\u001a\u00020 \u00a2\u0006\b\n\u0000\u001a\u0004\bF\u0010DR\u000e\u0010G\u001a\u00020$X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0017\u0010H\u001a\b\u0012\u0004\u0012\u00020J0I\u00a2\u0006\b\n\u0000\u001a\u0004\bK\u0010LR\u0011\u0010M\u001a\u00020 \u00a2\u0006\b\n\u0000\u001a\u0004\bN\u0010DR\u0010\u0010O\u001a\u0004\u0018\u00010PX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010Q\u001a\u00020\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010R\u001a\u00020\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0011\u0010S\u001a\u00020:\u00a2\u0006\b\n\u0000\u001a\u0004\bT\u0010<R\u0011\u0010U\u001a\u00020$\u00a2\u0006\b\n\u0000\u001a\u0004\bV\u0010WR\u0011\u0010X\u001a\u00020:\u00a2\u0006\b\n\u0000\u001a\u0004\bY\u0010<R\u0011\u0010Z\u001a\u00020 \u00a2\u0006\b\n\u0000\u001a\u0004\b[\u0010DR\u0011\u0010\\\u001a\u00020$\u00a2\u0006\b\n\u0000\u001a\u0004\b]\u0010WR\u0011\u0010^\u001a\u00020 \u00a2\u0006\b\n\u0000\u001a\u0004\b_\u0010DR\u0011\u0010`\u001a\u00020:\u00a2\u0006\b\n\u0000\u001a\u0004\ba\u0010<R\u0011\u0010b\u001a\u00020$\u00a2\u0006\b\n\u0000\u001a\u0004\bc\u0010WR\u000e\u0010d\u001a\u00020 X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010e\u001a\u00020\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010f\u001a\u00020$X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0099\u0001"}, d2={"Lnet/ccbluex/liquidbounce/ui/client/hud/element/elements/Target2;", "Lnet/ccbluex/liquidbounce/ui/client/hud/element/Element;", "()V", "animProgress", "", "getAnimProgress", "()F", "setAnimProgress", "(F)V", "animSpeedValue", "Lnet/ccbluex/liquidbounce/value/IntegerValue;", "backgroundalpha", "getBackgroundalpha", "()Lnet/ccbluex/liquidbounce/value/IntegerValue;", "barColor", "Ljava/awt/Color;", "getBarColor", "()Ljava/awt/Color;", "setBarColor", "(Ljava/awt/Color;)V", "bg", "getBg", "setBg", "bgAlphaValue", "bgBlueValue", "bgColor", "getBgColor", "setBgColor", "bgGreenValue", "bgRedValue", "blueValue", "brightnessValue", "Lnet/ccbluex/liquidbounce/value/FloatValue;", "changeTime", "", "colorModeValue", "Lnet/ccbluex/liquidbounce/value/ListValue;", "counter1", "", "counter2", "decimalFormat", "Ljava/text/DecimalFormat;", "decimalFormat2", "displayPercent", "easingHP", "fontValue", "Lnet/ccbluex/liquidbounce/value/FontValue;", "gblueValue", "generateAmountValue", "getGenerateAmountValue", "ggreenValue", "gotDamaged", "", "gradientDistanceValue", "getGradientDistanceValue", "gradientLoopValue", "getGradientLoopValue", "gradientRoundedBarValue", "Lnet/ccbluex/liquidbounce/value/BoolValue;", "getGradientRoundedBarValue", "()Lnet/ccbluex/liquidbounce/value/BoolValue;", "gredValue", "greenValue", "lastChangeHealth", "lastHealth", "lastUpdate", "maxParticleSize", "getMaxParticleSize", "()Lnet/ccbluex/liquidbounce/value/FloatValue;", "minParticleSize", "getMinParticleSize", "modeValue", "particleList", "", "Lnet/ccbluex/liquidbounce/ui/client/hud/element/elements/Particle;", "getParticleList", "()Ljava/util/List;", "particleRange", "getParticleRange", "prevTarget", "Lnet/ccbluex/liquidbounce/api/minecraft/client/entity/IEntityLivingBase;", "rainbowSpeed", "redValue", "riceParticle", "getRiceParticle", "riceParticleCircle", "getRiceParticleCircle", "()Lnet/ccbluex/liquidbounce/value/ListValue;", "riceParticleFade", "getRiceParticleFade", "riceParticleFadingSpeed", "getRiceParticleFadingSpeed", "riceParticleRect", "getRiceParticleRect", "riceParticleSpeed", "getRiceParticleSpeed", "riceParticleSpin", "getRiceParticleSpin", "riceParticleTriangle", "getRiceParticleTriangle", "saturationValue", "switchAnimSpeedValue", "switchModeValue", "drawAstolfo", "", "target", "nowAnimHP", "drawBest", "easingHealth", "drawElement", "Lnet/ccbluex/liquidbounce/ui/client/hud/element/Border;", "drawFlux", "drawHead", "skin", "Lnet/ccbluex/liquidbounce/api/minecraft/util/IResourceLocation;", "x", "y", "scale", "width", "", "height", "red", "green", "blue", "alpha", "drawHead2", "drawLiquid", "drawMoon", "drawNovo", "drawRice", "entity", "drawRise", "drawRomantic", "drawRomanticHead", "hurtPercent", "drawSparklingWater", "drawTenacity", "drawTenacity5", "drawWaterMelon", "drawZamorozka", "drawnewnovo", "drawnovoline2", "drawnovoline3", "getColor", "color", "getColorAtIndex", "i", "getFadeProgress", "getHealth", "getTBorder", "handleDamage", "ent", "Lnet/minecraft/entity/player/EntityPlayer;", "Fnierior"})
public final class Target2
extends Element {
    private final ListValue modeValue = new ListValue("Mode", new String[]{"Tenacity5", "Rice", "Romantic", "WaterMelon", "SparklingWater", "Best", "Novoline", "Astolfo", "Liquid", "Flux", "Rise", "Zamorozka", "novoline2", "moon", "novoline3", "newnovoline", "tenacity"}, "Rise");
    private final ListValue switchModeValue = new ListValue("SwitchMode", new String[]{"Slide", "Zoom", "None"}, "Slide");
    private final IntegerValue animSpeedValue = new IntegerValue("AnimSpeed", 10, 5, 20);
    private final IntegerValue switchAnimSpeedValue = new IntegerValue("SwitchAnimSpeed", 20, 5, 40);
    private final FontValue fontValue;
    @NotNull
    private final IntegerValue backgroundalpha;
    private final IntegerValue redValue;
    private final IntegerValue greenValue;
    private final IntegerValue blueValue;
    private final IntegerValue gredValue;
    private final IntegerValue ggreenValue;
    private final IntegerValue gblueValue;
    private final ListValue colorModeValue;
    private final FloatValue saturationValue;
    private final FloatValue brightnessValue;
    private final IntegerValue bgRedValue;
    private final IntegerValue bgGreenValue;
    private final IntegerValue bgBlueValue;
    private final IntegerValue bgAlphaValue;
    @NotNull
    private final IntegerValue gradientLoopValue;
    @NotNull
    private final IntegerValue gradientDistanceValue;
    @NotNull
    private final BoolValue gradientRoundedBarValue;
    @NotNull
    private final BoolValue riceParticle;
    @NotNull
    private final BoolValue riceParticleSpin;
    @NotNull
    private final IntegerValue generateAmountValue;
    @NotNull
    private final ListValue riceParticleCircle;
    @NotNull
    private final ListValue riceParticleRect;
    @NotNull
    private final ListValue riceParticleTriangle;
    @NotNull
    private final FloatValue riceParticleSpeed;
    @NotNull
    private final BoolValue riceParticleFade;
    @NotNull
    private final FloatValue riceParticleFadingSpeed;
    private final IntegerValue rainbowSpeed;
    @NotNull
    private final FloatValue particleRange;
    @NotNull
    private final FloatValue minParticleSize;
    @NotNull
    private final FloatValue maxParticleSize;
    @NotNull
    private Color barColor;
    @NotNull
    private Color bgColor;
    @NotNull
    private final List<Particle> particleList;
    private float easingHP;
    private float animProgress;
    private IEntityLivingBase prevTarget;
    private float lastHealth;
    private float lastChangeHealth;
    private long changeTime;
    private float displayPercent;
    private boolean gotDamaged;
    private float bg;
    private long lastUpdate;
    private final DecimalFormat decimalFormat;
    private final DecimalFormat decimalFormat2;
    private final int[] counter1;
    private final int[] counter2;

    @NotNull
    public final IntegerValue getBackgroundalpha() {
        return this.backgroundalpha;
    }

    @NotNull
    public final IntegerValue getGradientLoopValue() {
        return this.gradientLoopValue;
    }

    @NotNull
    public final IntegerValue getGradientDistanceValue() {
        return this.gradientDistanceValue;
    }

    @NotNull
    public final BoolValue getGradientRoundedBarValue() {
        return this.gradientRoundedBarValue;
    }

    @NotNull
    public final BoolValue getRiceParticle() {
        return this.riceParticle;
    }

    @NotNull
    public final BoolValue getRiceParticleSpin() {
        return this.riceParticleSpin;
    }

    @NotNull
    public final IntegerValue getGenerateAmountValue() {
        return this.generateAmountValue;
    }

    @NotNull
    public final ListValue getRiceParticleCircle() {
        return this.riceParticleCircle;
    }

    @NotNull
    public final ListValue getRiceParticleRect() {
        return this.riceParticleRect;
    }

    @NotNull
    public final ListValue getRiceParticleTriangle() {
        return this.riceParticleTriangle;
    }

    @NotNull
    public final FloatValue getRiceParticleSpeed() {
        return this.riceParticleSpeed;
    }

    @NotNull
    public final BoolValue getRiceParticleFade() {
        return this.riceParticleFade;
    }

    @NotNull
    public final FloatValue getRiceParticleFadingSpeed() {
        return this.riceParticleFadingSpeed;
    }

    @NotNull
    public final FloatValue getParticleRange() {
        return this.particleRange;
    }

    @NotNull
    public final FloatValue getMinParticleSize() {
        return this.minParticleSize;
    }

    @NotNull
    public final FloatValue getMaxParticleSize() {
        return this.maxParticleSize;
    }

    @NotNull
    public final Color getBarColor() {
        return this.barColor;
    }

    public final void setBarColor(@NotNull Color color) {
        Intrinsics.checkParameterIsNotNull(color, "<set-?>");
        this.barColor = color;
    }

    @NotNull
    public final Color getBgColor() {
        return this.bgColor;
    }

    public final void setBgColor(@NotNull Color color) {
        Intrinsics.checkParameterIsNotNull(color, "<set-?>");
        this.bgColor = color;
    }

    @NotNull
    public final List<Particle> getParticleList() {
        return this.particleList;
    }

    public final float getAnimProgress() {
        return this.animProgress;
    }

    public final void setAnimProgress(float f) {
        this.animProgress = f;
    }

    public final float getBg() {
        return this.bg;
    }

    public final void setBg(float f) {
        this.bg = f;
    }

    private final float getHealth(IEntityLivingBase entity) {
        return entity == null || entity.isDead() ? 0.0f : entity.getHealth();
    }

    private final int getColorAtIndex(int i) {
        return ColorUtils.fade(new Color(((Number)this.redValue.get()).intValue(), ((Number)this.greenValue.get()).intValue(), ((Number)this.blueValue.get()).intValue()), i * ((Number)this.gradientDistanceValue.get()).intValue(), 100).getRGB();
    }

    @NotNull
    public final Color getColor(@NotNull Color color) {
        Intrinsics.checkParameterIsNotNull(color, "color");
        return ColorUtils.INSTANCE.reAlpha(color, (int)((float)color.getAlpha() / 255.0f * (1.0f - this.getFadeProgress())));
    }

    @NotNull
    public final Color getColor(int color) {
        return this.getColor(new Color(color));
    }

    public final float getFadeProgress() {
        return this.animProgress;
    }

    public final void handleDamage(@NotNull EntityPlayer ent) {
        Intrinsics.checkParameterIsNotNull(ent, "ent");
        this.gotDamaged = true;
    }

    /*
     * Unable to fully structure code
     */
    @Override
    @Nullable
    public Border drawElement() {
        target = LiquidBounce.INSTANCE.getCombatManager().getTarget();
        time = System.currentTimeMillis();
        pct = (float)(time - this.lastUpdate) / (((Number)this.switchAnimSpeedValue.get()).floatValue() * 50.0f);
        this.lastUpdate = System.currentTimeMillis();
        if (MinecraftInstance.classProvider.isGuiHudDesigner(MinecraftInstance.mc.getCurrentScreen())) {
            target = MinecraftInstance.mc.getThePlayer();
        }
        if (target != null) {
            this.prevTarget = target;
        }
        if (this.prevTarget == null) {
            return this.getTBorder();
        }
        if (target != null) {
            if (this.displayPercent < (float)true) {
                this.displayPercent += pct;
            }
            if (this.displayPercent > (float)true) {
                this.displayPercent = 1.0f;
            }
        } else {
            if (this.displayPercent > (float)false) {
                this.displayPercent -= pct;
            }
            if (this.displayPercent < (float)false) {
                this.displayPercent = 0.0f;
                this.prevTarget = null;
                return this.getTBorder();
            }
        }
        this.animProgress += 0.0075f * (float)RenderUtils.deltaTime;
        this.animProgress = RangesKt.coerceIn(this.animProgress, 0.0f, 1.0f);
        var6_4 = (String)this.colorModeValue.get();
        tmp = -1;
        switch (var6_4.hashCode()) {
            case -2137395588: {
                if (!var6_4.equals("Health")) break;
                tmp = 1;
                break;
            }
            case -1656737386: {
                if (!var6_4.equals("Rainbow")) break;
                tmp = 2;
                break;
            }
            case 2029746065: {
                if (!var6_4.equals("Custom")) break;
                tmp = 3;
                break;
            }
            case 2181788: {
                if (!var6_4.equals("Fade")) break;
                tmp = 4;
                break;
            }
        }
        switch (tmp) {
            case 2: {
                v0 = new Color(ColorUtils.hslRainbow$default(ColorUtils.INSTANCE, 100 * ((Number)this.rainbowSpeed.get()).intValue(), 0.0f, 0.0f, 0, 0, 30, null).getRGB());
                break;
            }
            case 3: {
                v0 = new Color(((Number)this.redValue.get()).intValue(), ((Number)this.greenValue.get()).intValue(), ((Number)this.blueValue.get()).intValue());
                break;
            }
            case 4: {
                v0 = ColorUtils.fade(new Color(((Number)this.redValue.get()).intValue(), ((Number)this.greenValue.get()).intValue(), ((Number)this.blueValue.get()).intValue()), 0, 100);
                break;
            }
            case 1: {
                if (target != null) {
                    v0 = BlendUtils.getHealthColor(target.getHealth(), target.getMaxHealth());
                    break;
                }
                v0 = Color.green;
                break;
            }
            default: {
                v0 = ColorUtils.LiquidSlowly(System.nanoTime(), 0, ((Number)this.saturationValue.get()).floatValue(), ((Number)this.brightnessValue.get()).floatValue());
                if (v0 != null) break;
                Intrinsics.throwNpe();
            }
        }
        preBarColor = v0;
        preBgColor = new Color(((Number)this.bgRedValue.get()).intValue(), ((Number)this.bgGreenValue.get()).intValue(), ((Number)this.bgBlueValue.get()).intValue(), ((Number)this.bgAlphaValue.get()).intValue());
        v1 = preBarColor;
        Intrinsics.checkExpressionValueIsNotNull(v1, "preBarColor");
        this.barColor = ColorUtils.INSTANCE.reAlpha(v1, (int)((float)preBarColor.getAlpha() / 255.0f * (1.0f - this.animProgress)));
        this.bgColor = ColorUtils.INSTANCE.reAlpha(preBgColor, (int)((float)preBgColor.getAlpha() / 255.0f * (1.0f - this.animProgress)));
        if (this.getHealth(this.prevTarget) != this.lastHealth) {
            this.lastChangeHealth = this.lastHealth;
            this.lastHealth = this.getHealth(this.prevTarget);
            this.changeTime = time;
        }
        nowAnimHP = time - (long)(((Number)this.animSpeedValue.get()).intValue() * 50) < this.changeTime ? this.getHealth(this.prevTarget) + (this.lastChangeHealth - this.getHealth(this.prevTarget)) * ((float)true - (float)(time - this.changeTime) / (((Number)this.animSpeedValue.get()).floatValue() * 50.0f)) : this.getHealth(this.prevTarget);
        var8_7 = (String)this.switchModeValue.get();
        var9_8 = false;
        v2 = var8_7;
        if (v2 == null) {
            throw new TypeCastException("null cannot be cast to non-null type java.lang.String");
        }
        v3 = v2.toLowerCase();
        Intrinsics.checkExpressionValueIsNotNull(v3, "(this as java.lang.String).toLowerCase()");
        var8_7 = v3;
        switch (var8_7.hashCode()) {
            case 109526449: {
                if (!var8_7.equals("slide")) ** break;
                break;
            }
            case 3744723: {
                if (!var8_7.equals("zoom")) ** break;
                v4 = this.getTBorder();
                if (v4 == null) {
                    return null;
                }
                border = v4;
                GL11.glScalef((float)this.displayPercent, (float)this.displayPercent, (float)this.displayPercent);
                GL11.glTranslatef((float)(border.getX2() * 0.5f * ((float)true - this.displayPercent) / this.displayPercent), (float)(border.getY2() * 0.5f * ((float)true - this.displayPercent) / this.displayPercent), (float)0.0f);
                ** break;
            }
        }
        percent = EaseUtils.easeInOutExpo(1.0 - (double)this.displayPercent);
        v5 = MinecraftInstance.mc;
        Intrinsics.checkExpressionValueIsNotNull(v5, "mc");
        xAxis = (double)MinecraftInstance.classProvider.createScaledResolution(v5).getScaledWidth() - this.getRenderX();
        GL11.glTranslated((double)(xAxis * percent), (double)0.0, (double)0.0);
        ** break;
lbl103:
        // 5 sources

        var8_7 = (String)this.modeValue.get();
        var9_8 = false;
        v6 = var8_7;
        if (v6 == null) {
            throw new TypeCastException("null cannot be cast to non-null type java.lang.String");
        }
        v7 = v6.toLowerCase();
        Intrinsics.checkExpressionValueIsNotNull(v7, "(this as java.lang.String).toLowerCase()");
        var8_7 = v7;
        tmp = -1;
        switch (var8_7.hashCode()) {
            case -1454523186: {
                if (!var8_7.equals("newnovoline")) break;
                tmp = 1;
                break;
            }
            case 3020260: {
                if (!var8_7.equals("best")) break;
                tmp = 2;
                break;
            }
            case 3500249: {
                if (!var8_7.equals("rice")) break;
                tmp = 3;
                break;
            }
            case 1322963594: {
                if (!var8_7.equals("zamorozka")) break;
                tmp = 4;
                break;
            }
            case 1648341806: {
                if (!var8_7.equals("novoline")) break;
                tmp = 5;
                break;
            }
            case -441011516: {
                if (!var8_7.equals("novoline2")) break;
                tmp = 6;
                break;
            }
            case 3357441: {
                if (!var8_7.equals("moon")) break;
                tmp = 7;
                break;
            }
            case -441011515: {
                if (!var8_7.equals("novoline3")) break;
                tmp = 8;
                break;
            }
            case -1102567108: {
                if (!var8_7.equals("liquid")) break;
                tmp = 9;
                break;
            }
            case -240873103: {
                if (!var8_7.equals("romantic")) break;
                tmp = 10;
                break;
            }
            case -1133275996: {
                if (!var8_7.equals("sparklingwater")) break;
                tmp = 11;
                break;
            }
            case -1307030705: {
                if (!var8_7.equals("tenacity")) break;
                tmp = 12;
                break;
            }
            case -1863246138: {
                if (!var8_7.equals("tenacity5")) break;
                tmp = 13;
                break;
            }
            case -703561496: {
                if (!var8_7.equals("astolfo")) break;
                tmp = 14;
                break;
            }
            case 3146217: {
                if (!var8_7.equals("flux")) break;
                tmp = 15;
                break;
            }
            case 1973903356: {
                if (!var8_7.equals("watermelon")) break;
                tmp = 16;
                break;
            }
            case 3500745: {
                if (!var8_7.equals("rise")) break;
                tmp = 17;
                break;
            }
        }
        switch (tmp) {
            case 11: {
                v8 = this.prevTarget;
                if (v8 == null) {
                    Intrinsics.throwNpe();
                }
                this.drawSparklingWater(v8, nowAnimHP);
                break;
            }
            case 5: {
                v9 = this.prevTarget;
                if (v9 == null) {
                    Intrinsics.throwNpe();
                }
                this.drawNovo(v9, nowAnimHP);
                break;
            }
            case 14: {
                v10 = this.prevTarget;
                if (v10 == null) {
                    Intrinsics.throwNpe();
                }
                this.drawAstolfo(v10, nowAnimHP);
                break;
            }
            case 9: {
                v11 = this.prevTarget;
                if (v11 == null) {
                    Intrinsics.throwNpe();
                }
                this.drawLiquid(v11, nowAnimHP);
                break;
            }
            case 15: {
                v12 = this.prevTarget;
                if (v12 == null) {
                    Intrinsics.throwNpe();
                }
                this.drawFlux(v12, nowAnimHP);
                break;
            }
            case 17: {
                v13 = this.prevTarget;
                if (v13 == null) {
                    Intrinsics.throwNpe();
                }
                this.drawRise(v13, nowAnimHP);
                break;
            }
            case 2: {
                v14 = this.prevTarget;
                if (v14 == null) {
                    Intrinsics.throwNpe();
                }
                this.drawBest(v14, nowAnimHP);
                break;
            }
            case 4: {
                v15 = this.prevTarget;
                if (v15 == null) {
                    Intrinsics.throwNpe();
                }
                this.drawZamorozka(v15, nowAnimHP);
                break;
            }
            case 6: {
                v16 = this.prevTarget;
                if (v16 == null) {
                    Intrinsics.throwNpe();
                }
                this.drawnovoline2(v16, nowAnimHP);
                break;
            }
            case 7: {
                v17 = this.prevTarget;
                if (v17 == null) {
                    Intrinsics.throwNpe();
                }
                this.drawMoon(v17, nowAnimHP);
                break;
            }
            case 8: {
                v18 = this.prevTarget;
                if (v18 == null) {
                    Intrinsics.throwNpe();
                }
                this.drawnovoline3(v18, nowAnimHP);
                break;
            }
            case 1: {
                v19 = this.prevTarget;
                if (v19 == null) {
                    Intrinsics.throwNpe();
                }
                this.drawnewnovo(v19, nowAnimHP);
                break;
            }
            case 12: {
                v20 = this.prevTarget;
                if (v20 == null) {
                    Intrinsics.throwNpe();
                }
                this.drawTenacity(v20, nowAnimHP);
                break;
            }
            case 16: {
                v21 = this.prevTarget;
                if (v21 == null) {
                    Intrinsics.throwNpe();
                }
                this.drawWaterMelon(v21, nowAnimHP);
                break;
            }
            case 10: {
                v22 = this.prevTarget;
                if (v22 == null) {
                    Intrinsics.throwNpe();
                }
                this.drawRomantic(v22, nowAnimHP);
                break;
            }
            case 13: {
                v23 = this.prevTarget;
                if (v23 == null) {
                    Intrinsics.throwNpe();
                }
                this.drawTenacity5(v23, nowAnimHP);
                break;
            }
            case 3: {
                v24 = this.prevTarget;
                if (v24 == null) {
                    Intrinsics.throwNpe();
                }
                this.drawRice(v24, nowAnimHP);
                break;
            }
        }
        return this.getTBorder();
    }

    private final void drawTenacity5(IEntityLivingBase target, float easingHealth) {
        String string = target.getName();
        if (string == null) {
            Intrinsics.throwNpe();
        }
        int additionalWidth = RangesKt.coerceAtLeast(Fonts.font40.getStringWidth(string), 75);
        Color c1 = ColorUtil.interpolateColorsBackAndForth(17, 0, new Color(230, 140, 255, 205), new Color(101, 208, 252, 205), true);
        Color c2 = ColorUtil.interpolateColorsBackAndForth(17, 90, new Color(230, 140, 255, 205), new Color(101, 208, 252, 205), true);
        Color c3 = ColorUtil.interpolateColorsBackAndForth(17, 270, new Color(230, 140, 255, 205), new Color(101, 208, 252, 205), true);
        Color c4 = ColorUtil.interpolateColorsBackAndForth(17, 180, new Color(230, 140, 255, 205), new Color(101, 208, 252, 205), true);
        GL11.glTranslated((double)(-this.getRenderX() * (double)this.getScale()), (double)(-this.getRenderY() * (double)this.getScale()), (double)0.0);
        GL11.glPushMatrix();
        ShadowUtils.INSTANCE.shadow(8.0f, new Function0<Unit>(this, additionalWidth, c1, c2, c3, c4){
            final /* synthetic */ Target2 this$0;
            final /* synthetic */ int $additionalWidth;
            final /* synthetic */ Color $c1;
            final /* synthetic */ Color $c2;
            final /* synthetic */ Color $c3;
            final /* synthetic */ Color $c4;

            public final void invoke() {
                GL11.glPushMatrix();
                GL11.glTranslated((double)(this.this$0.getRenderX() * (double)this.this$0.getScale()), (double)(this.this$0.getRenderY() * (double)this.this$0.getScale()), (double)0.0);
                RoundedUtil.drawGradientRound(0.0f * this.this$0.getScale(), 5.0f * this.this$0.getScale(), 59.0f + (float)this.$additionalWidth * this.this$0.getScale(), 45.0f * this.this$0.getScale(), 6.0f, this.$c1, this.$c2, this.$c3, this.$c4);
                GL11.glPopMatrix();
            }
            {
                this.this$0 = target2;
                this.$additionalWidth = n;
                this.$c1 = color;
                this.$c2 = color2;
                this.$c3 = color3;
                this.$c4 = color4;
                super(0);
            }
        }, drawTenacity5.2.INSTANCE);
        GL11.glPopMatrix();
        GL11.glTranslated((double)(this.getRenderX() * (double)this.getScale()), (double)(this.getRenderY() * (double)this.getScale()), (double)0.0);
        RoundedUtil.drawGradientRound(0.0f, 5.0f, 59.0f + (float)additionalWidth, 45.0f, 6.0f, c1, c2, c3, c4);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GL11.glPushMatrix();
        GL11.glTranslatef((float)5.0f, (float)5.0f, (float)0.0f);
        ITextureManager iTextureManager = MinecraftInstance.mc.getTextureManager();
        INetworkPlayerInfo iNetworkPlayerInfo = MinecraftInstance.mc.getNetHandler().getPlayerInfo(target.getUniqueID());
        if (iNetworkPlayerInfo == null) {
            Intrinsics.throwNpe();
        }
        iTextureManager.bindTexture(iNetworkPlayerInfo.getLocationSkin());
        RenderUtils.drawScaledCustomSizeModalCircle(5, 7, 8.0f, 8.0f, 8, 8, 30, 30, 64.0f, 64.0f);
        RenderUtils.drawScaledCustomSizeModalCircle(5, 7, 40.0f, 8.0f, 8, 8, 30, 30, 64.0f, 64.0f);
        GL11.glPopMatrix();
        String string2 = target.getName();
        if (string2 == null) {
            Intrinsics.throwNpe();
        }
        float f = (float)47 + (float)additionalWidth / 2.0f;
        float f2 = 1.0f + (float)Fonts.font40.getFontHeight();
        Color color = Color.WHITE;
        Intrinsics.checkExpressionValueIsNotNull(color, "Color.WHITE");
        Fonts.font40.drawCenteredString(string2, f, f2, color.getRGB(), false);
        StringBuilder stringBuilder = new StringBuilder().append(String.valueOf(MathKt.roundToInt(this.easingHP / target.getMaxHealth() * (float)100))).append("% - ");
        IEntityPlayerSP iEntityPlayerSP = MinecraftInstance.mc.getThePlayer();
        if (iEntityPlayerSP == null) {
            Intrinsics.throwNpe();
        }
        String infoStr = stringBuilder.append(String.valueOf(MathKt.roundToInt(PlayerExtensionKt.getDistanceToEntityBox(iEntityPlayerSP, target)))).append("M").toString();
        float f3 = 47.0f + (float)(additionalWidth - Fonts.font40.getStringWidth(infoStr)) / 2.0f;
        float f4 = 45.0f - (float)Fonts.font40.getFontHeight();
        Color color2 = Color.WHITE;
        Intrinsics.checkExpressionValueIsNotNull(color2, "Color.WHITE");
        Fonts.font40.drawString(infoStr, f3, f4, color2.getRGB(), false);
        RenderUtils.drawRoundedCornerRect(46.0f, 24.0f, 46.0f + (float)additionalWidth, 29.0f, 2.5f, new Color(60, 60, 60, 130).getRGB());
        RenderUtils.drawRoundedCornerRect(46.0f, 24.0f, 46.0f + this.easingHP / target.getMaxHealth() * (float)additionalWidth, 29.0f, 2.5f, new Color(240, 240, 240, 250).getRGB());
    }

    /*
     * Unable to fully structure code
     */
    private final void drawRice(IEntityLivingBase entity, float easingHealth) {
        block17: {
            block18: {
                block19: {
                    font = Fonts.font35;
                    name = "Name: " + entity.getName();
                    v0 = new StringBuilder().append("Distance: ");
                    v1 = MinecraftInstance.mc.getThePlayer();
                    if (v1 == null) {
                        Intrinsics.throwNpe();
                    }
                    info = v0.append(this.decimalFormat2.format(PlayerExtensionKt.getDistanceToEntityBox(v1, entity))).toString();
                    healthName = this.decimalFormat2.format(Float.valueOf(easingHealth));
                    length = RangesKt.coerceAtLeast((float)RangesKt.coerceAtLeast(font.getStringWidth(name), font.getStringWidth(info)) + 40.0f, 125.0f);
                    v2 = this.decimalFormat2.format(Float.valueOf(entity.getMaxHealth()));
                    Intrinsics.checkExpressionValueIsNotNull(v2, "decimalFormat2.format(entity.maxHealth)");
                    maxHealthLength = font.getStringWidth(v2);
                    TenacityRectUtil.drawRect(0, 0, (int)(10.0f + length), 55);
                    if (!((Boolean)this.riceParticle.get()).booleanValue()) break block17;
                    if (!this.gotDamaged) break block18;
                    var9_9 = 0;
                    var10_12 = ((Number)this.generateAmountValue.get()).intValue();
                    if (var9_9 > var10_12) break block19;
                    while (true) {
                        block20: {
                            parSize = RandomUtils.INSTANCE.nextFloat(((Number)this.minParticleSize.get()).floatValue(), ((Number)this.maxParticleSize.get()).floatValue());
                            parDistX = RandomUtils.INSTANCE.nextFloat(-((Number)this.particleRange.get()).floatValue(), ((Number)this.particleRange.get()).floatValue());
                            parDistY = RandomUtils.INSTANCE.nextFloat(-((Number)this.particleRange.get()).floatValue(), ((Number)this.particleRange.get()).floatValue());
                            var16_24 = firstChar = RandomUtils.INSTANCE.random(1, (StringsKt.equals((String)this.riceParticleCircle.get(), "none", true) != false ? "" : "c") + (StringsKt.equals((String)this.riceParticleRect.get(), "none", true) != false ? "" : "r") + (StringsKt.equals((String)this.riceParticleTriangle.get(), "none", true) != false ? "" : "t"));
                            switch (var16_24.hashCode()) {
                                case 114: {
                                    if (!var16_24.equals("r")) ** break;
                                    break;
                                }
                                case 99: {
                                    if (!var16_24.equals("c")) ** break;
                                    v3 = new StringBuilder().append("c_");
                                    var17_25 = (String)this.riceParticleCircle.get();
                                    Intrinsics.checkExpressionValueIsNotNull(Locale.getDefault(), "Locale.getDefault()");
                                    var21_29 = v3;
                                    var20_28 = ShapeType.Companion;
                                    var19_27 = false;
                                    v4 = var17_25;
                                    if (v4 == null) {
                                        throw new TypeCastException("null cannot be cast to non-null type java.lang.String");
                                    }
                                    Intrinsics.checkExpressionValueIsNotNull(v4.toLowerCase(var18_26), "(this as java.lang.String).toLowerCase(locale)");
                                    v5 = var20_28;
                                    v6 = var21_29.append(var22_30).toString();
                                    break block20;
                                }
                            }
                            v7 = new StringBuilder().append("r_");
                            var17_25 = (String)this.riceParticleRect.get();
                            Intrinsics.checkExpressionValueIsNotNull(Locale.getDefault(), "Locale.getDefault()");
                            var21_29 = v7;
                            var19_27 = false;
                            v8 = var17_25;
                            if (v8 == null) {
                                throw new TypeCastException("null cannot be cast to non-null type java.lang.String");
                            }
                            Intrinsics.checkExpressionValueIsNotNull(v8.toLowerCase(var18_26), "(this as java.lang.String).toLowerCase(locale)");
                            v5 = var20_28;
                            v6 = var21_29.append(var22_30).toString();
                            break block20;
                            v9 = new StringBuilder().append("t_");
                            var17_25 = (String)this.riceParticleTriangle.get();
                            Intrinsics.checkExpressionValueIsNotNull(Locale.getDefault(), "Locale.getDefault()");
                            var21_29 = v9;
                            var19_27 = false;
                            v10 = var17_25;
                            if (v10 == null) {
                                throw new TypeCastException("null cannot be cast to non-null type java.lang.String");
                            }
                            Intrinsics.checkExpressionValueIsNotNull(v10.toLowerCase(var18_26), "(this as java.lang.String).toLowerCase(locale)");
                            v5 = var20_28;
                            v6 = var21_29.append(var22_30).toString();
                        }
                        if (v5.getTypeFromName(v6) == null) {
                            break;
                        }
                        v11 = LiquidBounce.INSTANCE.getModuleManager().get(Gident.class);
                        if (v11 == null) {
                            throw new TypeCastException("null cannot be cast to non-null type net.ccbluex.liquidbounce.features.module.modules.color.Gident");
                        }
                        hud = (Gident)v11;
                        color2 = RenderUtils.getGradientOffset(new Color(((Number)Gident.redValue.get()).intValue(), ((Number)Gident.greenValue.get()).intValue(), ((Number)Gident.blueValue.get()).intValue()), new Color(((Number)Gident.redValue2.get()).intValue(), ((Number)Gident.greenValue2.get()).intValue(), ((Number)Gident.blueValue2.get()).intValue()), 10.0);
                        v12 = new float[]{0.0f, 1.0f};
                        v13 = new Color[2];
                        v14 = Color.white;
                        Intrinsics.checkExpressionValueIsNotNull(v14, "Color.white");
                        v13[0] = v14;
                        v15 = color2;
                        Intrinsics.checkExpressionValueIsNotNull(v15, "color2");
                        v13[1] = v15;
                        v16 = BlendUtils.blendColors(v12, v13, RandomUtils.nextBoolean() != false ? RandomUtils.INSTANCE.nextFloat(0.5f, 1.0f) : 0.0f);
                        Intrinsics.checkExpressionValueIsNotNull(v16, "BlendUtils.blendColors(\n\u2026loat(0.5F, 1.0F) else 0F)");
                        this.particleList.add(new Particle(v16, parDistX, parDistY, parSize, drawType));
                        if (j == var10_12) break;
                        ++j;
                    }
                }
                this.gotDamaged = false;
            }
            var10_12 = 0;
            deleteQueue = new ArrayList<E>();
            $this$forEach$iv = this.particleList;
            $i$f$forEach = false;
            for (T element$iv : $this$forEach$iv) {
                particle = (Particle)element$iv;
                $i$a$-forEach-Target2$drawRice$1 = false;
                if (particle.getAlpha() > 0.0f) {
                    particle.render(20.0f, 20.0f, (Boolean)this.riceParticleFade.get(), ((Number)this.riceParticleSpeed.get()).floatValue(), ((Number)this.riceParticleFadingSpeed.get()).floatValue(), (Boolean)this.riceParticleSpin.get());
                    continue;
                }
                deleteQueue.add(particle);
            }
            this.particleList.removeAll(deleteQueue);
        }
        scaleHT = RangesKt.coerceIn((float)entity.getHurtTime() / (float)Math.random(), 0.0f, 1.0f);
        if (MinecraftInstance.mc.getNetHandler().getPlayerInfo(entity.getUniqueID()) != null) {
            v17 = MinecraftInstance.mc.getNetHandler().getPlayerInfo(entity.getUniqueID());
            if (v17 == null) {
                Intrinsics.throwNpe();
            }
            Target2.drawHead$default(this, v17.getLocationSkin(), 5.0f + 15.0f * (scaleHT * 0.2f), 5.0f + 15.0f * (scaleHT * 0.2f), 1.0f - scaleHT * 0.2f, 30, 30, 1.0f, 0.4f + (1.0f - scaleHT) * 0.6f, 0.4f + (1.0f - scaleHT) * 0.6f, 0.0f, 512, null);
        }
        GlStateManager.func_179117_G();
        font.drawString(name, 39.0f, 11.0f, this.getColor(-1).getRGB());
        font.drawString(info, 39.0f, 23.0f, this.getColor(-1).getRGB());
        barWidth = (length - 5.0f - maxHealthLength) * RangesKt.coerceIn(easingHealth / entity.getMaxHealth(), 0.0f, 1.0f);
        Stencil.write(false);
        GL11.glDisable((int)3553);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        if (((Boolean)this.gradientRoundedBarValue.get()).booleanValue()) {
            RenderUtils.fastRoundedRect(5.0f, 42.0f, 5.0f + barWidth, 48.0f, 3.0f);
        } else {
            RenderUtils.quickDrawRect(5.0f, 42.0f, 5.0f + barWidth, 48.0f);
        }
        GL11.glDisable((int)3042);
        Stencil.erase(true);
        RenderUtils.drawRoundedRect(5.0f, 42.0f, length - maxHealthLength, 48.0f, 3, new Color(255, 43, 24).getRGB());
        Stencil.dispose();
        GlStateManager.func_179117_G();
        v18 = healthName;
        Intrinsics.checkExpressionValueIsNotNull(v18, "healthName");
        font.drawString(v18, 10.0f + barWidth, 41.0f, this.getColor(-1).getRGB());
    }

    private final void drawWaterMelon(IEntityLivingBase target, float easingHealth) {
        RenderUtils.drawRoundedCornerRect(-1.5f, 2.5f, 152.5f, 52.5f, 5.0f, new Color(0, 0, 0, 26).getRGB());
        RenderUtils.drawRoundedCornerRect(-1.0f, 2.0f, 152.0f, 52.0f, 5.0f, new Color(0, 0, 0, 26).getRGB());
        RenderUtils.drawRoundedCornerRect(-0.5f, 1.5f, 151.5f, 51.5f, 5.0f, new Color(0, 0, 0, 40).getRGB());
        RenderUtils.drawRoundedCornerRect(-0.0f, 1.0f, 151.0f, 51.0f, 5.0f, new Color(0, 0, 0, 60).getRGB());
        RenderUtils.drawRoundedCornerRect(0.5f, 0.5f, 150.5f, 50.5f, 5.0f, new Color(0, 0, 0, 50).getRGB());
        RenderUtils.drawRoundedCornerRect(1.0f, 0.0f, 150.0f, 50.0f, 5.0f, new Color(0, 0, 0, 50).getRGB());
        float hurtPercent = PlayerExtensionKt.getHurtPercent(target);
        float scale = hurtPercent == 0.0f ? 1.0f : (hurtPercent < 0.5f ? 1.0f - 0.1f * hurtPercent * (float)2 : 0.9f + 0.1f * (hurtPercent - 0.5f) * (float)2);
        int size = 35;
        GL11.glPushMatrix();
        GL11.glTranslatef((float)5.0f, (float)5.0f, (float)0.0f);
        GL11.glScalef((float)scale, (float)scale, (float)scale);
        GL11.glTranslatef((float)((float)size * 0.5f * (1.0f - scale) / scale), (float)((float)size * 0.5f * (1.0f - scale) / scale), (float)0.0f);
        GL11.glColor4f((float)1.0f, (float)(1.0f - hurtPercent), (float)(1.0f - hurtPercent), (float)1.0f);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        ITextureManager iTextureManager = MinecraftInstance.mc.getTextureManager();
        INetworkPlayerInfo iNetworkPlayerInfo = MinecraftInstance.mc.getNetHandler().getPlayerInfo(target.getUniqueID());
        if (iNetworkPlayerInfo == null) {
            Intrinsics.throwNpe();
        }
        iTextureManager.bindTexture(iNetworkPlayerInfo.getLocationSkin());
        RenderUtils.drawScaledCustomSizeModalCircle(5, 5, 8.0f, 8.0f, 8, 8, 30, 30, 64.0f, 64.0f);
        RenderUtils.drawScaledCustomSizeModalCircle(5, 5, 40.0f, 8.0f, 8, 8, 30, 30, 64.0f, 64.0f);
        GL11.glPopMatrix();
        String string = String.valueOf(target.getName());
        Color color = Color.WHITE;
        Intrinsics.checkExpressionValueIsNotNull(color, "Color.WHITE");
        Fonts.font35.drawString(string, 45.0f, 12.0f, color.getRGB());
        DecimalFormat df = new DecimalFormat("0.00");
        Fonts.font30.drawString("Armor " + df.format(PlayerUtils.INSTANCE.getAr(target) * (double)100) + '%', 45.0f, 24.0f, new Color(200, 200, 200).getRGB());
        RenderUtils.drawRoundedCornerRect(45.0f, 32.0f, 145.0f, 42.0f, 5.0f, new Color(0, 0, 0, 100).getRGB());
        RenderUtils.drawRoundedCornerRect(45.0f, 32.0f, 45.0f + easingHealth / target.getMaxHealth() * 100.0f, 42.0f, 5.0f, ColorUtils.rainbow().getRGB());
        Fonts.font30.drawString(df.format(Float.valueOf(easingHealth / target.getMaxHealth() * (float)100)) + '%', 80.0f, 34.0f, new Color(255, 255, 255).getRGB(), true);
    }

    private final void drawRomantic(IEntityLivingBase target, float easingHealth) {
        float floatX = (float)this.getRenderX();
        float floatY = (float)this.getRenderY();
        String string = target.getName();
        if (string == null) {
            Intrinsics.throwNpe();
        }
        float width = 26.0f + (float)RangesKt.coerceAtLeast(Fonts.font30.getStringWidth(string), 90);
        float size = 24.0f;
        float hurtPercent = (float)target.getHurtTime() / 10.0f;
        float scale = hurtPercent == 0.0f ? 1.0f : (hurtPercent < 0.5f ? 1.0f - 0.2f * hurtPercent * (float)2 : 0.8f + 0.2f * (hurtPercent - 0.5f) * (float)2);
        RenderUtils.drawRect(0.0f, 0.0f, width, 38.0f, new Color(0, 0, 0, 30));
        RenderUtils.drawShadowWithCustomAlpha(0.0f, 0.0f, width, 38.0f, 255.0f);
        GL11.glPushMatrix();
        GL11.glTranslatef((float)5.0f, (float)5.0f, (float)0.0f);
        GL11.glScalef((float)scale, (float)scale, (float)scale);
        GL11.glTranslatef((float)(size * 0.5f * (1.0f - scale) / scale), (float)(size * 0.5f * (1.0f - scale) / scale), (float)0.0f);
        INetworkPlayerInfo playerInfo = MinecraftInstance.mc.getNetHandler().getPlayerInfo(target.getUniqueID());
        if (playerInfo != null) {
            IResourceLocation locationSkin = playerInfo.getLocationSkin();
            this.drawRomanticHead(locationSkin, 24, 24, hurtPercent);
        }
        GL11.glPopMatrix();
        if (easingHealth > target.getHealth()) {
            RenderUtils.drawRect(34.0f, 20.0f, 34.0f + (width - 42.0f) * (easingHealth / target.getMaxHealth()), 28.0f, new Color(255, 10, 10));
        }
        GlStateManager.func_179117_G();
        String string2 = target.getName();
        if (string2 == null) {
            Intrinsics.throwNpe();
        }
        Fonts.font30.drawString(string2, 34.0f, 20.0f - (float)Fonts.font30.getFontHeight(), new Color(255, 255, 255).getRGB());
        RenderUtils.drawRect(34.0f, 20.0f, width - 8.0f, 28.0f, new Color(61, 61, 61, 50));
        RenderUtils.drawRect(34.0f, 20.0f, 34.0f + easingHealth / target.getMaxHealth() * (width - 42.0f), 28.0f, new Color(255, 255, 255));
        if (easingHealth < target.getHealth()) {
            RenderUtils.drawRect(easingHealth / target.getMaxHealth() * (width - 42.0f) + 34.0f, 20.0f, target.getHealth() / target.getMaxHealth() * (width - 42.0f) + 34.0f, 28.0f, new Color(255, 255, 255).getRGB());
        }
    }

    private final void drawRomanticHead(IResourceLocation skin, int width, int height, float hurtPercent) {
        GL11.glColor4f((float)1.0f, (float)(1.0f - hurtPercent), (float)(1.0f - hurtPercent), (float)1.0f);
        MinecraftInstance.mc.getTextureManager().bindTexture(skin);
        Gui.func_152125_a((int)2, (int)2, (float)8.0f, (float)8.0f, (int)8, (int)8, (int)width, (int)height, (float)64.0f, (float)64.0f);
    }

    private final void drawSparklingWater(IEntityLivingBase target, float easingHealth) {
        RenderUtils.drawRoundedCornerRect(-1.5f, 2.5f, 152.5f, 52.5f, 5.0f, new Color(0, 0, 0, 26).getRGB());
        RenderUtils.drawRoundedCornerRect(-1.0f, 2.0f, 152.0f, 52.0f, 5.0f, new Color(0, 0, 0, 26).getRGB());
        RenderUtils.drawRoundedCornerRect(-0.5f, 1.5f, 151.5f, 51.5f, 5.0f, new Color(0, 0, 0, 40).getRGB());
        RenderUtils.drawRoundedCornerRect(-0.0f, 1.0f, 151.0f, 51.0f, 5.0f, new Color(0, 0, 0, 60).getRGB());
        RenderUtils.drawRoundedCornerRect(0.5f, 0.5f, 150.5f, 50.5f, 5.0f, new Color(0, 0, 0, 50).getRGB());
        RenderUtils.drawRoundedCornerRect(1.0f, 0.0f, 150.0f, 50.0f, 5.0f, new Color(0, 0, 0, 50).getRGB());
        if (target.getHurtTime() > 1) {
            GL11.glColor4f((float)1.0f, (float)0.0f, (float)0.0f, (float)0.5f);
            RenderUtils.drawEntityOnScreen(25, 48, 32, target);
        } else {
            GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
            RenderUtils.drawEntityOnScreen(25, 45, 30, target);
        }
        String string = String.valueOf(target.getName());
        Color color = Color.WHITE;
        Intrinsics.checkExpressionValueIsNotNull(color, "Color.WHITE");
        Fonts.font35.drawString(string, 45.0f, 6.0f, color.getRGB());
        DecimalFormat df = new DecimalFormat("0.00");
        Fonts.font30.drawString("Armor " + df.format(PlayerUtils.INSTANCE.getAr(target) * (double)100) + '%', 45.0f, 40.0f, new Color(200, 200, 200).getRGB());
        RenderUtils.drawRoundedCornerRect(45.0f, 23.0f, 145.0f, 33.0f, 5.0f, new Color(0, 0, 0, 100).getRGB());
        RenderUtils.drawRoundedCornerRect(45.0f, 23.0f, 45.0f + easingHealth / target.getMaxHealth() * 100.0f, 33.0f, 5.0f, ColorUtils.rainbow().getRGB());
        Fonts.font30.drawString(df.format(Float.valueOf(easingHealth / target.getMaxHealth() * (float)100)) + '%', 80.0f, 25.0f, new Color(255, 255, 255).getRGB(), true);
    }

    private final void drawAstolfo(IEntityLivingBase target, float nowAnimHP) {
        IFontRenderer font = (IFontRenderer)this.fontValue.get();
        Color color = RenderUtils.skyRainbow(1, 1.0f, 0.9f);
        float hpPct = nowAnimHP / target.getMaxHealth();
        RenderUtils.drawRect(0.0f, 0.0f, 140.0f, 60.0f, new Color(0, 0, 0, 110).getRGB());
        Color color2 = color;
        Intrinsics.checkExpressionValueIsNotNull(color2, "color");
        RenderUtils.drawRect(3.0f, 55.0f, 137.0f, 58.0f, ColorUtils.INSTANCE.reAlpha(color2, 100).getRGB());
        RenderUtils.drawRect(3.0f, 55.0f, (float)3 + hpPct * 134.0f, 58.0f, color.getRGB());
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        RenderUtils.drawEntityOnScreen(18, 46, 20, target);
        String string = target.getName();
        if (string == null) {
            Intrinsics.throwNpe();
        }
        font.drawStringWithShadow(string, 37, 6, -1);
        GL11.glPushMatrix();
        GL11.glScalef((float)2.0f, (float)2.0f, (float)2.0f);
        font.drawString(MathKt.roundToInt(this.getHealth(target)) + " \u2764", 19, 9, color.getRGB());
        GL11.glPopMatrix();
    }

    private final void drawNovo(IEntityLivingBase target, float nowAnimHP) {
        Color color;
        IFontRenderer font = (IFontRenderer)this.fontValue.get();
        Color color2 = color = BlendUtils.getHealthColor(this.getHealth(target), target.getMaxHealth());
        Intrinsics.checkExpressionValueIsNotNull(color2, "color");
        Color darkColor = ColorUtils.INSTANCE.darker(color2, 0.6f);
        float hpPos = 33.0f + (float)(MathKt.roundToInt(this.getHealth(target) / target.getMaxHealth() * (float)10000) / 100);
        RenderUtils.drawRect(0.0f, 0.0f, 140.0f, 40.0f, new Color(40, 40, 40).getRGB());
        String string = target.getName();
        if (string == null) {
            Intrinsics.throwNpe();
        }
        Color color3 = Color.WHITE;
        Intrinsics.checkExpressionValueIsNotNull(color3, "Color.WHITE");
        font.drawString(string, 33, 5, color3.getRGB());
        RenderUtils.drawEntityOnScreen(20, 35, 15, target);
        RenderUtils.drawRect(hpPos, 18.0f, 33.0f + (float)(MathKt.roundToInt(nowAnimHP / target.getMaxHealth() * (float)10000) / 100), 25.0f, darkColor);
        RenderUtils.drawRect(33.0f, 18.0f, hpPos, 25.0f, color);
        Color color4 = Color.RED;
        Intrinsics.checkExpressionValueIsNotNull(color4, "Color.RED");
        font.drawString("\u2764", 33, 30, color4.getRGB());
        String string2 = this.decimalFormat.format(Float.valueOf(this.getHealth(target)));
        Intrinsics.checkExpressionValueIsNotNull(string2, "decimalFormat.format(getHealth(target))");
        Color color5 = Color.WHITE;
        Intrinsics.checkExpressionValueIsNotNull(color5, "Color.WHITE");
        font.drawString(string2, 43, 30, color5.getRGB());
    }

    public final void drawHead(@NotNull IResourceLocation skin, int x, int y, int width, int height, float alpha) {
        Intrinsics.checkParameterIsNotNull(skin, "skin");
        GL11.glDisable((int)2929);
        GL11.glEnable((int)3042);
        GL11.glDepthMask((boolean)false);
        OpenGlHelper.func_148821_a((int)770, (int)771, (int)1, (int)0);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)alpha);
        MinecraftInstance.mc.getTextureManager().bindTexture(skin);
        Gui.func_152125_a((int)x, (int)y, (float)8.0f, (float)8.0f, (int)8, (int)8, (int)width, (int)height, (float)64.0f, (float)64.0f);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)2929);
    }

    public static /* synthetic */ void drawHead$default(Target2 target2, IResourceLocation iResourceLocation, int n, int n2, int n3, int n4, float f, int n5, Object object) {
        if ((n5 & 2) != 0) {
            n = 2;
        }
        if ((n5 & 4) != 0) {
            n2 = 2;
        }
        if ((n5 & 0x20) != 0) {
            f = 1.0f;
        }
        target2.drawHead(iResourceLocation, n, n2, n3, n4, f);
    }

    public final void drawHead(@NotNull IResourceLocation skin, float x, float y, float scale, int width, int height, float red, float green, float blue, float alpha) {
        Intrinsics.checkParameterIsNotNull(skin, "skin");
        GL11.glPushMatrix();
        GL11.glTranslatef((float)x, (float)y, (float)0.0f);
        GL11.glScalef((float)scale, (float)scale, (float)scale);
        GL11.glDisable((int)2929);
        GL11.glEnable((int)3042);
        GL11.glDepthMask((boolean)false);
        OpenGlHelper.func_148821_a((int)770, (int)771, (int)1, (int)0);
        GL11.glColor4f((float)RangesKt.coerceIn(red, 0.0f, 1.0f), (float)RangesKt.coerceIn(green, 0.0f, 1.0f), (float)RangesKt.coerceIn(blue, 0.0f, 1.0f), (float)RangesKt.coerceIn(alpha, 0.0f, 1.0f));
        MinecraftInstance.mc.getTextureManager().bindTexture(skin);
        Gui.func_152125_a((int)0, (int)0, (float)8.0f, (float)8.0f, (int)8, (int)8, (int)width, (int)height, (float)64.0f, (float)64.0f);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)2929);
        GL11.glPopMatrix();
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
    }

    public static /* synthetic */ void drawHead$default(Target2 target2, IResourceLocation iResourceLocation, float f, float f2, float f3, int n, int n2, float f4, float f5, float f6, float f7, int n3, Object object) {
        if ((n3 & 0x200) != 0) {
            f7 = 1.0f;
        }
        target2.drawHead(iResourceLocation, f, f2, f3, n, n2, f4, f5, f6, f7);
    }

    private final void drawHead2(IResourceLocation skin, int x, int y, int width, int height, float alpha) {
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)alpha);
        MinecraftInstance.mc.getTextureManager().bindTexture(skin);
        Gui.func_152125_a((int)x, (int)y, (float)8.0f, (float)8.0f, (int)8, (int)8, (int)width, (int)height, (float)64.0f, (float)64.0f);
    }

    private final void drawLiquid(IEntityLivingBase target, float easingHealth) {
        String string = target.getName();
        if (string == null) {
            Intrinsics.throwNpe();
        }
        float width = RangesKt.coerceAtLeast(38 + Fonts.font40.getStringWidth(string), 118);
        Color color = Color.BLACK;
        Intrinsics.checkExpressionValueIsNotNull(color, "Color.BLACK");
        int n = color.getRGB();
        Color color2 = Color.BLACK;
        Intrinsics.checkExpressionValueIsNotNull(color2, "Color.BLACK");
        RenderUtils.drawBorderedRect(0.0f, 0.0f, width, 36.0f, 3.0f, n, color2.getRGB());
        if (easingHealth > this.getHealth(target)) {
            RenderUtils.drawRect(0.0f, 34.0f, easingHealth / target.getMaxHealth() * width, 36.0f, new Color(252, 185, 65).getRGB());
        }
        RenderUtils.drawRect(0.0f, 34.0f, this.getHealth(target) / target.getMaxHealth() * width, 36.0f, new Color(252, 96, 66).getRGB());
        if (easingHealth < this.getHealth(target)) {
            RenderUtils.drawRect(easingHealth / target.getMaxHealth() * width, 34.0f, this.getHealth(target) / target.getMaxHealth() * width, 36.0f, new Color(44, 201, 144).getRGB());
        }
        String string2 = target.getName();
        boolean bl = false;
        boolean bl2 = false;
        String it = string2;
        boolean bl3 = false;
        String string3 = it;
        if (string3 == null) {
            Intrinsics.throwNpe();
        }
        Fonts.font40.drawString(string3, 36, 3, 0xFFFFFF);
        StringBuilder stringBuilder = new StringBuilder().append("Distance: ");
        IEntityPlayerSP iEntityPlayerSP = MinecraftInstance.mc.getThePlayer();
        if (iEntityPlayerSP == null) {
            Intrinsics.throwNpe();
        }
        Fonts.font35.drawString(stringBuilder.append(this.decimalFormat.format(PlayerExtensionKt.getDistanceToEntityBox(iEntityPlayerSP, target))).toString(), 36, 15, 0xFFFFFF);
        INetworkPlayerInfo iNetworkPlayerInfo = MinecraftInstance.mc.getNetHandler().getPlayerInfo(target.getUniqueID());
        if (iNetworkPlayerInfo == null) {
            Intrinsics.throwNpe();
        }
        RenderUtils.drawHead(iNetworkPlayerInfo.getLocationSkin(), 2, 2, 30, 30);
        INetworkPlayerInfo playerInfo = MinecraftInstance.mc.getNetHandler().getPlayerInfo(target.getUniqueID());
        if (playerInfo != null) {
            Fonts.font35.drawString("Ping: " + RangesKt.coerceAtLeast(playerInfo.getResponseTime(), 0), 36, 24, 0xFFFFFF);
        }
    }

    private final void drawZamorozka(IEntityLivingBase target, float easingHealth) {
        IFontRenderer font = (IFontRenderer)this.fontValue.get();
        RenderUtils.drawCircleRect(0.0f, 0.0f, 150.0f, 55.0f, 5.0f, new Color(0, 0, 0, 70).getRGB());
        RenderUtils.drawRect(7.0f, 7.0f, 35.0f, 40.0f, new Color(0, 0, 0, 70).getRGB());
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        RenderUtils.drawEntityOnScreen(21, 38, 15, target);
        float barLength = 136.0f;
        RenderUtils.drawCircleRect(7.0f, 45.0f, 143.0f, 50.0f, 2.5f, new Color(0, 0, 0, 70).getRGB());
        RenderUtils.drawCircleRect(7.0f, 45.0f, (float)7 + RangesKt.coerceAtLeast(easingHealth / target.getMaxHealth() * barLength, 5.0f), 50.0f, 2.5f, ColorUtils.INSTANCE.rainbowWithAlpha(90).getRGB());
        RenderUtils.drawCircleRect(7.0f, 45.0f, (float)7 + RangesKt.coerceAtLeast(target.getHealth() / target.getMaxHealth() * barLength, 5.0f), 50.0f, 2.5f, ColorUtils.rainbow().getRGB());
        RenderUtils.drawCircleRect(43.0f, 15.0f - (float)font.getFontHeight(), 143.0f, 17.0f, (float)(font.getFontHeight() + 1) * 0.45f, new Color(0, 0, 0, 70).getRGB());
        font.drawCenteredString(target.getName() + ' ' + (EntityUtils.INSTANCE.getPing(target.asEntityPlayer()) != -1 ? "\u00a7f" + EntityUtils.INSTANCE.getPing(target.asEntityPlayer()) + "ms" : ""), 93.0f, 16.0f - (float)font.getFontHeight(), ColorUtils.rainbow().getRGB(), false);
        String string = "Health: " + this.decimalFormat.format(Float.valueOf(easingHealth)) + " \u00a77/ " + this.decimalFormat.format(Float.valueOf(target.getMaxHealth()));
        int n = 11 + font.getFontHeight();
        Color color = Color.WHITE;
        Intrinsics.checkExpressionValueIsNotNull(color, "Color.WHITE");
        font.drawString(string, 43, n, color.getRGB());
        StringBuilder stringBuilder = new StringBuilder().append("Distance: ");
        IEntityPlayerSP iEntityPlayerSP = MinecraftInstance.mc.getThePlayer();
        if (iEntityPlayerSP == null) {
            Intrinsics.throwNpe();
        }
        String string2 = stringBuilder.append(this.decimalFormat.format(PlayerExtensionKt.getDistanceToEntityBox(iEntityPlayerSP, target))).toString();
        int n2 = 11 + font.getFontHeight() * 2;
        Color color2 = Color.WHITE;
        Intrinsics.checkExpressionValueIsNotNull(color2, "Color.WHITE");
        font.drawString(string2, 43, n2, color2.getRGB());
    }

    /*
     * WARNING - void declaration
     */
    private final void drawMoon(IEntityLivingBase target, float easingHealth) {
        IFontRenderer font = (IFontRenderer)this.fontValue.get();
        String hp = this.decimalFormat.format(Float.valueOf(easingHealth));
        int additionalWidth = RangesKt.coerceAtLeast(font.getStringWidth(target.getName() + "  " + hp + " hp"), 75);
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glShadeModel((int)7425);
        float yPos = (float)(5 + font.getFontHeight()) + 3.0f;
        float f = 5;
        String string = this.decimalFormat.format(Float.valueOf(target.getMaxHealth()));
        Intrinsics.checkExpressionValueIsNotNull(string, "decimalFormat.format(target.maxHealth)");
        int stopPos = (int)(f + (float)(135 - font.getStringWidth(string)) * (easingHealth / target.getMaxHealth()));
        int n = 5;
        IntProgression intProgression = RangesKt.step(new IntRange(n, stopPos), 5);
        int n2 = intProgression.getFirst();
        int n3 = intProgression.getLast();
        int n4 = intProgression.getStep();
        int n5 = n2;
        int n6 = n3;
        if (n4 >= 0 ? n5 <= n6 : n5 >= n6) {
            while (true) {
                void i;
                double x1 = RangesKt.coerceAtMost((int)(i + 5), stopPos);
                RenderUtils.quickDrawGradientSideways((double)i - 5.0, 0.0, 45.0 + (double)additionalWidth - 1.0, 1.0, ColorUtils.hslRainbow$default(ColorUtils.INSTANCE, (int)i, 0.0f, 0.0f, 10, 0, 22, null).getRGB(), ColorUtils.hslRainbow$default(ColorUtils.INSTANCE, (int)x1, 0.0f, 0.0f, 0, 0, 22, null).getRGB());
                if (i == n3) break;
                i += n4;
            }
        }
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
        GL11.glDisable((int)2848);
        GL11.glShadeModel((int)7424);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        RenderUtils.drawRect(37.0f, yPos + (float)5, 37.0f + (float)additionalWidth, yPos + (float)13, new Color(0, 0, 0, 100).getRGB());
        if (target.getHealth() <= target.getMaxHealth()) {
            RenderUtils.drawCircleRect(37.0f, yPos + (float)5, 37.0f + (float)(MathKt.roundToInt(easingHealth / target.getMaxHealth() * (float)8100) / 100), yPos + (float)13, 3.0f, new Color(0, 255, 0).getRGB());
        }
        if (target.getHealth() < target.getMaxHealth() / (float)2) {
            RenderUtils.drawCircleRect(37.0f, yPos + (float)5, 37.0f + (float)(MathKt.roundToInt(easingHealth / target.getMaxHealth() * (float)8100) / 100), yPos + (float)13, 3.0f, new Color(255, 255, 0).getRGB());
        }
        if (target.getHealth() < target.getMaxHealth() / (float)4) {
            RenderUtils.drawCircleRect(37.0f, yPos + (float)5, 37.0f + (float)(MathKt.roundToInt(easingHealth / target.getMaxHealth() * (float)8100) / 100), yPos + (float)13, 3.0f, new Color(255, 0, 0).getRGB());
        }
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
        GL11.glDisable((int)2848);
        GL11.glShadeModel((int)7424);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        String string2 = target.getName();
        if (string2 == null) {
            Intrinsics.throwNpe();
        }
        Color color = Color.WHITE;
        Intrinsics.checkExpressionValueIsNotNull(color, "Color.WHITE");
        font.drawString(string2, 37, 5, color.getRGB());
        INetworkPlayerInfo iNetworkPlayerInfo = MinecraftInstance.mc.getNetHandler().getPlayerInfo(target.getUniqueID());
        if (iNetworkPlayerInfo == null) {
            Intrinsics.throwNpe();
        }
        RenderUtils.drawHead(iNetworkPlayerInfo.getLocationSkin(), 2, 2, 32, 32);
        GL11.glScaled((double)0.7, (double)0.7, (double)0.7);
        String string3 = hp + " hp";
        n3 = 0;
        n4 = 0;
        String it = string3;
        boolean bl = false;
        Color color2 = Color.LIGHT_GRAY;
        Intrinsics.checkExpressionValueIsNotNull(color2, "Color.LIGHT_GRAY");
        font.drawString(it, 53, 23, color2.getRGB());
    }

    /*
     * WARNING - void declaration
     */
    private final void drawRise(IEntityLivingBase target, float easingHealth) {
        IFontRenderer font = (IFontRenderer)this.fontValue.get();
        RenderUtils.drawCircleRect(0.0f, 0.0f, 150.0f, 50.0f, 5.0f, new Color(0, 0, 0, 130).getRGB());
        float hurtPercent = PlayerExtensionKt.getHurtPercent(target);
        float scale = hurtPercent == 0.0f ? 1.0f : (hurtPercent < 0.5f ? 1.0f - 0.2f * hurtPercent * (float)2 : 0.8f + 0.2f * (hurtPercent - 0.5f) * (float)2);
        int size = 30;
        GL11.glPushMatrix();
        GL11.glTranslatef((float)5.0f, (float)5.0f, (float)0.0f);
        GL11.glScalef((float)scale, (float)scale, (float)scale);
        GL11.glTranslatef((float)((float)size * 0.5f * (1.0f - scale) / scale), (float)((float)size * 0.5f * (1.0f - scale) / scale), (float)0.0f);
        GL11.glColor4f((float)1.0f, (float)(1.0f - hurtPercent), (float)(1.0f - hurtPercent), (float)1.0f);
        INetworkPlayerInfo iNetworkPlayerInfo = MinecraftInstance.mc.getNetHandler().getPlayerInfo(target.getUniqueID());
        if (iNetworkPlayerInfo == null) {
            Intrinsics.throwNpe();
        }
        RenderUtils.quickDrawHead(iNetworkPlayerInfo.getLocationSkin(), 0, 0, size, size);
        GL11.glPopMatrix();
        String string = "Name " + target.getName();
        Color color = Color.WHITE;
        Intrinsics.checkExpressionValueIsNotNull(color, "Color.WHITE");
        font.drawString(string, 40, 11, color.getRGB());
        StringBuilder stringBuilder = new StringBuilder().append("Distance ");
        IEntityPlayerSP iEntityPlayerSP = MinecraftInstance.mc.getThePlayer();
        if (iEntityPlayerSP == null) {
            Intrinsics.throwNpe();
        }
        String string2 = stringBuilder.append(this.decimalFormat.format(PlayerExtensionKt.getDistanceToEntityBox(iEntityPlayerSP, target))).append(" Hurt ").append(target.getHurtTime()).toString();
        int n = 11 + font.getFontHeight();
        Color color2 = Color.WHITE;
        Intrinsics.checkExpressionValueIsNotNull(color2, "Color.WHITE");
        font.drawString(string2, 40, n, color2.getRGB());
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glShadeModel((int)7425);
        drawRise.1 $fun$renderSideway$1 = drawRise.1.INSTANCE;
        float f = 5;
        String string3 = this.decimalFormat.format(Float.valueOf(target.getMaxHealth()));
        Intrinsics.checkExpressionValueIsNotNull(string3, "decimalFormat.format(target.maxHealth)");
        int stopPos = (int)(f + (float)(135 - font.getStringWidth(string3)) * (easingHealth / target.getMaxHealth()));
        int n2 = 5;
        IntProgression intProgression = RangesKt.step(new IntRange(n2, stopPos), 5);
        int n3 = intProgression.getFirst();
        int n4 = intProgression.getLast();
        int n5 = intProgression.getStep();
        int n6 = n3;
        int n7 = n4;
        if (n5 >= 0 ? n6 <= n7 : n6 >= n7) {
            while (true) {
                void i;
                $fun$renderSideway$1.invoke((int)i, RangesKt.coerceAtMost((int)(i + 5), stopPos));
                if (i == n4) break;
                i += n5;
            }
        }
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
        GL11.glDisable((int)2848);
        GL11.glShadeModel((int)7424);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        String string4 = this.decimalFormat.format(Float.valueOf(easingHealth));
        Intrinsics.checkExpressionValueIsNotNull(string4, "decimalFormat.format(easingHealth)");
        int n8 = 43 - font.getFontHeight() / 2;
        Color color3 = Color.WHITE;
        Intrinsics.checkExpressionValueIsNotNull(color3, "Color.WHITE");
        font.drawString(string4, stopPos + 5, n8, color3.getRGB());
    }

    private final void drawBest(IEntityLivingBase target, float easingHealth) {
        IFontRenderer font = (IFontRenderer)this.fontValue.get();
        float f = 60;
        IFontRenderer iFontRenderer = MinecraftInstance.mc.getFontRendererObj();
        String string = target.getName();
        if (string == null) {
            Intrinsics.throwNpe();
        }
        float addedLen = f + (float)iFontRenderer.getStringWidth(string) * 1.6f;
        RenderUtils.drawRect(0.0f, 0.0f, addedLen, 47.0f, new Color(0, 0, 0, 120).getRGB());
        RenderUtils.drawRoundedCornerRect(0.0f, 0.0f, easingHealth / target.getMaxHealth() * addedLen, 47.0f, 3.0f, new Color(255, 255, 255, 90).getRGB());
        RenderUtils.drawShadowWithCustomAlpha(0.0f, 0.0f, addedLen, 47.0f, 200.0f);
        float hurtPercent = PlayerExtensionKt.getHurtPercent(target);
        float scale = hurtPercent == 0.0f ? 1.0f : (hurtPercent < 0.5f ? 1.0f - 0.1f * hurtPercent * (float)2 : 0.9f + 0.1f * (hurtPercent - 0.5f) * (float)2);
        int size = 35;
        GL11.glPushMatrix();
        GL11.glTranslatef((float)5.0f, (float)5.0f, (float)0.0f);
        GL11.glScalef((float)scale, (float)scale, (float)scale);
        GL11.glTranslatef((float)((float)size * 0.5f * (1.0f - scale) / scale), (float)((float)size * 0.5f * (1.0f - scale) / scale), (float)0.0f);
        GL11.glColor4f((float)1.0f, (float)(1.0f - hurtPercent), (float)(1.0f - hurtPercent), (float)1.0f);
        INetworkPlayerInfo iNetworkPlayerInfo = MinecraftInstance.mc.getNetHandler().getPlayerInfo(target.getUniqueID());
        if (iNetworkPlayerInfo == null) {
            Intrinsics.throwNpe();
        }
        this.drawHead2(iNetworkPlayerInfo.getLocationSkin(), 0, 0, size, size, 255.0f);
        GL11.glPopMatrix();
        GL11.glPushMatrix();
        GL11.glScalef((float)1.5f, (float)1.5f, (float)1.5f);
        String string2 = target.getName();
        if (string2 == null) {
            Intrinsics.throwNpe();
        }
        Color color = Color.WHITE;
        Intrinsics.checkExpressionValueIsNotNull(color, "Color.WHITE");
        font.drawString(string2, 39, 8, color.getRGB());
        GL11.glPopMatrix();
        String string3 = "Health " + MathKt.roundToInt(target.getHealth());
        int n = 20 + (int)((double)font.getFontHeight() * 1.5);
        Color color2 = Color.WHITE;
        Intrinsics.checkExpressionValueIsNotNull(color2, "Color.WHITE");
        font.drawString(string3, 56, n, color2.getRGB());
    }

    private final void drawFlux(IEntityLivingBase target, float nowAnimHP) {
        String string = target.getName();
        if (string == null) {
            Intrinsics.throwNpe();
        }
        float width = RangesKt.coerceAtLeast(38 + Fonts.font40.getStringWidth(string), 70);
        RenderUtils.drawRect(0.0f, 0.0f, width, 34.0f, new Color(40, 40, 40).getRGB());
        Color color = Color.BLACK;
        Intrinsics.checkExpressionValueIsNotNull(color, "Color.BLACK");
        RenderUtils.drawRect(2.0f, 22.0f, width - 2.0f, 24.0f, color.getRGB());
        Color color2 = Color.BLACK;
        Intrinsics.checkExpressionValueIsNotNull(color2, "Color.BLACK");
        RenderUtils.drawRect(2.0f, 28.0f, width - 2.0f, 30.0f, color2.getRGB());
        RenderUtils.drawRect(2.0f, 22.0f, (float)2 + nowAnimHP / target.getMaxHealth() * (width - (float)4), 24.0f, new Color(231, 182, 0).getRGB());
        RenderUtils.drawRect(2.0f, 22.0f, (float)2 + this.getHealth(target) / target.getMaxHealth() * (width - (float)4), 24.0f, new Color(0, 224, 84).getRGB());
        RenderUtils.drawRect(2.0f, 28.0f, (float)2 + (float)target.getTotalArmorValue() / 20.0f * (width - (float)4), 30.0f, new Color(77, 128, 255).getRGB());
        String string2 = target.getName();
        if (string2 == null) {
            Intrinsics.throwNpe();
        }
        Color color3 = Color.WHITE;
        Intrinsics.checkExpressionValueIsNotNull(color3, "Color.WHITE");
        Fonts.font40.drawString(string2, 22, 3, color3.getRGB());
        GL11.glPushMatrix();
        GL11.glScaled((double)0.7, (double)0.7, (double)0.7);
        String string3 = "Health: " + this.decimalFormat.format(Float.valueOf(this.getHealth(target)));
        float f = (float)(4 + Fonts.font40.getFontHeight()) / 0.7f;
        Color color4 = Color.WHITE;
        Intrinsics.checkExpressionValueIsNotNull(color4, "Color.WHITE");
        Fonts.font35.drawString(string3, 31.428572f, f, color4.getRGB());
        GL11.glPopMatrix();
        INetworkPlayerInfo iNetworkPlayerInfo = MinecraftInstance.mc.getNetHandler().getPlayerInfo(target.getUniqueID());
        if (iNetworkPlayerInfo == null) {
            Intrinsics.throwNpe();
        }
        RenderUtils.drawHead(iNetworkPlayerInfo.getLocationSkin(), 2, 2, 16, 16);
    }

    private final void drawnovoline2(IEntityLivingBase target, float easingHealth) {
        String string = target.getName();
        if (string == null) {
            Intrinsics.throwNpe();
        }
        float width = RangesKt.coerceAtLeast(38 + Fonts.font40.getStringWidth(string), 118);
        RenderUtils.drawRect(0.0f, 0.0f, width + 14.0f, 44.0f, new Color(0, 0, 0, ((Number)this.backgroundalpha.get()).intValue()).getRGB());
        INetworkPlayerInfo iNetworkPlayerInfo = MinecraftInstance.mc.getNetHandler().getPlayerInfo(target.getUniqueID());
        if (iNetworkPlayerInfo == null) {
            Intrinsics.throwNpe();
        }
        RenderUtils.drawHead(iNetworkPlayerInfo.getLocationSkin(), 3, 3, 30, 30);
        String string2 = target.getName();
        if (string2 == null) {
            Intrinsics.throwNpe();
        }
        Color color = Color.WHITE;
        Intrinsics.checkExpressionValueIsNotNull(color, "Color.WHITE");
        Fonts.font40.drawString(string2, 34.5f, 4.0f, color.getRGB());
        String string3 = "Health: " + this.decimalFormat.format(Float.valueOf(target.getHealth()));
        Color color2 = Color.WHITE;
        Intrinsics.checkExpressionValueIsNotNull(color2, "Color.WHITE");
        Fonts.font40.drawString(string3, 34.5f, 14.0f, color2.getRGB());
        StringBuilder stringBuilder = new StringBuilder().append("Distance: ");
        IEntityPlayerSP iEntityPlayerSP = MinecraftInstance.mc.getThePlayer();
        if (iEntityPlayerSP == null) {
            Intrinsics.throwNpe();
        }
        String string4 = stringBuilder.append(this.decimalFormat.format(Float.valueOf(iEntityPlayerSP.getDistanceToEntity(target)))).append('m').toString();
        Color color3 = Color.WHITE;
        Intrinsics.checkExpressionValueIsNotNull(color3, "Color.WHITE");
        Fonts.font40.drawString(string4, 34.5f, 24.0f, color3.getRGB());
        RenderUtils.drawRect(2.5f, 35.5f, width + 11.5f, 37.5f, new Color(0, 0, 0, 200).getRGB());
        RenderUtils.drawRect(3.0f, 36.0f, 3.0f + easingHealth / target.getMaxHealth() * (width + 8.0f), 37.0f, new Color(((Number)this.redValue.get()).intValue(), ((Number)this.greenValue.get()).intValue(), ((Number)this.blueValue.get()).intValue()).getRGB());
        RenderUtils.drawRect(2.5f, 39.5f, width + 11.5f, 41.5f, new Color(0, 0, 0, 200).getRGB());
        RenderUtils.drawRect(3.0f, 40.0f, 3.0f + (float)target.getTotalArmorValue() / 20.0f * (width + 8.0f), 41.0f, new Color(77, 128, 255).getRGB());
    }

    private final void drawnovoline3(IEntityLivingBase target, float easingHealth) {
        Color mainColor = new Color(((Number)this.redValue.get()).intValue(), ((Number)this.greenValue.get()).intValue(), ((Number)this.blueValue.get()).intValue());
        int percent = (int)target.getHealth();
        String string = target.getName();
        if (string == null) {
            Intrinsics.throwNpe();
        }
        float nameLength = (float)RangesKt.coerceAtLeast(Fonts.font40.getStringWidth(string), Fonts.font40.getStringWidth(String.valueOf(this.decimalFormat.format((Object)percent)))) + 20.0f;
        float barWidth = RangesKt.coerceIn(target.getHealth() / target.getMaxHealth(), 0.0f, target.getMaxHealth()) * (nameLength - 2.0f);
        RenderUtils.drawRect(-2.0f, -2.0f, 3.0f + nameLength + 36.0f, 38.0f, new Color(50, 50, 50, 150).getRGB());
        RenderUtils.drawRect(-1.0f, -1.0f, 2.0f + nameLength + 36.0f, 37.0f, new Color(0, 0, 0, 100).getRGB());
        INetworkPlayerInfo iNetworkPlayerInfo = MinecraftInstance.mc.getNetHandler().getPlayerInfo(target.getUniqueID());
        if (iNetworkPlayerInfo == null) {
            Intrinsics.throwNpe();
        }
        RenderUtils.drawHead(iNetworkPlayerInfo.getLocationSkin(), 0, 0, 36, 36);
        String string2 = target.getName();
        if (string2 == null) {
            Intrinsics.throwNpe();
        }
        Fonts.minecraftFont.drawStringWithShadow(string2, 38, 2, -1);
        RenderUtils.drawRect(37.0f, 14.0f, 37.0f + nameLength, 24.0f, new Color(0, 0, 0, 200).getRGB());
        float animateThingy = RangesKt.coerceIn(easingHealth, target.getHealth(), target.getMaxHealth()) / target.getMaxHealth() * (nameLength - 2.0f);
        if (easingHealth > target.getHealth()) {
            Color color = mainColor.darker();
            Intrinsics.checkExpressionValueIsNotNull(color, "mainColor.darker()");
            RenderUtils.drawRect(38.0f, 15.0f, 38.0f + animateThingy, 23.0f, color.getRGB());
        }
        RenderUtils.drawRect(38.0f, 15.0f, 38.0f + barWidth, 23.0f, mainColor.getRGB());
        String string3 = String.valueOf(this.decimalFormat.format((Object)percent));
        Color color = Color.WHITE;
        Intrinsics.checkExpressionValueIsNotNull(color, "Color.WHITE");
        Fonts.minecraftFont.drawStringWithShadow(string3, 38, 26, color.getRGB());
    }

    private final void drawnewnovo(IEntityLivingBase target, float easingHealth) {
        String string = target.getName();
        if (string == null) {
            Intrinsics.throwNpe();
        }
        float width = RangesKt.coerceAtLeast(38 + Fonts.minecraftFont.getStringWidth(string), 118);
        this.counter1[0] = this.counter1[0] + 1;
        this.counter2[0] = this.counter2[0] + 1;
        this.counter1[0] = RangesKt.coerceIn(this.counter1[0], 0, 50);
        this.counter2[0] = RangesKt.coerceIn(this.counter2[0], 0, 80);
        RenderUtils.drawRect(0.0f, 0.0f, width, 34.5f, new Color(0, 0, 0, ((Number)this.backgroundalpha.get()).intValue()));
        Color customColor = new Color(((Number)this.redValue.get()).intValue(), ((Number)this.greenValue.get()).intValue(), ((Number)this.blueValue.get()).intValue(), 255);
        Color customColor1 = new Color(((Number)this.gredValue.get()).intValue(), ((Number)this.ggreenValue.get()).intValue(), ((Number)this.gblueValue.get()).intValue(), 255);
        RenderUtils.drawGradientSideways(34.0, 16.0, (double)width - (double)2, 24.0, new Color(40, 40, 40, 220).getRGB(), new Color(60, 60, 60, 255).getRGB());
        double d = (double)(36.0f + easingHealth / target.getMaxHealth() * (width - 36.0f)) - (double)2;
        Color color = Palette.fade2(customColor, this.counter1[0], Fonts.font35.getFontHeight());
        Intrinsics.checkExpressionValueIsNotNull(color, "Palette.fade2(customColo\u2026,Fonts.font35.fontHeight)");
        int n = color.getRGB();
        Color color2 = Palette.fade2(customColor1, this.counter2[0], Fonts.font35.getFontHeight());
        Intrinsics.checkExpressionValueIsNotNull(color2, "Palette.fade2(customColo\u2026 Fonts.font35.fontHeight)");
        RenderUtils.drawGradientSideways(34.0, 16.0, d, 24.0, n, color2.getRGB());
        String string2 = target.getName();
        if (string2 == null) {
            Intrinsics.throwNpe();
        }
        Fonts.minecraftFont.drawString(string2, 34, 4, new Color(255, 255, 255, 255).getRGB());
        INetworkPlayerInfo iNetworkPlayerInfo = MinecraftInstance.mc.getNetHandler().getPlayerInfo(target.getUniqueID());
        if (iNetworkPlayerInfo == null) {
            Intrinsics.throwNpe();
        }
        RenderUtils.drawHead(iNetworkPlayerInfo.getLocationSkin(), 2, 2, 30, 30);
        String string3 = new BigDecimal(target.getHealth() / target.getMaxHealth() * (float)100).setScale(1, 4).toString() + "%";
        int n2 = (int)(width / (float)2 + (float)5);
        Color color3 = Color.white;
        Intrinsics.checkExpressionValueIsNotNull(color3, "Color.white");
        Fonts.minecraftFont.drawStringWithShadow(string3, n2, 17, color3.getRGB());
    }

    private final void drawTenacity(IEntityLivingBase target, float easingHealth) {
        IFontRenderer font = (IFontRenderer)this.fontValue.get();
        String string = target.getName();
        if (string == null) {
            Intrinsics.throwNpe();
        }
        int additionalWidth = RangesKt.coerceAtLeast(font.getStringWidth(string), 75);
        float hurtPercent = PlayerExtensionKt.getHurtPercent(target);
        RenderUtils.drawRoundedCornerRect(0.0f, 5.0f, 59.0f + (float)additionalWidth, 45.0f, 6.0f, ColorUtils.rainbow().getRGB());
        float scale = hurtPercent == 0.0f ? 1.0f : (hurtPercent < 0.5f ? 1.0f - 0.1f * hurtPercent * (float)2 : 0.9f + 0.1f * (hurtPercent - 0.5f) * (float)2);
        int size = 35;
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GL11.glPushMatrix();
        GL11.glTranslatef((float)5.0f, (float)5.0f, (float)0.0f);
        GL11.glScalef((float)scale, (float)scale, (float)scale);
        GL11.glTranslatef((float)((float)size * 0.5f * (1.0f - scale) / scale), (float)((float)size * 0.5f * (1.0f - scale) / scale), (float)0.0f);
        GL11.glColor4f((float)1.0f, (float)(1.0f - hurtPercent), (float)(1.0f - hurtPercent), (float)1.0f);
        ITextureManager iTextureManager = MinecraftInstance.mc.getTextureManager();
        INetworkPlayerInfo iNetworkPlayerInfo = MinecraftInstance.mc.getNetHandler().getPlayerInfo(target.getUniqueID());
        if (iNetworkPlayerInfo == null) {
            Intrinsics.throwNpe();
        }
        iTextureManager.bindTexture(iNetworkPlayerInfo.getLocationSkin());
        RenderUtils.drawScaledCustomSizeModalCircle(5, 5, 8.0f, 8.0f, 8, 8, 30, 30, 64.0f, 64.0f);
        RenderUtils.drawScaledCustomSizeModalCircle(5, 5, 40.0f, 8.0f, 8, 8, 30, 30, 64.0f, 64.0f);
        GL11.glPopMatrix();
        String string2 = target.getName();
        if (string2 == null) {
            Intrinsics.throwNpe();
        }
        float f = (float)45 + (float)additionalWidth / 2.0f;
        float f2 = 1.0f + (float)font.getFontHeight();
        Color color = Color.WHITE;
        Intrinsics.checkExpressionValueIsNotNull(color, "Color.WHITE");
        font.drawCenteredString(string2, f, f2, color.getRGB(), false);
        StringBuilder stringBuilder = new StringBuilder().append(String.valueOf(MathKt.roundToInt(easingHealth / target.getMaxHealth() * (float)100))).append(" - ");
        IEntityPlayerSP iEntityPlayerSP = MinecraftInstance.mc.getThePlayer();
        if (iEntityPlayerSP == null) {
            Intrinsics.throwNpe();
        }
        String infoStr = stringBuilder.append(String.valueOf(MathKt.roundToInt(PlayerExtensionKt.getDistanceToEntityBox(iEntityPlayerSP, target)))).append("M").toString();
        float f3 = 45.0f + (float)(additionalWidth - font.getStringWidth(infoStr)) / 2.0f;
        float f4 = 2.0f + (float)(font.getFontHeight() + font.getFontHeight());
        Color color2 = Color.WHITE;
        Intrinsics.checkExpressionValueIsNotNull(color2, "Color.WHITE");
        font.drawString(infoStr, f3, f4, color2.getRGB(), false);
        RenderUtils.drawRoundedCornerRect(44.0f, 32.0f, 44.0f + (float)additionalWidth, 38.0f, 2.5f, new Color(60, 60, 60, 130).getRGB());
        RenderUtils.drawRoundedCornerRect(44.0f, 32.0f, 44.0f + easingHealth / target.getMaxHealth() * (float)additionalWidth, 38.0f, 2.5f, new Color(240, 240, 240, 250).getRGB());
    }

    private final Border getTBorder() {
        Border border;
        String string = (String)this.modeValue.get();
        boolean bl = false;
        String string2 = string;
        if (string2 == null) {
            throw new TypeCastException("null cannot be cast to non-null type java.lang.String");
        }
        String string3 = string2.toLowerCase();
        Intrinsics.checkExpressionValueIsNotNull(string3, "(this as java.lang.String).toLowerCase()");
        switch (string3) {
            case "novoline": {
                border = new Border(0.0f, 0.0f, 140.0f, 40.0f);
                break;
            }
            case "rice": {
                border = new Border(0.0f, 0.0f, 135.0f, 55.0f);
                break;
            }
            case "astolfo": {
                border = new Border(0.0f, 0.0f, 140.0f, 60.0f);
                break;
            }
            case "liquid": {
                float f = 38;
                IEntityPlayerSP iEntityPlayerSP = MinecraftInstance.mc.getThePlayer();
                if (iEntityPlayerSP == null) {
                    Intrinsics.throwNpe();
                }
                String string4 = iEntityPlayerSP.getName();
                if (string4 == null) {
                    Intrinsics.throwNpe();
                }
                border = new Border(0.0f, 0.0f, f + (float)RangesKt.coerceAtLeast(Fonts.font40.getStringWidth(string4), 118), 36.0f);
                break;
            }
            case "flux": {
                IEntityPlayerSP iEntityPlayerSP = MinecraftInstance.mc.getThePlayer();
                if (iEntityPlayerSP == null) {
                    Intrinsics.throwNpe();
                }
                String string5 = iEntityPlayerSP.getName();
                if (string5 == null) {
                    Intrinsics.throwNpe();
                }
                border = new Border(0.0f, 0.0f, RangesKt.coerceAtLeast(38 + Fonts.font40.getStringWidth(string5), 70), 34.0f);
                break;
            }
            case "rise": {
                border = new Border(0.0f, 0.0f, 150.0f, 55.0f);
                break;
            }
            case "zamorozka": {
                border = new Border(0.0f, 0.0f, 150.0f, 55.0f);
                break;
            }
            case "exhibition": {
                border = new Border(0.0f, 0.0f, 140.0f, 45.0f);
                break;
            }
            case "best": {
                border = new Border(0.0f, 0.0f, 150.0f, 47.0f);
                break;
            }
            case "novoline2": {
                border = new Border(0.0f, 0.0f, 140.0f, 40.0f);
                break;
            }
            case "novoline3": {
                border = new Border(0.0f, 0.0f, 140.0f, 40.0f);
                break;
            }
            case "newnovoline": {
                border = new Border(0.0f, 0.0f, 140.0f, 40.0f);
                break;
            }
            case "moon": {
                border = new Border(0.0f, 0.0f, 140.0f, 40.0f);
                break;
            }
            case "tenacity5": {
                IEntityPlayerSP iEntityPlayerSP = MinecraftInstance.mc.getThePlayer();
                if (iEntityPlayerSP == null) {
                    Intrinsics.throwNpe();
                }
                String string6 = String.valueOf(iEntityPlayerSP.getName());
                IFontRenderer iFontRenderer = Fonts.font40;
                float f = 62.0f;
                float f2 = 3.0f;
                float f3 = -2.0f;
                boolean bl2 = false;
                boolean bl3 = false;
                String p1 = string6;
                boolean bl4 = false;
                int n = iFontRenderer.getStringWidth(p1);
                float f4 = 50.0f;
                float f5 = f + (float)RangesKt.coerceAtLeast(n, 75);
                float f6 = f2;
                float f7 = f3;
                border = new Border(f7, f6, f5, f4);
                break;
            }
            case "romantic": {
                border = new Border(0.0f, 0.0f, 120.0f, 36.0f);
                break;
            }
            case "watermelon": {
                border = new Border(0.0f, 0.0f, 120.0f, 48.0f);
                break;
            }
            case "sparklingwater": {
                border = new Border(0.0f, 0.0f, 120.0f, 48.0f);
                break;
            }
            case "tenacity": {
                border = new Border(0.0f, 0.0f, 140.0f, 40.0f);
                break;
            }
            default: {
                border = null;
            }
        }
        return border;
    }

    public Target2() {
        super(0.0, 0.0, 1.0f, new Side(Side.Horizontal.MIDDLE, Side.Vertical.MIDDLE));
        List list;
        IFontRenderer iFontRenderer = Fonts.font40;
        Intrinsics.checkExpressionValueIsNotNull(iFontRenderer, "Fonts.font40");
        this.fontValue = new FontValue("Font", iFontRenderer);
        this.backgroundalpha = new IntegerValue("Alpha", 120, 0, 255);
        this.redValue = new IntegerValue("Red", 255, 0, 255);
        this.greenValue = new IntegerValue("Green", 255, 0, 255);
        this.blueValue = new IntegerValue("Blue", 255, 0, 255);
        this.gredValue = new IntegerValue("GradientRed", 255, 0, 255);
        this.ggreenValue = new IntegerValue("GradientGreen", 255, 0, 255);
        this.gblueValue = new IntegerValue("GradientBlue", 255, 0, 255);
        this.colorModeValue = new ListValue("Color", new String[]{"Custom", "Rainbow", "Sky", "Slowly", "Fade", "Health"}, "Health");
        this.saturationValue = new FloatValue("Saturation", 1.0f, 0.0f, 1.0f);
        this.brightnessValue = new FloatValue("Brightness", 1.0f, 0.0f, 1.0f);
        this.bgRedValue = new IntegerValue("Background-Red", 0, 0, 255);
        this.bgGreenValue = new IntegerValue("Background-Green", 0, 0, 255);
        this.bgBlueValue = new IntegerValue("Background-Blue", 0, 0, 255);
        this.bgAlphaValue = new IntegerValue("Background-Alpha", 160, 0, 255);
        this.gradientLoopValue = new IntegerValue("GradientLoop", 4, 1, 40);
        this.gradientDistanceValue = new IntegerValue("GradientDistance", 50, 1, 200);
        this.gradientRoundedBarValue = new BoolValue("GradientRoundedBar", false);
        this.riceParticle = new BoolValue("Rice-Particle", true);
        this.riceParticleSpin = new BoolValue("Rice-ParticleSpin", true);
        this.generateAmountValue = new IntegerValue("GenerateAmount", 10, 1, 40);
        this.riceParticleCircle = new ListValue("Circle-Particles", new String[]{"Outline", "Solid", "None"}, "Solid");
        this.riceParticleRect = new ListValue("Rect-Particles", new String[]{"Outline", "Solid", "None"}, "Outline");
        this.riceParticleTriangle = new ListValue("Triangle-Particles", new String[]{"Outline", "Solid", "None"}, "Outline");
        this.riceParticleSpeed = new FloatValue("Rice-ParticleSpeed", 0.05f, 0.01f, 0.2f);
        this.riceParticleFade = new BoolValue("Rice-ParticleFade", true);
        this.riceParticleFadingSpeed = new FloatValue("ParticleFadingSpeed", 0.05f, 0.01f, 0.2f);
        this.rainbowSpeed = new IntegerValue("RainbowSpeed", 1, 1, 10);
        this.particleRange = new FloatValue("Rice-ParticleRange", 50.0f, 0.0f, 50.0f);
        this.minParticleSize = new FloatValue(this, "MinParticleSize", 0.5f, 0.0f, 5.0f){
            final /* synthetic */ Target2 this$0;

            protected void onChanged(float oldValue, float newValue) {
                float v = ((Number)this.this$0.getMaxParticleSize().get()).floatValue();
                if (v < newValue) {
                    this.set(Float.valueOf(v));
                }
            }
            {
                this.this$0 = $outer;
                super($super_call_param$1, $super_call_param$2, $super_call_param$3, $super_call_param$4);
            }
        };
        this.maxParticleSize = new FloatValue(this, "MaxParticleSize", 2.5f, 0.0f, 5.0f){
            final /* synthetic */ Target2 this$0;

            protected void onChanged(float oldValue, float newValue) {
                float v = ((Number)this.this$0.getMinParticleSize().get()).floatValue();
                if (v > newValue) {
                    this.set(Float.valueOf(v));
                }
            }
            {
                this.this$0 = $outer;
                super($super_call_param$1, $super_call_param$2, $super_call_param$3, $super_call_param$4);
            }
        };
        this.barColor = new Color(-1);
        this.bgColor = new Color(-1);
        Target2 target2 = this;
        boolean bl = false;
        target2.particleList = list = (List)new ArrayList();
        this.lastHealth = 20.0f;
        this.lastChangeHealth = 20.0f;
        this.changeTime = System.currentTimeMillis();
        this.lastUpdate = System.currentTimeMillis();
        this.decimalFormat = new DecimalFormat("0.0");
        this.decimalFormat2 = new DecimalFormat("##0.0", new DecimalFormatSymbols(Locale.ENGLISH));
        this.counter1 = new int[]{50};
        this.counter2 = new int[]{80};
    }
}

