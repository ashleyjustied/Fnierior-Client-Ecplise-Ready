/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.GlStateManager
 *  org.jetbrains.annotations.NotNull
 */
package net.ccbluex.liquidbounce.ui.client.hud.element.elements;

import inferior.ling.utils.CustomUI;
import java.awt.Color;
import kotlin.Metadata;
import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.ui.client.hud.element.Border;
import net.ccbluex.liquidbounce.ui.client.hud.element.Element;
import net.ccbluex.liquidbounce.ui.client.hud.element.ElementInfo;
import net.ccbluex.liquidbounce.ui.cnfont.FontLoaders;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import net.ccbluex.liquidbounce.value.BoolValue;
import net.minecraft.client.renderer.GlStateManager;
import org.jetbrains.annotations.NotNull;

@ElementInfo(name="KeyBinds")
@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\b\u0010\t\u001a\u00020\nH\u0016J\u0006\u0010\u000b\u001a\u00020\fR\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0011\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\b\u00a8\u0006\r"}, d2={"Lnet/ccbluex/liquidbounce/ui/client/hud/element/elements/KeyBinds;", "Lnet/ccbluex/liquidbounce/ui/client/hud/element/Element;", "()V", "anmitY", "", "onlyState", "Lnet/ccbluex/liquidbounce/value/BoolValue;", "getOnlyState", "()Lnet/ccbluex/liquidbounce/value/BoolValue;", "drawElement", "Lnet/ccbluex/liquidbounce/ui/client/hud/element/Border;", "getmoduley", "", "Fnierior"})
public final class KeyBinds
extends Element {
    @NotNull
    private final BoolValue onlyState = new BoolValue("OnlyModuleState", true);
    private float anmitY;

    @NotNull
    public final BoolValue getOnlyState() {
        return this.onlyState;
    }

    @Override
    @NotNull
    public Border drawElement() {
        int y2 = 0;
        this.anmitY = (float)RenderUtils.getAnimationState2(this.anmitY, 15 + this.getmoduley(), 250.0);
        RenderUtils.drawRoundedRect(0.0f, 0.0f, 114.0f, this.anmitY, (int)((Number)CustomUI.radius.get()).floatValue(), new Color(((Number)CustomUI.r.get()).intValue(), ((Number)CustomUI.g.get()).intValue(), ((Number)CustomUI.b.get()).intValue(), ((Number)CustomUI.a.get()).intValue()).getRGB());
        GlStateManager.func_179117_G();
        float fwidth = 10.0f;
        FontLoaders.G16.drawString("KeyBinds", fwidth, 4.5f, -1, true);
        for (Module module : LiquidBounce.INSTANCE.getModuleManager().getModules()) {
            if (module.getKeyBind() == 0 || ((Boolean)this.onlyState.get()).booleanValue() && !module.getState()) continue;
            FontLoaders.G16.drawString(module.getName(), fwidth, (float)y2 + 19.0f, -1, true);
            FontLoaders.G16.drawString(module.getState() ? "[\u5f00\u542f]" : "[\u5173\u95ed]", (float)(108 - FontLoaders.G16.getStringWidth(module.getState() ? "[\u5f00\u542f]" : "[\u5173\u95ed]")), (float)y2 + 21.0f, module.getState() ? new Color(255, 255, 255).getRGB() : new Color(255, 255, 255).getRGB(), true);
            y2 += 10;
        }
        return new Border(0.0f, 0.0f, 114.0f, 17 + this.getmoduley());
    }

    public final int getmoduley() {
        int y = 0;
        for (Module module : LiquidBounce.INSTANCE.getModuleManager().getModules()) {
            if (module.getKeyBind() == 0 || ((Boolean)this.onlyState.get()).booleanValue() && !module.getState()) continue;
            y += 12;
        }
        return y;
    }

    public KeyBinds() {
        super(0.0, 0.0, 0.0f, null, 15, null);
    }
}

