/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.ResourceLocation
 */
package net.ccbluex.liquidbounce.utils;

import java.util.Calendar;
import java.util.Random;
import net.minecraft.util.ResourceLocation;

public class RandomImgUtils {
    private static long startTime = 0L;
    static Random random = new Random();
    static int count = random.nextInt(1);
    public static int count2 = random.nextInt(1);

    public static ResourceLocation getBackGround() {
        Calendar cal = Calendar.getInstance();
        int hour = cal.get(11);
        int minute = cal.get(12);
        int minuteOfDay = hour * 60 + minute;
        boolean start = false;
        int end = 960;
        if (minuteOfDay >= 0 && minuteOfDay <= 960) {
            return new ResourceLocation("pride/bg-morning.png");
        }
        return new ResourceLocation("pride/bg-night.png");
    }
}

