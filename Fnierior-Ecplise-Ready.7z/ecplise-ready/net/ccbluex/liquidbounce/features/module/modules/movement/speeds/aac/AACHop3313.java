/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.NotNull
 */
package net.ccbluex.liquidbounce.features.module.modules.movement.speeds.aac;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.api.IClassProvider;
import net.ccbluex.liquidbounce.api.minecraft.client.block.IBlock;
import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntityPlayerSP;
import net.ccbluex.liquidbounce.api.minecraft.util.WBlockPos;
import net.ccbluex.liquidbounce.event.JumpEvent;
import net.ccbluex.liquidbounce.event.MoveEvent;
import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.SpeedMode;
import net.ccbluex.liquidbounce.utils.MinecraftInstance;
import net.ccbluex.liquidbounce.utils.MovementUtils;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\b\u0010\u0003\u001a\u00020\u0004H\u0016J\b\u0010\u0005\u001a\u00020\u0004H\u0016J\u0010\u0010\u0006\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\bH\u0016J\b\u0010\t\u001a\u00020\u0004H\u0016\u00a8\u0006\n"}, d2={"Lnet/ccbluex/liquidbounce/features/module/modules/movement/speeds/aac/AACHop3313;", "Lnet/ccbluex/liquidbounce/features/module/modules/movement/speeds/SpeedMode;", "()V", "onDisable", "", "onMotion", "onMove", "event", "Lnet/ccbluex/liquidbounce/event/MoveEvent;", "onUpdate", "Fnierior"})
public final class AACHop3313
extends SpeedMode {
    @Override
    public void onMotion() {
    }

    /*
     * WARNING - void declaration
     */
    @Override
    public void onUpdate() {
        IEntityPlayerSP iEntityPlayerSP = MinecraftInstance.mc.getThePlayer();
        if (iEntityPlayerSP == null) {
            return;
        }
        IEntityPlayerSP thePlayer = iEntityPlayerSP;
        if (!MovementUtils.isMoving() || thePlayer.isInWater() || thePlayer.isInLava() || thePlayer.isOnLadder() || thePlayer.isRiding() || thePlayer.getHurtTime() > 0) {
            return;
        }
        if (thePlayer.getOnGround() && thePlayer.isCollidedVertically()) {
            float yawRad = thePlayer.getRotationYaw() * ((float)Math.PI / 180);
            IEntityPlayerSP iEntityPlayerSP2 = thePlayer;
            double d = iEntityPlayerSP2.getMotionX();
            IEntityPlayerSP iEntityPlayerSP3 = iEntityPlayerSP2;
            boolean bl = false;
            float f = (float)Math.sin(yawRad);
            iEntityPlayerSP3.setMotionX(d - (double)(f * 0.202f));
            IEntityPlayerSP iEntityPlayerSP4 = thePlayer;
            d = iEntityPlayerSP4.getMotionZ();
            iEntityPlayerSP3 = iEntityPlayerSP4;
            bl = false;
            f = (float)Math.cos(yawRad);
            iEntityPlayerSP3.setMotionZ(d + (double)(f * 0.202f));
            thePlayer.setMotionY(0.405);
            LiquidBounce.INSTANCE.getEventManager().callEvent(new JumpEvent(0.405f));
            MovementUtils.strafe$default(0.0f, 1, null);
        } else if (thePlayer.getFallDistance() < 0.31f) {
            IBlock iBlock;
            void blockPos$iv;
            WBlockPos yawRad = thePlayer.getPosition();
            IClassProvider iClassProvider = MinecraftInstance.classProvider;
            boolean $i$f$getBlock = false;
            Object object = MinecraftInstance.mc.getTheWorld();
            IBlock iBlock2 = object != null && (object = object.getBlockState((WBlockPos)blockPos$iv)) != null ? object.getBlock() : (iBlock = null);
            if (iClassProvider.isBlockCarpet(iBlock)) {
                return;
            }
            thePlayer.setJumpMovementFactor(thePlayer.getMoveStrafing() == 0.0f ? 0.027f : 0.021f);
            IEntityPlayerSP iEntityPlayerSP5 = thePlayer;
            iEntityPlayerSP5.setMotionX(iEntityPlayerSP5.getMotionX() * 1.001);
            IEntityPlayerSP iEntityPlayerSP6 = thePlayer;
            iEntityPlayerSP6.setMotionZ(iEntityPlayerSP6.getMotionZ() * 1.001);
            if (!thePlayer.isCollidedHorizontally()) {
                IEntityPlayerSP iEntityPlayerSP7 = thePlayer;
                iEntityPlayerSP7.setMotionY(iEntityPlayerSP7.getMotionY() - (double)0.014999993f);
            }
        } else {
            thePlayer.setJumpMovementFactor(0.02f);
        }
    }

    @Override
    public void onMove(@NotNull MoveEvent event) {
        Intrinsics.checkParameterIsNotNull(event, "event");
    }

    @Override
    public void onDisable() {
        IEntityPlayerSP iEntityPlayerSP = MinecraftInstance.mc.getThePlayer();
        if (iEntityPlayerSP == null) {
            Intrinsics.throwNpe();
        }
        iEntityPlayerSP.setJumpMovementFactor(0.02f);
    }

    public AACHop3313() {
        super("AACHop3.3.13");
    }
}

