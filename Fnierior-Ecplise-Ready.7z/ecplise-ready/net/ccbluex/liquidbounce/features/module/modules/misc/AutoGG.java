/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.play.server.SPacketChat
 *  net.minecraft.network.play.server.SPacketTitle
 *  net.minecraft.util.text.ITextComponent
 *  org.jetbrains.annotations.NotNull
 */
package net.ccbluex.liquidbounce.features.module.modules.misc;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import me.sound.SoundPlayer;
import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntityPlayerSP;
import net.ccbluex.liquidbounce.api.minecraft.network.IPacket;
import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.event.PacketEvent;
import net.ccbluex.liquidbounce.event.UpdateEvent;
import net.ccbluex.liquidbounce.event.WorldEvent;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.features.special.AutoDisable;
import net.ccbluex.liquidbounce.injection.PacketImpl;
import net.ccbluex.liquidbounce.ui.client.hud.element.elements.InfosUtils.Recorder;
import net.ccbluex.liquidbounce.ui.client.hud.element.elements.Notification;
import net.ccbluex.liquidbounce.ui.client.hud.element.elements.NotifyType;
import net.ccbluex.liquidbounce.utils.MinecraftInstance;
import net.ccbluex.liquidbounce.utils.timer.MSTimer;
import net.ccbluex.liquidbounce.value.BoolValue;
import net.ccbluex.liquidbounce.value.IntegerValue;
import net.ccbluex.liquidbounce.value.TextValue;
import net.minecraft.network.play.server.SPacketChat;
import net.minecraft.network.play.server.SPacketTitle;
import net.minecraft.util.text.ITextComponent;
import org.jetbrains.annotations.NotNull;

@ModuleInfo(Chinese="\u81ea\u52a8\u53d1GG", name="AutoGG", description="by RyF_", category=ModuleCategory.FNIERIOR)
@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u0000Z\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0007\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\b\u0010\u001a\u001a\u00020\u001bH\u0002J\b\u0010\u001c\u001a\u00020\u001bH\u0002J\b\u0010\u001d\u001a\u00020\u001bH\u0016J\u0010\u0010\u001e\u001a\u00020\u001b2\u0006\u0010\u001f\u001a\u00020 H\u0007J\u0010\u0010!\u001a\u00020\u001b2\u0006\u0010\u001f\u001a\u00020\"H\u0007J\u0010\u0010#\u001a\u00020\u001b2\u0006\u0010\u001f\u001a\u00020$H\u0007J\b\u0010%\u001a\u00020\u001bH\u0002J\b\u0010&\u001a\u00020\u001bH\u0002J\b\u0010'\u001a\u00020\u001bH\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0012\u001a\u00020\u00138VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b\u0014\u0010\u0015R\u000e\u0010\u0016\u001a\u00020\u0017X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006("}, d2={"Lnet/ccbluex/liquidbounce/features/module/modules/misc/AutoGG;", "Lnet/ccbluex/liquidbounce/features/module/Module;", "()V", "bwstart", "", "delayValue", "Lnet/ccbluex/liquidbounce/value/IntegerValue;", "gameTotal", "", "gameWin", "gamestarted", "ggMessageValue", "Lnet/ccbluex/liquidbounce/value/TextValue;", "ggValue", "Lnet/ccbluex/liquidbounce/value/BoolValue;", "sWStart1", "sWStart2", "startValve", "tag", "", "getTag", "()Ljava/lang/String;", "timer", "Lnet/ccbluex/liquidbounce/utils/timer/MSTimer;", "winning", "winverify", "gameend", "", "gg2", "onEnable", "onPacket", "event", "Lnet/ccbluex/liquidbounce/event/PacketEvent;", "onUpdate", "Lnet/ccbluex/liquidbounce/event/UpdateEvent;", "onWorld", "Lnet/ccbluex/liquidbounce/event/WorldEvent;", "start", "stateReset", "total", "Fnierior"})
public final class AutoGG
extends Module {
    private final IntegerValue delayValue = new IntegerValue("Delay", 1000, 100, 5000);
    private final BoolValue ggValue = new BoolValue("SendGG", true);
    private final TextValue ggMessageValue = new TextValue("GGMessage", "[Fnierior] \u4e0d\u9519\u7684\u4e00\u6218\uff0c\u901f\u901f\u56de\u53bb\u529e\u573a\u5e86\u529f\u5bb4\u5427.");
    private final TextValue startValve = new TextValue("StartMessage", "[Fnierior] \u6211\u4f1a\u4e3a\u4e16\u754c\u4e0a\u6240\u6709\u7684\u7f8e\u597d\u800c\u6218.");
    private boolean winverify;
    private boolean gamestarted;
    private boolean winning;
    private boolean bwstart;
    private boolean sWStart1;
    private boolean sWStart2;
    private final MSTimer timer = new MSTimer();
    private int gameTotal;
    private int gameWin;

    private final void stateReset() {
        this.timer.reset();
        this.winverify = false;
        this.gamestarted = false;
        this.bwstart = false;
        this.winning = false;
        this.sWStart1 = false;
        this.sWStart2 = false;
    }

    @Override
    public void onEnable() {
        this.stateReset();
    }

    @EventTarget
    public final void onWorld(@NotNull WorldEvent event) {
        Intrinsics.checkParameterIsNotNull(event, "event");
        this.stateReset();
    }

    @EventTarget
    public final void onPacket(@NotNull PacketEvent event) {
        Intrinsics.checkParameterIsNotNull(event, "event");
        IPacket $this$unwrap$iv = event.getPacket();
        boolean $i$f$unwrap = false;
        Object packet = ((PacketImpl)$this$unwrap$iv).getWrapped();
        if (packet instanceof SPacketChat) {
            String message;
            ITextComponent iTextComponent = ((SPacketChat)packet).func_148915_c();
            Intrinsics.checkExpressionValueIsNotNull(iTextComponent, "packet.chatComponent");
            String string = message = iTextComponent.func_150260_c();
            Intrinsics.checkExpressionValueIsNotNull(string, "message");
            if (StringsKt.contains$default((CharSequence)string, "\u6e38\u620f\u5f00\u59cb ...", false, 2, null) && StringsKt.startsWith$default(message, "\u8d77\u5e8a\u6218\u4e89", false, 2, null) && !StringsKt.contains$default((CharSequence)message, ":", false, 2, null)) {
                this.gamestarted = true;
            }
            if (StringsKt.contains$default((CharSequence)message, "\u4f60\u73b0\u5728\u662f\u89c2\u5bdf\u8005\u72b6\u6001. \u6309E\u6253\u5f00\u83dc\u5355.", false, 2, null) || StringsKt.contains$default((CharSequence)message, "\u606d\u559c", false, 2, null) && StringsKt.startsWith$default(message, "\u8d77\u5e8a\u6218\u4e89", false, 2, null) || StringsKt.startsWith$default(message, "[\u8d77\u5e8a\u6218\u4e89]", false, 2, null) && StringsKt.contains$default((CharSequence)message, "\u8d62\u5f97\u4e86\u6e38\u620f", false, 2, null)) {
                this.gameend();
            }
            if (StringsKt.contains$default((CharSequence)message, "\u5f00\u59cb\u5012\u8ba1\u65f6: 1 \u79d2", false, 2, null)) {
                this.sWStart2 = true;
            }
            if (StringsKt.contains$default((CharSequence)message, "\u6e38\u620f\u5f00\u59cb", false, 2, null) && !StringsKt.contains$default((CharSequence)message, ":", false, 2, null)) {
                this.start();
            }
        }
        if (packet instanceof SPacketTitle) {
            String title;
            ITextComponent iTextComponent = ((SPacketTitle)packet).func_179805_b();
            if (iTextComponent == null) {
                return;
            }
            String string = title = iTextComponent.func_150260_c();
            Intrinsics.checkExpressionValueIsNotNull(string, "title");
            if (StringsKt.contains$default((CharSequence)string, "\u606d\u559c", false, 2, null) || StringsKt.contains$default((CharSequence)title, "\u4f60\u7684\u961f\u4f0d\u83b7\u80dc\u4e86", false, 2, null) || StringsKt.contains$default((CharSequence)title, "VICTORY", false, 2, null)) {
                this.winning = true;
            }
            if (StringsKt.contains$default((CharSequence)title, "\u6218\u6597\u5f00\u59cb", false, 2, null)) {
                this.sWStart1 = true;
            }
        }
    }

    @EventTarget
    public final void onUpdate(@NotNull UpdateEvent event) {
        Intrinsics.checkParameterIsNotNull(event, "event");
        if (!this.timer.hasTimePassed(((Number)this.delayValue.get()).intValue())) {
            return;
        }
        if (this.winning) {
            this.gg2();
        }
        if (this.sWStart1 && this.sWStart2 || this.gamestarted) {
            this.total();
        }
        if (this.sWStart1 && this.sWStart2) {
            this.start();
        }
    }

    private final void gg2() {
        if (((Boolean)this.ggValue.get()).booleanValue()) {
            IEntityPlayerSP iEntityPlayerSP = MinecraftInstance.mc.getThePlayer();
            if (iEntityPlayerSP == null) {
                Intrinsics.throwNpe();
            }
            iEntityPlayerSP.sendChatMessage((String)this.ggMessageValue.get());
        }
        new SoundPlayer().playSound(SoundPlayer.SoundType.VICTORY, LiquidBounce.INSTANCE.getModuleManager().getToggleVolume());
        LiquidBounce.INSTANCE.getHud().addNotification(new Notification("AutoGG", "You Won the game,GG!", NotifyType.SUCCESS, 0, 0, 24, null));
        Recorder recorder = Recorder.INSTANCE;
        int n = recorder.getWin();
        recorder.setWin(n + 1);
        n = this.gameWin;
        this.gameWin = n + 1;
        AutoDisable.INSTANCE.handleGameEnd();
        this.stateReset();
    }

    private final void start() {
        LiquidBounce.INSTANCE.getHud().addNotification(new Notification("AutoGG", "Game started.", NotifyType.INFO, 0, 0, 24, null));
        IEntityPlayerSP iEntityPlayerSP = MinecraftInstance.mc.getThePlayer();
        if (iEntityPlayerSP == null) {
            Intrinsics.throwNpe();
        }
        iEntityPlayerSP.sendChatMessage((String)this.startValve.get());
        new SoundPlayer().playSound(SoundPlayer.SoundType.START, LiquidBounce.INSTANCE.getModuleManager().getToggleVolume());
        this.total();
    }

    private final void total() {
        Recorder recorder = Recorder.INSTANCE;
        int n = recorder.getTotalPlayed();
        recorder.setTotalPlayed(n + 1);
        n = this.gameTotal;
        this.gameTotal = n + 1;
        this.stateReset();
    }

    private final void gameend() {
        AutoDisable.INSTANCE.handleGameEnd();
        this.stateReset();
    }

    @Override
    @NotNull
    public String getTag() {
        return " Total/Win:" + this.gameTotal + '/' + this.gameWin;
    }
}

