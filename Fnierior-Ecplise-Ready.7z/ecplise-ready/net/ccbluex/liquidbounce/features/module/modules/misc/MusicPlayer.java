/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.GuiScreen
 */
package net.ccbluex.liquidbounce.features.module.modules.misc;

import cn.hanabi.gui.cloudmusic.ui.MusicPlayerUI;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.value.FloatValue;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;

@ModuleInfo(name="MusicPlayer", Chinese="\u97f3\u4e50", description="Netease music api", category=ModuleCategory.RENDER, canEnable=false)
public class MusicPlayer
extends Module {
    public final FloatValue volumeValue = new FloatValue("Volume", 1.0f, 0.1f, 1.0f);

    @Override
    public void onEnable() {
        Minecraft.func_71410_x().func_147108_a((GuiScreen)new MusicPlayerUI());
    }
}

