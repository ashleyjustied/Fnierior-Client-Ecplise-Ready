/*
 * Decompiled with CFR 0.152.
 */
package net.ccbluex.liquidbounce.features.module.modules.render;

import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.value.BoolValue;
import net.ccbluex.liquidbounce.value.FloatValue;

@ModuleInfo(Chinese="\u73a9\u5bb6\u5927\u5c0f\u7f16\u8f91", name="PlayerSizeEdit", description="Edit the player.", category=ModuleCategory.PLAYER)
public class PlayerEdit
extends Module {
    public static FloatValue playerSizeValue = new FloatValue("PlayerSize", 0.5f, 0.01f, 5.0f);
    public static BoolValue editPlayerSizeValue = new BoolValue("EditPlayerSize", true);
}

