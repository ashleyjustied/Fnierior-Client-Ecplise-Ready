/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.NotNull
 */
package net.ccbluex.liquidbounce.features.module.modules.movement.speeds.aac;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntityPlayerSP;
import net.ccbluex.liquidbounce.event.MoveEvent;
import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.SpeedMode;
import net.ccbluex.liquidbounce.utils.MinecraftInstance;
import net.ccbluex.liquidbounce.utils.MovementUtils;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\b\u0010\u0006\u001a\u00020\u0007H\u0016J\b\u0010\b\u001a\u00020\u0007H\u0016J\u0010\u0010\t\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\u000bH\u0016J\b\u0010\f\u001a\u00020\u0007H\u0016R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\r"}, d2={"Lnet/ccbluex/liquidbounce/features/module/modules/movement/speeds/aac/AACLowHop3;", "Lnet/ccbluex/liquidbounce/features/module/modules/movement/speeds/SpeedMode;", "()V", "firstJump", "", "waitForGround", "onEnable", "", "onMotion", "onMove", "event", "Lnet/ccbluex/liquidbounce/event/MoveEvent;", "onUpdate", "Fnierior"})
public final class AACLowHop3
extends SpeedMode {
    private boolean firstJump;
    private boolean waitForGround;

    @Override
    public void onEnable() {
        this.firstJump = true;
    }

    @Override
    public void onMotion() {
        IEntityPlayerSP iEntityPlayerSP = MinecraftInstance.mc.getThePlayer();
        if (iEntityPlayerSP == null) {
            return;
        }
        IEntityPlayerSP thePlayer = iEntityPlayerSP;
        if (MovementUtils.isMoving()) {
            if (thePlayer.getHurtTime() <= 0) {
                if (thePlayer.getOnGround()) {
                    this.waitForGround = false;
                    if (!this.firstJump) {
                        this.firstJump = true;
                    }
                    thePlayer.jump();
                    thePlayer.setMotionY(0.41);
                } else {
                    if (this.waitForGround) {
                        return;
                    }
                    if (thePlayer.isCollidedHorizontally()) {
                        return;
                    }
                    this.firstJump = false;
                    IEntityPlayerSP iEntityPlayerSP2 = thePlayer;
                    iEntityPlayerSP2.setMotionY(iEntityPlayerSP2.getMotionY() - 0.0149);
                }
                if (!thePlayer.isCollidedHorizontally()) {
                    MovementUtils.forward(this.firstJump ? 0.0016 : 0.001799);
                }
            } else {
                this.firstJump = true;
                this.waitForGround = true;
            }
        } else {
            thePlayer.setMotionZ(0.0);
            thePlayer.setMotionX(0.0);
        }
        double speed = MovementUtils.INSTANCE.getSpeed();
        double d = MovementUtils.getDirection();
        IEntityPlayerSP iEntityPlayerSP3 = thePlayer;
        boolean bl = false;
        double d2 = Math.sin(d);
        iEntityPlayerSP3.setMotionX(-(d2 * speed));
        d = MovementUtils.getDirection();
        iEntityPlayerSP3 = thePlayer;
        bl = false;
        d2 = Math.cos(d);
        iEntityPlayerSP3.setMotionZ(d2 * speed);
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMove(@NotNull MoveEvent event) {
        Intrinsics.checkParameterIsNotNull(event, "event");
    }

    public AACLowHop3() {
        super("AACLowHop3");
    }
}

