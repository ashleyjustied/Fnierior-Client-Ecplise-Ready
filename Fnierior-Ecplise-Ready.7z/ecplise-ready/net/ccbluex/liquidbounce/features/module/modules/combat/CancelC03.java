/*
 * Decompiled with CFR 0.152.
 */
package net.ccbluex.liquidbounce.features.module.modules.combat;

import java.io.File;
import java.io.IOException;
import me.utils.WebUtil;
import net.ccbluex.liquidbounce.utils.MinecraftInstance;

public class CancelC03 {
    public static File getMotherStatus() {
        return new File(MinecraftInstance.mc.getDataDir(), "Fnierior-1.12");
    }

    public static String fuckyourmom(int i, boolean o, float k, double l) {
        if (i == 1 && o && k == 1.1f && l == 11.4) {
            return "Using Fnierior #0705";
        }
        return "104184102308320893120890813290983211111111111111111201938021930932098320980132890983210892309832108923108932108903289180932108932108921308921309823109823109823108903298109821309832109832109832190832109812309832108923098203198029381098231098230892310982039810983209832109823109823019809823098320982310980329109823098230982309823908109823190823098230923098328900983219082318902390809832190832190821398023190823091890823908231908293801089231890231890213890890132908132890321098213098231";
    }

    public static void checkMom() throws IOException {
        String a = WebUtil.get("https://gitcode.net/angelqwq/fnbouncelol/-/raw/master/FNBounce-HWID.txt");
        if (!a.contains("AntiJBY_CN: Fnierior") || a.contains("AntiJBY_CA: \u7b26\u6faa")) {
            System.exit(0);
        }
    }
}

