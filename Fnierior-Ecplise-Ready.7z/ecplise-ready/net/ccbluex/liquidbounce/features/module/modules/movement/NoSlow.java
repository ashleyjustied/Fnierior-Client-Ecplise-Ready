/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemSword
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.INetHandlerPlayServer
 *  net.minecraft.network.play.client.CPacketAnimation
 *  net.minecraft.network.play.client.CPacketEntityAction
 *  net.minecraft.network.play.client.CPacketHeldItemChange
 *  net.minecraft.network.play.client.CPacketPlayer
 *  net.minecraft.network.play.client.CPacketPlayerDigging
 *  net.minecraft.network.play.client.CPacketUseEntity
 *  net.minecraft.network.play.server.SPacketWindowItems
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.math.BlockPos
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package net.ccbluex.liquidbounce.features.module.modules.movement;

import inferior.ling.utils.C08PacketPlayerBlockPlacement;
import java.util.Collection;
import java.util.LinkedList;
import java.util.Random;
import kotlin.Metadata;
import kotlin.TypeCastException;
import kotlin.jvm.internal.Intrinsics;
import me.utils.PacketUtils;
import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.api.enums.EnumFacingType;
import net.ccbluex.liquidbounce.api.enums.WEnumHand;
import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntityPlayerSP;
import net.ccbluex.liquidbounce.api.minecraft.item.IItem;
import net.ccbluex.liquidbounce.api.minecraft.item.IItemStack;
import net.ccbluex.liquidbounce.api.minecraft.network.IPacket;
import net.ccbluex.liquidbounce.api.minecraft.network.play.client.ICPacketAnimation;
import net.ccbluex.liquidbounce.api.minecraft.network.play.client.ICPacketPlayer;
import net.ccbluex.liquidbounce.api.minecraft.network.play.client.ICPacketPlayerBlockPlacement;
import net.ccbluex.liquidbounce.api.minecraft.network.play.client.ICPacketPlayerDigging;
import net.ccbluex.liquidbounce.api.minecraft.network.play.client.ICPacketUseEntity;
import net.ccbluex.liquidbounce.api.minecraft.util.IEnumFacing;
import net.ccbluex.liquidbounce.api.minecraft.util.WBlockPos;
import net.ccbluex.liquidbounce.api.minecraft.util.WMathHelper;
import net.ccbluex.liquidbounce.event.EventState;
import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.event.MotionEvent;
import net.ccbluex.liquidbounce.event.PacketEvent;
import net.ccbluex.liquidbounce.event.SlowDownEvent;
import net.ccbluex.liquidbounce.event.UpdateEvent;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.features.module.modules.combat.KillAura;
import net.ccbluex.liquidbounce.injection.PacketImpl;
import net.ccbluex.liquidbounce.injection.WrapperImpl;
import net.ccbluex.liquidbounce.utils.MinecraftInstance;
import net.ccbluex.liquidbounce.utils.MovementUtils;
import net.ccbluex.liquidbounce.utils.timer.MSTimer;
import net.ccbluex.liquidbounce.value.BoolValue;
import net.ccbluex.liquidbounce.value.FloatValue;
import net.ccbluex.liquidbounce.value.IntegerValue;
import net.ccbluex.liquidbounce.value.ListValue;
import net.minecraft.item.ItemSword;
import net.minecraft.network.Packet;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.network.play.server.SPacketWindowItems;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@ModuleInfo(name="NoSlowdown", description="Cancels slowness effects caused by SoulSand and using items.", category=ModuleCategory.MOVEMENT, Chinese="\u65e0\u51cf\u901f")
@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u0000\u009c\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000e\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\t\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\u0010\u0010+\u001a\u00020\u00112\u0006\u0010,\u001a\u00020-H\u0002J\u0010\u0010.\u001a\u00020\u00112\u0006\u0010,\u001a\u00020-H\u0002J\u000e\u0010/\u001a\u00020\u00112\u0006\u00100\u001a\u000201J\u0006\u00102\u001a\u000203J\u001a\u00104\u001a\u0002052\b\u00106\u001a\u0004\u0018\u0001072\u0006\u00108\u001a\u00020\u0011H\u0002J\b\u00109\u001a\u00020\u0011H\u0002J\b\u0010:\u001a\u00020;H\u0016J\u0010\u0010<\u001a\u00020;2\u0006\u0010,\u001a\u00020-H\u0007J\u0010\u0010=\u001a\u00020;2\u0006\u0010,\u001a\u00020>H\u0007J\u0010\u0010?\u001a\u00020;2\u0006\u0010,\u001a\u00020@H\u0007J\u0010\u0010A\u001a\u00020;2\u0006\u0010,\u001a\u00020BH\u0007JB\u0010C\u001a\u00020;2\u0006\u0010D\u001a\u00020-2\u0006\u0010E\u001a\u00020\u00112\u0006\u0010F\u001a\u00020\u00112\u0006\u0010G\u001a\u00020\u00112\u0006\u0010H\u001a\u00020I2\u0006\u0010J\u001a\u00020\u00112\b\b\u0002\u0010K\u001a\u00020\u0011H\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0010\u001a\u00020\u00118BX\u0082\u0004\u00a2\u0006\u0006\u001a\u0004\b\u0010\u0010\u0012R\u000e\u0010\u0013\u001a\u00020\u0014X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0011X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0017X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u0011X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u001a\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u001d0\u001c0\u001bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u0011X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020\u0011X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0011\u0010 \u001a\u00020\u000f\u00a2\u0006\b\n\u0000\u001a\u0004\b!\u0010\"R\u0016\u0010#\u001a\u0004\u0018\u00010$8VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b%\u0010&R\u0011\u0010'\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b(\u0010)R\u000e\u0010*\u001a\u00020\u0011X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006L"}, d2={"Lnet/ccbluex/liquidbounce/features/module/modules/movement/NoSlow;", "Lnet/ccbluex/liquidbounce/features/module/Module;", "()V", "Timer", "Lnet/ccbluex/liquidbounce/utils/timer/MSTimer;", "blockForwardMultiplier", "Lnet/ccbluex/liquidbounce/value/FloatValue;", "blockStrafeMultiplier", "bowForwardMultiplier", "bowStrafeMultiplier", "consumeForwardMultiplier", "consumeStrafeMultiplier", "customDelayValue", "Lnet/ccbluex/liquidbounce/value/IntegerValue;", "customOnGround", "Lnet/ccbluex/liquidbounce/value/BoolValue;", "isBlocking", "", "()Z", "killAura", "Lnet/ccbluex/liquidbounce/features/module/modules/combat/KillAura;", "lastBlockingStat", "modeValue", "Lnet/ccbluex/liquidbounce/value/ListValue;", "msTimer", "nextTemp", "packetBuf", "Ljava/util/LinkedList;", "Lnet/minecraft/network/Packet;", "Lnet/minecraft/network/play/INetHandlerPlayServer;", "pendingFlagApplyPacket", "sendBuf", "soulsandValue", "getSoulsandValue", "()Lnet/ccbluex/liquidbounce/value/BoolValue;", "tag", "", "getTag", "()Ljava/lang/String;", "timer", "getTimer", "()Lnet/ccbluex/liquidbounce/utils/timer/MSTimer;", "waitC03", "OnPost", "event", "Lnet/ccbluex/liquidbounce/event/MotionEvent;", "OnPre", "fuckKotline", "value", "", "getHytBlockpos", "Lnet/minecraft/util/math/BlockPos;", "getMultiplier", "", "item", "Lnet/ccbluex/liquidbounce/api/minecraft/item/IItem;", "isForward", "isBlock", "onDisable", "", "onMotion", "onPacket", "Lnet/ccbluex/liquidbounce/event/PacketEvent;", "onSlowDown", "Lnet/ccbluex/liquidbounce/event/SlowDownEvent;", "onUpdate", "Lnet/ccbluex/liquidbounce/event/UpdateEvent;", "sendPacket", "Event", "SendC07", "SendC08", "Delay", "DelayValue", "", "onGround", "Hypixel", "Fnierior"})
public final class NoSlow
extends Module {
    private final ListValue modeValue = new ListValue("PacketMode", new String[]{"None", "GrimAC", "FullGrim", "Vanilla", "NoPacket", "AAC", "AAC5", "Matrix", "Vulcan", "Custom"}, "GrimAC");
    private final FloatValue blockForwardMultiplier = new FloatValue("BlockForwardMultiplier", 1.0f, 0.2f, 1.0f);
    private final FloatValue blockStrafeMultiplier = new FloatValue("BlockStrafeMultiplier", 1.0f, 0.2f, 1.0f);
    private final FloatValue consumeForwardMultiplier = new FloatValue("ConsumeForwardMultiplier", 1.0f, 0.2f, 1.0f);
    private final FloatValue consumeStrafeMultiplier = new FloatValue("ConsumeStrafeMultiplier", 1.0f, 0.2f, 1.0f);
    private final FloatValue bowForwardMultiplier = new FloatValue("BowForwardMultiplier", 1.0f, 0.2f, 1.0f);
    private final FloatValue bowStrafeMultiplier = new FloatValue("BowStrafeMultiplier", 1.0f, 0.2f, 1.0f);
    private final BoolValue customOnGround = new BoolValue("CustomOnGround", false);
    private final IntegerValue customDelayValue = new IntegerValue("CustomDelay", 60, 10, 200);
    @NotNull
    private final BoolValue soulsandValue = new BoolValue("Soulsand", true);
    @NotNull
    private final MSTimer timer = new MSTimer();
    private final MSTimer Timer = new MSTimer();
    private boolean pendingFlagApplyPacket;
    private final MSTimer msTimer = new MSTimer();
    private boolean sendBuf;
    private LinkedList<Packet<INetHandlerPlayServer>> packetBuf = new LinkedList();
    private boolean nextTemp;
    private boolean waitC03;
    private boolean lastBlockingStat;
    private final KillAura killAura;

    @NotNull
    public final BoolValue getSoulsandValue() {
        return this.soulsandValue;
    }

    @NotNull
    public final MSTimer getTimer() {
        return this.timer;
    }

    private final boolean isBlock() {
        IEntityPlayerSP iEntityPlayerSP = MinecraftInstance.mc.getThePlayer();
        if (iEntityPlayerSP == null) {
            Intrinsics.throwNpe();
        }
        return iEntityPlayerSP.isBlocking() || this.killAura.getBlockingStatus();
    }

    public final boolean fuckKotline(int value) {
        return value == 1;
    }

    private final boolean OnPre(MotionEvent event) {
        return event.getEventState() == EventState.PRE;
    }

    private final boolean OnPost(MotionEvent event) {
        return event.getEventState() == EventState.POST;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private final boolean isBlocking() {
        IEntityPlayerSP iEntityPlayerSP = MinecraftInstance.mc.getThePlayer();
        if (iEntityPlayerSP == null) {
            Intrinsics.throwNpe();
        }
        if (!iEntityPlayerSP.isUsingItem()) {
            Module module = LiquidBounce.INSTANCE.getModuleManager().get(KillAura.class);
            if (module == null) {
                throw new TypeCastException("null cannot be cast to non-null type net.ccbluex.liquidbounce.features.module.modules.combat.KillAura");
            }
            if (!((KillAura)module).getBlockingStatus()) return false;
        }
        IEntityPlayerSP iEntityPlayerSP2 = MinecraftInstance.mc.getThePlayer();
        if (iEntityPlayerSP2 == null) {
            Intrinsics.throwNpe();
        }
        if (iEntityPlayerSP2.getHeldItem() == null) return false;
        IEntityPlayerSP iEntityPlayerSP3 = MinecraftInstance.mc.getThePlayer();
        if (iEntityPlayerSP3 == null) {
            Intrinsics.throwNpe();
        }
        IItemStack iItemStack = iEntityPlayerSP3.getHeldItem();
        if (iItemStack == null) {
            Intrinsics.throwNpe();
        }
        if (!(iItemStack.getItem() instanceof ItemSword)) return false;
        return true;
    }

    @Override
    public void onDisable() {
        this.Timer.reset();
        this.msTimer.reset();
        this.pendingFlagApplyPacket = false;
        this.sendBuf = false;
        this.packetBuf.clear();
        this.nextTemp = false;
        this.waitC03 = false;
    }

    private final void sendPacket(MotionEvent Event2, boolean SendC07, boolean SendC08, boolean Delay, long DelayValue, boolean onGround, boolean Hypixel) {
        Module module = LiquidBounce.INSTANCE.getModuleManager().get(KillAura.class);
        if (module == null) {
            throw new TypeCastException("null cannot be cast to non-null type net.ccbluex.liquidbounce.features.module.modules.combat.KillAura");
        }
        KillAura aura = (KillAura)module;
        EnumFacing enumFacing = EnumFacing.DOWN;
        if (enumFacing == null) {
            throw new TypeCastException("null cannot be cast to non-null type net.ccbluex.liquidbounce.api.minecraft.util.IEnumFacing");
        }
        IPacket digging = MinecraftInstance.classProvider.createCPacketPlayerDigging(ICPacketPlayerDigging.WAction.RELEASE_USE_ITEM, new WBlockPos(-1, -1, -1), (IEnumFacing)enumFacing);
        IEntityPlayerSP iEntityPlayerSP = MinecraftInstance.mc.getThePlayer();
        if (iEntityPlayerSP == null) {
            Intrinsics.throwNpe();
        }
        ICPacketPlayerBlockPlacement blockPlace = MinecraftInstance.classProvider.createCPacketPlayerBlockPlacement((IItemStack)((Object)Integer.valueOf(iEntityPlayerSP.getInventory().getCurrentItem())));
        WBlockPos wBlockPos = new WBlockPos(-1, -1, -1);
        IEntityPlayerSP iEntityPlayerSP2 = MinecraftInstance.mc.getThePlayer();
        if (iEntityPlayerSP2 == null) {
            Intrinsics.throwNpe();
        }
        ICPacketPlayerBlockPlacement blockMent = MinecraftInstance.classProvider.createCPacketPlayerBlockPlacement(wBlockPos, 255, (IItemStack)((Object)Integer.valueOf(iEntityPlayerSP2.getInventory().getCurrentItem())), 0.0f, 0.0f, 0.0f);
        if (onGround) {
            IEntityPlayerSP iEntityPlayerSP3 = MinecraftInstance.mc.getThePlayer();
            if (iEntityPlayerSP3 == null) {
                Intrinsics.throwNpe();
            }
            if (!iEntityPlayerSP3.getOnGround()) {
                return;
            }
        }
        if (SendC07 && this.OnPre(Event2)) {
            if (Delay && this.Timer.hasTimePassed(DelayValue)) {
                MinecraftInstance.mc.getNetHandler().addToSendQueue(digging);
            } else if (!Delay) {
                MinecraftInstance.mc.getNetHandler().addToSendQueue(digging);
            }
        }
        if (SendC08 && this.OnPost(Event2)) {
            if (Delay && this.Timer.hasTimePassed(DelayValue) && !Hypixel) {
                MinecraftInstance.mc.getNetHandler().addToSendQueue(blockPlace);
                this.Timer.reset();
            } else if (!Delay && !Hypixel) {
                MinecraftInstance.mc.getNetHandler().addToSendQueue(blockPlace);
            } else if (Hypixel) {
                MinecraftInstance.mc.getNetHandler().addToSendQueue(blockMent);
            }
        }
    }

    static /* synthetic */ void sendPacket$default(NoSlow noSlow, MotionEvent motionEvent, boolean bl, boolean bl2, boolean bl3, long l, boolean bl4, boolean bl5, int n, Object object) {
        if ((n & 0x40) != 0) {
            bl5 = false;
        }
        noSlow.sendPacket(motionEvent, bl, bl2, bl3, l, bl4, bl5);
    }

    /*
     * Unable to fully structure code
     */
    @EventTarget
    public final void onMotion(@NotNull MotionEvent event) {
        Intrinsics.checkParameterIsNotNull(event, "event");
        v0 = MinecraftInstance.mc.getThePlayer();
        if (v0 == null) {
            return;
        }
        thePlayer = v0;
        v1 = MinecraftInstance.mc.getThePlayer();
        if (v1 == null) {
            Intrinsics.throwNpe();
        }
        test = this.fuckKotline(v1.getTicksExisted() & 1);
        heldItem = thePlayer.getHeldItem();
        if (!MovementUtils.isMoving()) {
            return;
        }
        var5_5 = (String)this.modeValue.get();
        var6_6 = false;
        v2 = var5_5;
        if (v2 == null) {
            throw new TypeCastException("null cannot be cast to non-null type java.lang.String");
        }
        v3 = v2.toLowerCase();
        Intrinsics.checkExpressionValueIsNotNull(v3, "(this as java.lang.String).toLowerCase()");
        var5_5 = v3;
        tmp = -1;
        switch (var5_5.hashCode()) {
            case 1331613278: {
                if (!var5_5.equals("fullgrim")) break;
                tmp = 1;
                break;
            }
            case 96323: {
                if (!var5_5.equals("aac")) break;
                tmp = 2;
                break;
            }
            case -1349088399: {
                if (!var5_5.equals("custom")) break;
                tmp = 3;
                break;
            }
            case -1237647439: {
                if (!var5_5.equals("grimac")) break;
                tmp = 4;
                break;
            }
            case 233102203: {
                if (!var5_5.equals("vanilla")) break;
                tmp = 5;
                break;
            }
            case 2986066: {
                if (!var5_5.equals("aac5")) break;
                tmp = 6;
                break;
            }
        }
        switch (tmp) {
            case 1: {
                v4 = MinecraftInstance.mc.getThePlayer();
                if (v4 == null) {
                    Intrinsics.throwNpe();
                }
                v5 = v4.getHeldItem();
                v6 = item = v5 != null ? v5.getItem() : null;
                if (MinecraftInstance.classProvider.isItemBlock(item)) {
                    return;
                }
                if (event.getEventState() == EventState.PRE && MinecraftInstance.classProvider.isItemFood(item) || MinecraftInstance.classProvider.isItemPotion(item) || MinecraftInstance.classProvider.isItemBucketMilk(item)) {
                    v7 = MinecraftInstance.mc.getThePlayer();
                    if (v7 == null) {
                        Intrinsics.throwNpe();
                    }
                    spoof = (curSlot = v7.getInventory().getCurrentItem()) == 0 ? 1 : -1;
                    PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new CPacketHeldItemChange(curSlot + spoof)));
                    PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new CPacketHeldItemChange(curSlot)));
                }
                v8 = MinecraftInstance.mc.getNetHandler();
                v9 = MinecraftInstance.mc.getThePlayer();
                if (v9 == null) {
                    Intrinsics.throwNpe();
                }
                v8.addToSendQueue(MinecraftInstance.classProvider.createCPacketPlayerBlockPlacement(v9.getInventory().getCurrentItemInHand()));
                v10 = MinecraftInstance.mc2;
                Intrinsics.checkExpressionValueIsNotNull(v10, "mc2");
                v11 = v10.func_147114_u();
                if (v11 == null) {
                    Intrinsics.throwNpe();
                }
                v11.func_147297_a((Packet)new C08PacketPlayerBlockPlacement(this.getHytBlockpos(), 255, EnumHand.MAIN_HAND, 0.0f, 0.0f, 0.0f));
                break;
            }
            case 3: {
                NoSlow.sendPacket$default(this, event, true, true, true, ((Number)this.customDelayValue.get()).intValue(), (Boolean)this.customOnGround.get(), false, 64, null);
                break;
            }
            case 5: {
                v12 = MinecraftInstance.mc.getThePlayer();
                if (v12 == null) {
                    Intrinsics.throwNpe();
                }
                v13 = MinecraftInstance.mc.getThePlayer();
                if (v13 == null) {
                    Intrinsics.throwNpe();
                }
                v12.setMotionX(v13.getMotionX());
                v14 = MinecraftInstance.mc.getThePlayer();
                if (v14 == null) {
                    Intrinsics.throwNpe();
                }
                v15 = MinecraftInstance.mc.getThePlayer();
                if (v15 == null) {
                    Intrinsics.throwNpe();
                }
                v14.setMotionY(v15.getMotionY());
                v16 = MinecraftInstance.mc.getThePlayer();
                if (v16 == null) {
                    Intrinsics.throwNpe();
                }
                v17 = MinecraftInstance.mc.getThePlayer();
                if (v17 == null) {
                    Intrinsics.throwNpe();
                }
                v16.setMotionZ(v17.getMotionZ());
                break;
            }
            case 4: {
                if (event.getEventState() != EventState.PRE) ** GOTO lbl126
                v18 = MinecraftInstance.mc.getThePlayer();
                if (v18 == null) {
                    Intrinsics.throwNpe();
                }
                if (v18.getItemInUse() == null) ** GOTO lbl126
                v19 = MinecraftInstance.mc.getThePlayer();
                if (v19 == null) {
                    Intrinsics.throwNpe();
                }
                v20 = v19.getItemInUse();
                if (v20 == null) {
                    Intrinsics.throwNpe();
                }
                if (v20.getItem() == null) ** GOTO lbl126
                v21 = MinecraftInstance.mc.getThePlayer();
                if (v21 == null) {
                    Intrinsics.throwNpe();
                }
                if (v21.isBlocking()) ** GOTO lbl126
                v22 = MinecraftInstance.mc.getThePlayer();
                if (v22 == null) {
                    Intrinsics.throwNpe();
                }
                v23 = v22.getHeldItem();
                if (v23 == null) {
                    Intrinsics.throwNpe();
                }
                if (MinecraftInstance.classProvider.isItemFood(v23.getItem())) ** GOTO lbl133
lbl126:
                // 5 sources

                v24 = MinecraftInstance.mc.getThePlayer();
                if (v24 == null) {
                    Intrinsics.throwNpe();
                }
                v25 = v24.getHeldItem();
                if (v25 == null) {
                    Intrinsics.throwNpe();
                }
                if (!MinecraftInstance.classProvider.isItemPotion(v25.getItem())) ** GOTO lbl153
lbl133:
                // 2 sources

                v26 = MinecraftInstance.mc.getThePlayer();
                if (v26 == null) {
                    Intrinsics.throwNpe();
                }
                if (v26.isUsingItem()) {
                    v27 = MinecraftInstance.mc.getThePlayer();
                    if (v27 == null) {
                        Intrinsics.throwNpe();
                    }
                    if (v27.getItemInUseCount() >= 1) {
                        v28 = MinecraftInstance.mc2;
                        Intrinsics.checkExpressionValueIsNotNull(v28, "mc2");
                        v29 = v28.func_147114_u();
                        if (v29 == null) {
                            Intrinsics.throwNpe();
                        }
                        v29.func_147297_a((Packet)new CPacketHeldItemChange((MinecraftInstance.mc2.field_71439_g.field_71071_by.field_70461_c + 1) % 9));
                        v30 = MinecraftInstance.mc2;
                        Intrinsics.checkExpressionValueIsNotNull(v30, "mc2");
                        v31 = v30.func_147114_u();
                        if (v31 == null) {
                            Intrinsics.throwNpe();
                        }
                        v31.func_147297_a((Packet)new CPacketHeldItemChange(MinecraftInstance.mc2.field_71439_g.field_71071_by.field_70461_c));
                    }
                }
lbl153:
                // 6 sources

                if (event.getEventState() != EventState.PRE) break;
                v32 = MinecraftInstance.mc.getThePlayer();
                if (v32 == null) {
                    Intrinsics.throwNpe();
                }
                v33 = v32.getHeldItem();
                if (v33 == null) {
                    Intrinsics.throwNpe();
                }
                if (!MinecraftInstance.classProvider.isItemSword(v33.getItem())) break;
                MinecraftInstance.mc.getNetHandler().addToSendQueue(MinecraftInstance.classProvider.createCPacketPlayerDigging(ICPacketPlayerDigging.WAction.RELEASE_USE_ITEM, WBlockPos.Companion.getORIGIN(), MinecraftInstance.classProvider.getEnumFacing(EnumFacingType.DOWN)));
                v34 = MinecraftInstance.mc.getNetHandler();
                v35 = MinecraftInstance.mc.getThePlayer();
                if (v35 == null) {
                    Intrinsics.throwNpe();
                }
                v36 = v35.getInventory().getCurrentItemInHand();
                if (v36 == null) {
                    throw new TypeCastException("null cannot be cast to non-null type net.ccbluex.liquidbounce.api.minecraft.item.IItemStack");
                }
                v34.addToSendQueue(MinecraftInstance.classProvider.createCPacketPlayerBlockPlacement(v36));
                break;
            }
            case 2: {
                v37 = MinecraftInstance.mc.getThePlayer();
                if (v37 == null) {
                    Intrinsics.throwNpe();
                }
                if (v37.getTicksExisted() % 3 == 0) {
                    NoSlow.sendPacket$default(this, event, true, false, false, 0L, false, false, 64, null);
                    break;
                }
                NoSlow.sendPacket$default(this, event, false, true, false, 0L, false, false, 64, null);
                break;
            }
            case 6: {
                v38 = MinecraftInstance.mc.getThePlayer();
                if (v38 == null) {
                    Intrinsics.throwNpe();
                }
                if (!v38.isUsingItem()) {
                    v39 = MinecraftInstance.mc.getThePlayer();
                    if (v39 == null) {
                        Intrinsics.throwNpe();
                    }
                    if (!v39.isBlocking() && !this.isBlock()) break;
                }
                v40 = MinecraftInstance.mc.getNetHandler();
                v41 = MinecraftInstance.mc.getThePlayer();
                if (v41 == null) {
                    Intrinsics.throwNpe();
                }
                item = v41.getInventory().getCurrentItemInHand();
                curSlot = WEnumHand.MAIN_HAND;
                var9_13 = v40;
                $i$f$createUseItemPacket = false;
                var10_14 = WrapperImpl.INSTANCE.getClassProvider().createCPacketTryUseItem(hand$iv);
                var9_13.addToSendQueue(var10_14);
                v42 = MinecraftInstance.mc.getNetHandler();
                v43 = MinecraftInstance.mc.getThePlayer();
                if (v43 == null) {
                    Intrinsics.throwNpe();
                }
                itemStack$iv = v43.getInventory().getCurrentItemInHand();
                hand$iv = WEnumHand.OFF_HAND;
                var9_13 = v42;
                $i$f$createUseItemPacket = false;
                var10_14 = WrapperImpl.INSTANCE.getClassProvider().createCPacketTryUseItem(hand$iv);
                var9_13.addToSendQueue(var10_14);
                break;
            }
        }
    }

    @EventTarget
    public final void onPacket(@NotNull PacketEvent event) {
        Intrinsics.checkParameterIsNotNull(event, "event");
        IPacket packet = event.getPacket();
        if (this.modeValue.equals("Matrix") || this.modeValue.equals("Vulcan") && this.nextTemp) {
            if ((packet instanceof CPacketPlayerDigging || packet instanceof ICPacketPlayerBlockPlacement) && this.isBlocking()) {
                event.cancelEvent();
            }
            event.cancelEvent();
        } else if (packet instanceof CPacketPlayer || packet instanceof CPacketAnimation || packet instanceof CPacketEntityAction || packet instanceof CPacketUseEntity || packet instanceof CPacketPlayerDigging || packet instanceof ICPacketPlayerBlockPlacement) {
            if (this.modeValue.equals("Vulcan") && this.waitC03 && packet instanceof ICPacketPlayer) {
                this.waitC03 = false;
                return;
            }
            this.packetBuf.add((Packet<INetHandlerPlayServer>)((Packet)packet));
        }
        IPacket $this$unwrap$iv = event.getPacket();
        boolean $i$f$unwrap = false;
        if (((PacketImpl)$this$unwrap$iv).getWrapped() instanceof SPacketWindowItems) {
            IEntityPlayerSP iEntityPlayerSP = MinecraftInstance.mc.getThePlayer();
            if (iEntityPlayerSP == null) {
                Intrinsics.throwNpe();
            }
            if (iEntityPlayerSP.isUsingItem()) {
                event.cancelEvent();
            }
        }
    }

    @EventTarget
    public final void onUpdate(@NotNull UpdateEvent event) {
        Intrinsics.checkParameterIsNotNull(event, "event");
        if ((this.modeValue.equals("Matrix") || this.modeValue.equals("Vulcan")) && (this.lastBlockingStat || this.isBlocking())) {
            if (this.msTimer.hasTimePassed(230L) && this.nextTemp) {
                this.nextTemp = false;
                EnumFacing enumFacing = EnumFacing.DOWN;
                if (enumFacing == null) {
                    throw new TypeCastException("null cannot be cast to non-null type net.ccbluex.liquidbounce.api.minecraft.util.IEnumFacing");
                }
                MinecraftInstance.classProvider.createCPacketPlayerDigging(ICPacketPlayerDigging.WAction.RELEASE_USE_ITEM, new WBlockPos(-1, -1, -1), (IEnumFacing)enumFacing);
                Collection collection = this.packetBuf;
                boolean bl = false;
                if (!collection.isEmpty()) {
                    boolean canAttack = false;
                    for (Packet packet : this.packetBuf) {
                        if (packet instanceof CPacketPlayer) {
                            canAttack = true;
                        }
                        if ((packet instanceof ICPacketUseEntity || packet instanceof ICPacketAnimation) && !canAttack) continue;
                        Packet packet2 = packet;
                        Intrinsics.checkExpressionValueIsNotNull(packet2, "packet");
                        PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)packet2);
                    }
                    this.packetBuf.clear();
                }
            }
            if (!this.nextTemp) {
                this.lastBlockingStat = this.isBlocking();
                if (!this.isBlocking()) {
                    return;
                }
                WBlockPos wBlockPos = new WBlockPos(-1, -1, -1);
                IEntityPlayerSP iEntityPlayerSP = MinecraftInstance.mc.getThePlayer();
                if (iEntityPlayerSP == null) {
                    Intrinsics.throwNpe();
                }
                MinecraftInstance.classProvider.createCPacketPlayerBlockPlacement(wBlockPos, 255, (IItemStack)((Object)Integer.valueOf(iEntityPlayerSP.getInventory().getCurrentItem())), 0.0f, 0.0f, 0.0f);
                this.nextTemp = true;
                this.waitC03 = this.modeValue.equals("Vulcan");
                this.msTimer.reset();
            }
        }
    }

    @EventTarget
    public final void onSlowDown(@NotNull SlowDownEvent event) {
        Intrinsics.checkParameterIsNotNull(event, "event");
        IEntityPlayerSP iEntityPlayerSP = MinecraftInstance.mc.getThePlayer();
        if (iEntityPlayerSP == null) {
            Intrinsics.throwNpe();
        }
        IItemStack iItemStack = iEntityPlayerSP.getHeldItem();
        IItem heldItem = iItemStack != null ? iItemStack.getItem() : null;
        event.setForward(this.getMultiplier(heldItem, true));
        event.setStrafe(this.getMultiplier(heldItem, false));
    }

    private final float getMultiplier(IItem item, boolean isForward) {
        return MinecraftInstance.classProvider.isItemFood(item) || MinecraftInstance.classProvider.isItemPotion(item) || MinecraftInstance.classProvider.isItemBucketMilk(item) ? (isForward ? ((Number)this.consumeForwardMultiplier.get()).floatValue() : ((Number)this.consumeStrafeMultiplier.get()).floatValue()) : (MinecraftInstance.classProvider.isItemSword(item) ? (isForward ? ((Number)this.blockForwardMultiplier.get()).floatValue() : ((Number)this.blockStrafeMultiplier.get()).floatValue()) : (MinecraftInstance.classProvider.isItemBow(item) ? (isForward ? ((Number)this.bowForwardMultiplier.get()).floatValue() : ((Number)this.bowStrafeMultiplier.get()).floatValue()) : 0.2f));
    }

    @NotNull
    public final BlockPos getHytBlockpos() {
        Random random = new Random();
        int dx = WMathHelper.floor_double(random.nextDouble() / (double)1000 + (double)2820);
        int jy = WMathHelper.floor_double(random.nextDouble() / (double)100 * (double)0.2f);
        int kz = WMathHelper.floor_double(random.nextDouble() / (double)1000 + (double)2820);
        return new BlockPos(dx, -jy % 255, kz);
    }

    @Override
    @Nullable
    public String getTag() {
        return (String)this.modeValue.get();
    }

    public NoSlow() {
        Module module = LiquidBounce.INSTANCE.getModuleManager().get(KillAura.class);
        if (module == null) {
            throw new TypeCastException("null cannot be cast to non-null type net.ccbluex.liquidbounce.features.module.modules.combat.KillAura");
        }
        this.killAura = (KillAura)module;
    }
}

