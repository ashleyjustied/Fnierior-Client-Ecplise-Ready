/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.NotNull
 */
package net.ccbluex.liquidbounce.features.module.modules.movement.speeds.ncp;

import java.util.Collection;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntityPlayerSP;
import net.ccbluex.liquidbounce.api.minecraft.client.multiplayer.IWorldClient;
import net.ccbluex.liquidbounce.api.minecraft.util.IAxisAlignedBB;
import net.ccbluex.liquidbounce.event.MoveEvent;
import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.SpeedMode;
import net.ccbluex.liquidbounce.utils.MinecraftInstance;
import net.ccbluex.liquidbounce.utils.MovementUtils;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\b\u0010\u0007\u001a\u00020\bH\u0016J\u0010\u0010\t\u001a\u00020\b2\u0006\u0010\n\u001a\u00020\u000bH\u0016J\b\u0010\f\u001a\u00020\bH\u0016J\b\u0010\r\u001a\u00020\u000eH\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u000f"}, d2={"Lnet/ccbluex/liquidbounce/features/module/modules/movement/speeds/ncp/Boost;", "Lnet/ccbluex/liquidbounce/features/module/modules/movement/speeds/SpeedMode;", "()V", "ground", "", "motionDelay", "", "onMotion", "", "onMove", "event", "Lnet/ccbluex/liquidbounce/event/MoveEvent;", "onUpdate", "shouldSpeedUp", "", "Fnierior"})
public final class Boost
extends SpeedMode {
    private int motionDelay;
    private float ground;

    @Override
    public void onMotion() {
        IEntityPlayerSP iEntityPlayerSP = MinecraftInstance.mc.getThePlayer();
        if (iEntityPlayerSP == null) {
            return;
        }
        IEntityPlayerSP thePlayer = iEntityPlayerSP;
        double speed = 3.1981;
        double offset = 4.69;
        boolean shouldOffset = true;
        IWorldClient iWorldClient = MinecraftInstance.mc.getTheWorld();
        if (iWorldClient == null) {
            Intrinsics.throwNpe();
        }
        Collection<IAxisAlignedBB> collection = iWorldClient.getCollidingBoundingBoxes(thePlayer, thePlayer.getEntityBoundingBox().offset(thePlayer.getMotionX() / offset, 0.0, thePlayer.getMotionZ() / offset));
        boolean bl = false;
        if (!collection.isEmpty()) {
            shouldOffset = false;
        }
        if (thePlayer.getOnGround() && this.ground < 1.0f) {
            this.ground += 0.2f;
        }
        if (!thePlayer.getOnGround()) {
            this.ground = 0.0f;
        }
        if (this.ground == 1.0f && this.shouldSpeedUp()) {
            if (!thePlayer.getSprinting()) {
                offset += 0.8;
            }
            if (thePlayer.getMoveStrafing() != 0.0f) {
                speed -= 0.1;
                offset += 0.5;
            }
            if (thePlayer.isInWater()) {
                speed -= 0.1;
            }
            ++this.motionDelay;
            switch (this.motionDelay) {
                case 1: {
                    IEntityPlayerSP iEntityPlayerSP2 = thePlayer;
                    iEntityPlayerSP2.setMotionX(iEntityPlayerSP2.getMotionX() * speed);
                    IEntityPlayerSP iEntityPlayerSP3 = thePlayer;
                    iEntityPlayerSP3.setMotionZ(iEntityPlayerSP3.getMotionZ() * speed);
                    break;
                }
                case 2: {
                    IEntityPlayerSP iEntityPlayerSP4 = thePlayer;
                    iEntityPlayerSP4.setMotionX(iEntityPlayerSP4.getMotionX() / 1.458);
                    IEntityPlayerSP iEntityPlayerSP5 = thePlayer;
                    iEntityPlayerSP5.setMotionZ(iEntityPlayerSP5.getMotionZ() / 1.458);
                    break;
                }
                case 4: {
                    if (shouldOffset) {
                        thePlayer.setPosition(thePlayer.getPosX() + thePlayer.getMotionX() / offset, thePlayer.getPosY(), thePlayer.getPosZ() + thePlayer.getMotionZ() / offset);
                    }
                    this.motionDelay = 0;
                    break;
                }
            }
        }
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMove(@NotNull MoveEvent event) {
        Intrinsics.checkParameterIsNotNull(event, "event");
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private final boolean shouldSpeedUp() {
        IEntityPlayerSP iEntityPlayerSP = MinecraftInstance.mc.getThePlayer();
        if (iEntityPlayerSP == null) {
            Intrinsics.throwNpe();
        }
        if (iEntityPlayerSP.isInLava()) return false;
        IEntityPlayerSP iEntityPlayerSP2 = MinecraftInstance.mc.getThePlayer();
        if (iEntityPlayerSP2 == null) {
            Intrinsics.throwNpe();
        }
        if (iEntityPlayerSP2.isOnLadder()) return false;
        IEntityPlayerSP iEntityPlayerSP3 = MinecraftInstance.mc.getThePlayer();
        if (iEntityPlayerSP3 == null) {
            Intrinsics.throwNpe();
        }
        if (iEntityPlayerSP3.isSneaking()) return false;
        if (!MovementUtils.isMoving()) return false;
        return true;
    }

    public Boost() {
        super("Boost");
    }
}

