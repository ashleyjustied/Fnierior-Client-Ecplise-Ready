/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.util.text.ITextComponent
 *  org.jetbrains.annotations.NotNull
 *  org.lwjgl.opengl.GL11
 */
package net.ccbluex.liquidbounce.features.module.modules.render;

import java.awt.Color;
import kotlin.Metadata;
import kotlin.TypeCastException;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import kotlin.text.StringsKt;
import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntity;
import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntityLivingBase;
import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntityPlayerSP;
import net.ccbluex.liquidbounce.api.minecraft.client.gui.IFontRenderer;
import net.ccbluex.liquidbounce.api.minecraft.client.multiplayer.IWorldClient;
import net.ccbluex.liquidbounce.api.minecraft.renderer.entity.IRenderManager;
import net.ccbluex.liquidbounce.api.minecraft.util.IIChatComponent;
import net.ccbluex.liquidbounce.api.minecraft.util.ITimer;
import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.event.Render3DEvent;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.features.module.modules.combat.KillAura;
import net.ccbluex.liquidbounce.ui.font.Fonts;
import net.ccbluex.liquidbounce.utils.EntityUtils;
import net.ccbluex.liquidbounce.utils.MinecraftInstance;
import net.ccbluex.liquidbounce.utils.render.ColorUtils;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import net.ccbluex.liquidbounce.value.BoolValue;
import net.ccbluex.liquidbounce.value.FloatValue;
import net.ccbluex.liquidbounce.value.FontValue;
import net.ccbluex.liquidbounce.value.IntegerValue;
import net.ccbluex.liquidbounce.value.ListValue;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.text.ITextComponent;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.opengl.GL11;

@ModuleInfo(Chinese="\u8ffd\u968f\u76ee\u6807HUD", name="FollowTargetHud", description="followtargethud", category=ModuleCategory.RENDER)
@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u0000Z\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\u0010\u0010\u0015\u001a\u00020\u00042\u0006\u0010\u0016\u001a\u00020\u0017H\u0002J\u0010\u0010\u0018\u001a\u00020\u00192\u0006\u0010\u001a\u001a\u00020\u001bH\u0007J\u0018\u0010\u001c\u001a\u00020\u00192\u0006\u0010\u0016\u001a\u00020\u001d2\u0006\u0010\u001e\u001a\u00020\u0004H\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u000eX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u000eX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0014X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u001f"}, d2={"Lnet/ccbluex/liquidbounce/features/module/modules/render/FollowTargetHud;", "Lnet/ccbluex/liquidbounce/features/module/Module;", "()V", "entityKeep", "", "fontValue", "Lnet/ccbluex/liquidbounce/value/FontValue;", "jelloAlphaValue", "Lnet/ccbluex/liquidbounce/value/IntegerValue;", "jelloColorValue", "Lnet/ccbluex/liquidbounce/value/BoolValue;", "modeValue", "Lnet/ccbluex/liquidbounce/value/ListValue;", "scaleValue", "Lnet/ccbluex/liquidbounce/value/FloatValue;", "targetTicks", "", "translateX", "translateY", "xChange", "", "getPlayerName", "entity", "Lnet/minecraft/entity/EntityLivingBase;", "onRender3D", "", "event", "Lnet/ccbluex/liquidbounce/event/Render3DEvent;", "renderNameTag", "Lnet/ccbluex/liquidbounce/api/minecraft/client/entity/IEntityLivingBase;", "tag", "Fnierior"})
public final class FollowTargetHud
extends Module {
    private final ListValue modeValue = new ListValue("Mode", new String[]{"Juul", "Jello", "Material", "Arris", "FDP"}, "Juul");
    private final FontValue fontValue;
    private final BoolValue jelloColorValue;
    private final IntegerValue jelloAlphaValue;
    private final FloatValue scaleValue;
    private final FloatValue translateY;
    private final FloatValue translateX;
    private float xChange;
    private int targetTicks;
    private String entityKeep;

    @EventTarget
    public final void onRender3D(@NotNull Render3DEvent event) {
        Intrinsics.checkParameterIsNotNull(event, "event");
        if (MinecraftInstance.mc.getThePlayer() == null) {
            return;
        }
        IWorldClient iWorldClient = MinecraftInstance.mc.getTheWorld();
        if (iWorldClient == null) {
            Intrinsics.throwNpe();
        }
        for (IEntity entity : iWorldClient.getLoadedEntityList()) {
            if (!EntityUtils.isSelected(entity, false)) continue;
            IIChatComponent iIChatComponent = entity.getDisplayName();
            if (iIChatComponent == null) {
                continue;
            }
            this.renderNameTag(entity.asEntityLivingBase(), iIChatComponent.getUnformattedText());
        }
    }

    private final String getPlayerName(EntityLivingBase entity) {
        String name;
        ITextComponent iTextComponent = entity.func_145748_c_();
        Intrinsics.checkExpressionValueIsNotNull(iTextComponent, "entity.displayName");
        String string = name = iTextComponent.func_150254_d();
        Intrinsics.checkExpressionValueIsNotNull(string, "name");
        return string;
    }

    private final void renderNameTag(IEntityLivingBase entity, String tag) {
        float distance;
        int n;
        this.xChange = ((Number)this.translateX.get()).floatValue() * (float)20;
        Module module = LiquidBounce.INSTANCE.getModuleManager().getModule(KillAura.class);
        if (module == null) {
            throw new TypeCastException("null cannot be cast to non-null type net.ccbluex.liquidbounce.features.module.modules.combat.KillAura");
        }
        KillAura killAura = (KillAura)module;
        if (Intrinsics.areEqual(entity, killAura.getTarget()) ^ true) {
            return;
        }
        if (Intrinsics.areEqual(entity, killAura.getTarget())) {
            this.entityKeep = String.valueOf(entity.getName());
            n = this.targetTicks;
            this.targetTicks = n + 1;
            if (this.targetTicks >= 5) {
                this.targetTicks = 4;
            }
        } else if (killAura.getTarget() == null) {
            n = this.targetTicks;
            this.targetTicks = n + -1;
            if (this.targetTicks <= -1) {
                this.targetTicks = 0;
                this.entityKeep = "dg636 top";
            }
        }
        if (this.targetTicks == 0) {
            return;
        }
        IFontRenderer fontRenderer = (IFontRenderer)this.fontValue.get();
        IFontRenderer font = Fonts.bold30;
        GL11.glPushMatrix();
        IRenderManager renderManager = MinecraftInstance.mc.getRenderManager();
        ITimer timer = MinecraftInstance.mc.getTimer();
        GL11.glTranslated((double)(entity.getLastTickPosX() + (entity.getPosX() - entity.getLastTickPosX()) * (double)timer.getRenderPartialTicks() - renderManager.getRenderPosX()), (double)(entity.getLastTickPosY() + (entity.getPosY() - entity.getLastTickPosY()) * (double)timer.getRenderPartialTicks() - renderManager.getRenderPosY() + (double)entity.getEyeHeight() + (double)((Number)this.translateY.get()).floatValue()), (double)(entity.getLastTickPosZ() + (entity.getPosZ() - entity.getLastTickPosZ()) * (double)timer.getRenderPartialTicks() - renderManager.getRenderPosZ()));
        GL11.glRotatef((float)(-MinecraftInstance.mc.getRenderManager().getPlayerViewY()), (float)0.0f, (float)1.0f, (float)0.0f);
        GL11.glRotatef((float)MinecraftInstance.mc.getRenderManager().getPlayerViewX(), (float)1.0f, (float)0.0f, (float)0.0f);
        IEntityPlayerSP iEntityPlayerSP = MinecraftInstance.mc.getThePlayer();
        if (iEntityPlayerSP == null) {
            Intrinsics.throwNpe();
        }
        if ((distance = iEntityPlayerSP.getDistanceToEntity(entity) / 4.0f) < 1.0f) {
            distance = 1.0f;
        }
        float scale = distance / 150.0f * ((Number)this.scaleValue.get()).floatValue();
        RenderUtils.disableGlCap(2896, 2929);
        RenderUtils.enableGlCap(3042);
        GL11.glBlendFunc((int)770, (int)771);
        IIChatComponent iIChatComponent = entity.getDisplayName();
        if (iIChatComponent == null) {
            Intrinsics.throwNpe();
        }
        String name = iIChatComponent.getUnformattedText();
        float healthPercent = entity.getHealth() / entity.getMaxHealth();
        if (healthPercent > 1.0f) {
            healthPercent = 1.0f;
        }
        String string = (String)this.modeValue.get();
        boolean bl = false;
        String string2 = string;
        if (string2 == null) {
            throw new TypeCastException("null cannot be cast to non-null type java.lang.String");
        }
        String string3 = string2.toLowerCase();
        Intrinsics.checkExpressionValueIsNotNull(string3, "(this as java.lang.String).toLowerCase()");
        switch (string3) {
            case "juul": {
                GL11.glScalef((float)(-scale * (float)2), (float)(-scale * (float)2), (float)(scale * (float)2));
                RenderUtils.drawRoundedCornerRect(-120.0f + this.xChange, -16.0f, -50.0f + this.xChange, 10.0f, 5.0f, new Color(64, 64, 64, 255).getRGB());
                RenderUtils.drawRoundedCornerRect(-110.0f + this.xChange, 0.0f, -20.0f + this.xChange, 35.0f, 5.0f, new Color(96, 96, 96, 255).getRGB());
                int n2 = -105 + (int)this.xChange;
                Color color = Color.WHITE;
                Intrinsics.checkExpressionValueIsNotNull(color, "Color.WHITE");
                fontRenderer.drawString("Attacking", n2, -13, color.getRGB());
                int n3 = -106 + (int)this.xChange;
                Color color2 = Color.WHITE;
                Intrinsics.checkExpressionValueIsNotNull(color2, "Color.WHITE");
                fontRenderer.drawString(tag, n3, 10, color2.getRGB());
                String healthString = String.valueOf((float)((int)(entity.getHealth() * 10.0f)) * 0.1f) + " / 20";
                int n4 = -25 - fontRenderer.getStringWidth(healthString) + (int)this.xChange;
                Color color3 = Color.WHITE;
                Intrinsics.checkExpressionValueIsNotNull(color3, "Color.WHITE");
                fontRenderer.drawString(healthString, n4, 22, color3.getRGB());
                StringBuilder stringBuilder = new StringBuilder().append("\u2922");
                IEntityPlayerSP iEntityPlayerSP2 = MinecraftInstance.mc.getThePlayer();
                if (iEntityPlayerSP2 == null) {
                    Intrinsics.throwNpe();
                }
                String distanceString = stringBuilder.append(String.valueOf((float)((int)(iEntityPlayerSP2.getDistanceToEntity(entity) * 10.0f)) * 0.1f)).toString();
                int n5 = -25 - fontRenderer.getStringWidth(distanceString) + (int)this.xChange;
                Color color4 = Color.WHITE;
                Intrinsics.checkExpressionValueIsNotNull(color4, "Color.WHITE");
                fontRenderer.drawString(distanceString, n5, 10, color4.getRGB());
                RenderUtils.drawRoundedCornerRect(-104.0f + this.xChange, 22.0f, -50.0f + this.xChange, 30.0f, 1.0f, new Color(64, 64, 64, 255).getRGB());
                float f = -104.0f + healthPercent * (float)54 + this.xChange;
                Color color5 = Color.WHITE;
                Intrinsics.checkExpressionValueIsNotNull(color5, "Color.WHITE");
                RenderUtils.drawRoundedCornerRect(-104.0f + this.xChange, 22.0f, f, 30.0f, 1.0f, color5.getRGB());
                break;
            }
            case "material": {
                GL11.glScalef((float)(-scale * (float)2), (float)(-scale * (float)2), (float)(scale * (float)2));
                RenderUtils.drawRoundedCornerRect(-40.0f + this.xChange, 0.0f, 40.0f + this.xChange, 30.0f, 5.0f, new Color(72, 72, 72, 220).getRGB());
                RenderUtils.drawRoundedCornerRect(-35.0f + this.xChange, 7.0f, -35.0f + healthPercent * (float)70 + this.xChange, 12.0f, 2.0f, new Color(10, 250, 10, 255).getRGB());
                break;
            }
            case "arris": {
                GL11.glScalef((float)(-scale * (float)2), (float)(-scale * (float)2), (float)(scale * (float)2));
                float hp = healthPercent;
                int additionalWidth = RangesKt.coerceAtLeast(font.getStringWidth(entity.getName() + "  " + hp + " hp"), 75);
                RenderUtils.drawRoundedCornerRect(this.xChange, 0.0f, 45.0f + (float)additionalWidth + this.xChange, 40.0f, 7.0f, new Color(0, 0, 0, 110).getRGB());
                String string4 = String.valueOf(entity.getName());
                int n6 = 40 + (int)this.xChange;
                Color color = Color.WHITE;
                Intrinsics.checkExpressionValueIsNotNull(color, "Color.WHITE");
                font.drawString(string4, n6, 5, color.getRGB());
                String string5 = hp + " hp";
                boolean bl2 = false;
                boolean bl3 = false;
                String it = string5;
                boolean bl4 = false;
                int n7 = 40 + additionalWidth - font.getStringWidth(it) + (int)this.xChange;
                Color color6 = Color.LIGHT_GRAY;
                Intrinsics.checkExpressionValueIsNotNull(color6, "Color.LIGHT_GRAY");
                font.drawString(it, n7, 5, color6.getRGB());
                float yPos = (float)(5 + font.getFontHeight()) + 3.0f;
                float f = (float)40 + this.xChange + healthPercent * (float)additionalWidth;
                float f2 = yPos + (float)4;
                Color color7 = Color.GREEN;
                Intrinsics.checkExpressionValueIsNotNull(color7, "Color.GREEN");
                RenderUtils.drawRect(40.0f + this.xChange, yPos, f, f2, color7.getRGB());
                break;
            }
            case "FDP": {
                GL11.glScalef((float)(-scale * (float)2), (float)(-scale * (float)2), (float)(scale * (float)2));
                RenderUtils.drawRoundedCornerRect(-70.0f, 0.0f, 70.0f, 40.0f, 5.0f, new Color(0, 0, 0, 95).getRGB());
                int n8 = -30 + (int)this.xChange;
                Color color = Color.WHITE;
                Intrinsics.checkExpressionValueIsNotNull(color, "Color.WHITE");
                fontRenderer.drawString(name, n8, 5, color.getRGB());
                String string6 = "Health " + (int)entity.getHealth();
                int n9 = -30 + (int)this.xChange;
                int n10 = 5 + font.getFontHeight();
                Color color8 = Color.WHITE;
                Intrinsics.checkExpressionValueIsNotNull(color8, "Color.WHITE");
                fontRenderer.drawString(string6, n9, n10, color8.getRGB());
                RenderUtils.drawRoundedCornerRect(-30.0f + this.xChange, 5 + font.getFontHeight() * 2, -30.0f + this.xChange + healthPercent * 95.0f, 37.0f, 3.0f, ColorUtils.rainbow().getRGB());
                break;
            }
            case "jello": {
                Color hpBarColor = new Color(255, 255, 255, ((Number)this.jelloAlphaValue.get()).intValue());
                IIChatComponent iIChatComponent2 = entity.getDisplayName();
                if (iIChatComponent2 == null) {
                    Intrinsics.throwNpe();
                }
                String name2 = iIChatComponent2.getUnformattedText();
                if (((Boolean)this.jelloColorValue.get()).booleanValue() && StringsKt.startsWith$default(name2, "\u00a7", false, 2, null)) {
                    hpBarColor = new Color(255, 255, 255);
                }
                Color bgColor = new Color(50, 50, 50, ((Number)this.jelloAlphaValue.get()).intValue());
                int width = fontRenderer.getStringWidth(tag);
                float maxWidth = (float)width + 4.0f - ((float)(-width) - 4.0f);
                float healthPercent2 = entity.getHealth() / entity.getMaxHealth();
                GL11.glScalef((float)(-scale * (float)2), (float)(-scale * (float)2), (float)(scale * (float)2));
                RenderUtils.drawRect(this.xChange, (float)(-fontRenderer.getFontHeight()) * 3.0f, (float)width + 8.0f + this.xChange, -3.0f, bgColor);
                if (healthPercent2 > 1.0f) {
                    healthPercent2 = 1.0f;
                }
                RenderUtils.drawRect(this.xChange, -3.0f, maxWidth * healthPercent2 + this.xChange, 1.0f, hpBarColor);
                RenderUtils.drawRect(maxWidth * healthPercent2 + this.xChange, -3.0f, (float)width + 8.0f + this.xChange, 1.0f, bgColor);
                int n11 = 4 + (int)this.xChange;
                int n12 = -fontRenderer.getFontHeight() * 2 - 4;
                Color color = Color.WHITE;
                Intrinsics.checkExpressionValueIsNotNull(color, "Color.WHITE");
                fontRenderer.drawString(tag, n11, n12, color.getRGB());
                GL11.glScalef((float)0.5f, (float)0.5f, (float)0.5f);
                String string7 = "Health: " + (int)entity.getHealth();
                int n13 = 4 + (int)this.xChange;
                int n14 = -fontRenderer.getFontHeight() * 2;
                Color color9 = Color.WHITE;
                Intrinsics.checkExpressionValueIsNotNull(color9, "Color.WHITE");
                fontRenderer.drawString(string7, n13, n14, color9.getRGB());
                break;
            }
        }
        RenderUtils.resetCaps();
        GlStateManager.func_179117_G();
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GL11.glPopMatrix();
    }

    public FollowTargetHud() {
        IFontRenderer iFontRenderer = Fonts.bold30;
        Intrinsics.checkExpressionValueIsNotNull(iFontRenderer, "Fonts.bold30");
        this.fontValue = new FontValue("Font", iFontRenderer);
        this.jelloColorValue = new BoolValue("JelloHPColor", true);
        this.jelloAlphaValue = new IntegerValue("JelloAlpha", 170, 0, 255);
        this.scaleValue = new FloatValue("Scale", 1.0f, 1.0f, 4.0f);
        this.translateY = new FloatValue("TanslateY", 0.55f, -2.0f, 2.0f);
        this.translateX = new FloatValue("TranslateX", 0.0f, -2.0f, 2.0f);
        this.xChange = ((Number)this.translateX.get()).floatValue() * (float)20;
        this.entityKeep = "yes";
    }
}

