/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.NotNull
 */
package net.ccbluex.liquidbounce.features.module.modules.misc;

import inferior.ling.modules.PlusScaffold;
import inferior.ling.modules.ScaffoldNew;
import kotlin.Metadata;
import kotlin.TypeCastException;
import kotlin.jvm.internal.Intrinsics;
import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntityPlayerSP;
import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.event.UpdateEvent;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.features.module.modules.world.OldScaffold;
import net.ccbluex.liquidbounce.features.module.modules.world.Scaffold;
import net.ccbluex.liquidbounce.features.module.modules.world.Timer;
import net.ccbluex.liquidbounce.utils.MinecraftInstance;
import net.ccbluex.liquidbounce.value.BoolValue;
import net.ccbluex.liquidbounce.value.ListValue;
import org.jetbrains.annotations.NotNull;

@ModuleInfo(Chinese="Telly\u5e2e\u52a9\u8005", name="TellyBridge", description="\u4e3b\u64ad\u770b\u6211\u4e00\u4e2a\u5e05\u6c14\u7684\u901f\u5ea620Telly", category=ModuleCategory.MISC)
@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u00000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\u0006\u0010\f\u001a\u00020\rJ\b\u0010\u000e\u001a\u00020\rH\u0016J\u0010\u0010\u000f\u001a\u00020\r2\u0006\u0010\u0010\u001a\u00020\u0011H\u0007R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\b\u001a\u00020\t8VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b\n\u0010\u000b\u00a8\u0006\u0012"}, d2={"Lnet/ccbluex/liquidbounce/features/module/modules/misc/ScaffoldHelper;", "Lnet/ccbluex/liquidbounce/features/module/Module;", "()V", "autobypassValue", "Lnet/ccbluex/liquidbounce/value/BoolValue;", "jumpMode", "Lnet/ccbluex/liquidbounce/value/ListValue;", "scaffoldModule", "tag", "", "getTag", "()Ljava/lang/String;", "jump", "", "onDisable", "onUpdate", "event", "Lnet/ccbluex/liquidbounce/event/UpdateEvent;", "Fnierior"})
public final class ScaffoldHelper
extends Module {
    private final ListValue scaffoldModule = new ListValue("ScaffoldModule", new String[]{"NewScaffold", "LiquidPlusScaffold", "Scaffold", "OldScaffold"}, "OldScaffold");
    private final BoolValue autobypassValue = new BoolValue("AutoBypass", true);
    private final ListValue jumpMode = new ListValue("AutoJumpMode", new String[]{"None", "mc", "mc2", "motionY", "Key"}, "None");

    @Override
    public void onDisable() {
        LiquidBounce.INSTANCE.getModuleManager().get(Scaffold.class).setState(false);
        LiquidBounce.INSTANCE.getModuleManager().get(OldScaffold.class).setState(false);
        LiquidBounce.INSTANCE.getModuleManager().get(ScaffoldNew.class).setState(false);
        super.onDisable();
    }

    public final void jump() {
        if (MinecraftInstance.mc2.field_71439_g.field_70122_E || !MinecraftInstance.mc2.field_71439_g.field_70160_al) {
            String string = (String)this.jumpMode.get();
            boolean bl = false;
            String string2 = string;
            if (string2 == null) {
                throw new TypeCastException("null cannot be cast to non-null type java.lang.String");
            }
            String string3 = string2.toLowerCase();
            Intrinsics.checkExpressionValueIsNotNull(string3, "(this as java.lang.String).toLowerCase()");
            switch (string3) {
                case "mc": {
                    IEntityPlayerSP iEntityPlayerSP = MinecraftInstance.mc.getThePlayer();
                    if (iEntityPlayerSP == null) {
                        Intrinsics.throwNpe();
                    }
                    iEntityPlayerSP.jump();
                    break;
                }
                case "mc2": {
                    MinecraftInstance.mc2.field_71439_g.func_70664_aZ();
                    break;
                }
                case "motiony": {
                    IEntityPlayerSP iEntityPlayerSP = MinecraftInstance.mc.getThePlayer();
                    if (iEntityPlayerSP == null) {
                        Intrinsics.throwNpe();
                    }
                    iEntityPlayerSP.setMotionY(0.42);
                    break;
                }
                case "key": {
                    MinecraftInstance.mc2.field_71474_y.field_74314_A.field_74513_e = true;
                    MinecraftInstance.mc2.field_71474_y.field_74314_A.field_74513_e = false;
                    break;
                }
            }
        }
    }

    @EventTarget
    public final void onUpdate(@NotNull UpdateEvent event) {
        Intrinsics.checkParameterIsNotNull(event, "event");
        if (((Boolean)this.autobypassValue.get()).booleanValue()) {
            IEntityPlayerSP iEntityPlayerSP = MinecraftInstance.mc.getThePlayer();
            if (iEntityPlayerSP == null) {
                Intrinsics.throwNpe();
            }
            iEntityPlayerSP.setRotationPitch(26.0f);
        }
        IEntityPlayerSP iEntityPlayerSP = MinecraftInstance.mc.getThePlayer();
        if (iEntityPlayerSP == null) {
            Intrinsics.throwNpe();
        }
        if (iEntityPlayerSP.getOnGround()) {
            String string = (String)this.scaffoldModule.get();
            boolean bl = false;
            String string2 = string;
            if (string2 == null) {
                throw new TypeCastException("null cannot be cast to non-null type java.lang.String");
            }
            String string3 = string2.toLowerCase();
            Intrinsics.checkExpressionValueIsNotNull(string3, "(this as java.lang.String).toLowerCase()");
            switch (string3) {
                case "scaffold": {
                    LiquidBounce.INSTANCE.getModuleManager().getModule(Scaffold.class).setState(false);
                    break;
                }
                case "newscaffold": {
                    LiquidBounce.INSTANCE.getModuleManager().getModule(ScaffoldNew.class).setState(false);
                    break;
                }
                case "oldscaffold": {
                    LiquidBounce.INSTANCE.getModuleManager().getModule(OldScaffold.class).setState(false);
                    break;
                }
                case "liquidplusscaffold": {
                    LiquidBounce.INSTANCE.getModuleManager().getModule(PlusScaffold.class).setState(false);
                    break;
                }
            }
            this.jump();
            LiquidBounce.INSTANCE.getModuleManager().getModule(Timer.class).setState(false);
        } else {
            String string = (String)this.scaffoldModule.get();
            boolean bl = false;
            String string4 = string;
            if (string4 == null) {
                throw new TypeCastException("null cannot be cast to non-null type java.lang.String");
            }
            String string5 = string4.toLowerCase();
            Intrinsics.checkExpressionValueIsNotNull(string5, "(this as java.lang.String).toLowerCase()");
            switch (string5) {
                case "scaffold": {
                    LiquidBounce.INSTANCE.getModuleManager().getModule(Scaffold.class).setState(true);
                    break;
                }
                case "oldscaffold": {
                    LiquidBounce.INSTANCE.getModuleManager().getModule(OldScaffold.class).setState(true);
                    break;
                }
                case "liquidplusscaffold": {
                    LiquidBounce.INSTANCE.getModuleManager().getModule(PlusScaffold.class).setState(true);
                    break;
                }
                case "newscaffold": {
                    LiquidBounce.INSTANCE.getModuleManager().getModule(ScaffoldNew.class).setState(true);
                    break;
                }
            }
            LiquidBounce.INSTANCE.getModuleManager().getModule(Timer.class).setState(true);
        }
    }

    @Override
    @NotNull
    public String getTag() {
        return (String)this.scaffoldModule.get();
    }
}

