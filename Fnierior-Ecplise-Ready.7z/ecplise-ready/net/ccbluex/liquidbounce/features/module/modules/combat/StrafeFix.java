/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.NotNull
 */
package net.ccbluex.liquidbounce.features.module.modules.combat;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntityPlayerSP;
import net.ccbluex.liquidbounce.api.minecraft.util.WMathHelper;
import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.event.StrafeEvent;
import net.ccbluex.liquidbounce.event.UpdateEvent;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.utils.MinecraftInstance;
import net.ccbluex.liquidbounce.utils.Rotation;
import net.ccbluex.liquidbounce.utils.RotationUtils;
import net.ccbluex.liquidbounce.value.BoolValue;
import org.jetbrains.annotations.NotNull;

@ModuleInfo(Chinese="\u7075\u6d3b\u79fb\u52a8Fix", name="StrafeFix", description="StrafeFix .114514.", category=ModuleCategory.COMBAT)
@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\u0016\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u00042\u0006\u0010\u0015\u001a\u00020\u0004J\b\u0010\u0016\u001a\u00020\u0013H\u0016J\u0010\u0010\u0017\u001a\u00020\u00132\u0006\u0010\u0018\u001a\u00020\u0019H\u0007J\u0016\u0010\u001a\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u00042\u0006\u0010\u0018\u001a\u00020\u001bJ\u0006\u0010\u001c\u001a\u00020\u0013R\u001a\u0010\u0003\u001a\u00020\u0004X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0005\u0010\u0006\"\u0004\b\u0007\u0010\bR\u001a\u0010\t\u001a\u00020\u0004X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\t\u0010\u0006\"\u0004\b\n\u0010\bR\u001a\u0010\u000b\u001a\u00020\u0004X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\u0006\"\u0004\b\r\u0010\bR\u0011\u0010\u000e\u001a\u00020\u000f\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011\u00a8\u0006\u001d"}, d2={"Lnet/ccbluex/liquidbounce/features/module/modules/combat/StrafeFix;", "Lnet/ccbluex/liquidbounce/features/module/Module;", "()V", "doFix", "", "getDoFix", "()Z", "setDoFix", "(Z)V", "isOverwrited", "setOverwrited", "silentFix", "getSilentFix", "setSilentFix", "silentFixVaule", "Lnet/ccbluex/liquidbounce/value/BoolValue;", "getSilentFixVaule", "()Lnet/ccbluex/liquidbounce/value/BoolValue;", "applyForceStrafe", "", "isSilent", "runStrafeFix", "onDisable", "onUpdate", "event", "Lnet/ccbluex/liquidbounce/event/UpdateEvent;", "runStrafeFixLoop", "Lnet/ccbluex/liquidbounce/event/StrafeEvent;", "updateOverwrite", "Fnierior"})
public final class StrafeFix
extends Module {
    @NotNull
    private final BoolValue silentFixVaule = new BoolValue("Silent", true);
    private boolean silentFix;
    private boolean doFix;
    private boolean isOverwrited;

    @NotNull
    public final BoolValue getSilentFixVaule() {
        return this.silentFixVaule;
    }

    public final boolean getSilentFix() {
        return this.silentFix;
    }

    public final void setSilentFix(boolean bl) {
        this.silentFix = bl;
    }

    public final boolean getDoFix() {
        return this.doFix;
    }

    public final void setDoFix(boolean bl) {
        this.doFix = bl;
    }

    public final boolean isOverwrited() {
        return this.isOverwrited;
    }

    public final void setOverwrited(boolean bl) {
        this.isOverwrited = bl;
    }

    @EventTarget
    public final void onUpdate(@NotNull UpdateEvent event) {
        Intrinsics.checkParameterIsNotNull(event, "event");
        if (!this.isOverwrited) {
            this.silentFix = (Boolean)this.silentFixVaule.get();
            this.doFix = true;
        }
    }

    @Override
    public void onDisable() {
        this.doFix = false;
    }

    public final void applyForceStrafe(boolean isSilent, boolean runStrafeFix) {
        this.silentFix = isSilent;
        this.doFix = runStrafeFix;
        this.isOverwrited = true;
    }

    public final void updateOverwrite() {
        this.isOverwrited = false;
        this.doFix = this.getState();
        this.silentFix = (Boolean)this.silentFixVaule.get();
    }

    public final void runStrafeFixLoop(boolean isSilent, @NotNull StrafeEvent event) {
        Intrinsics.checkParameterIsNotNull(event, "event");
        if (event.isCancelled()) {
            return;
        }
        Rotation rotation = RotationUtils.targetRotation;
        if (rotation == null) {
            return;
        }
        Rotation rotation2 = rotation;
        float yaw = rotation2.component1();
        float strafe = event.getStrafe();
        float forward = event.getForward();
        float friction = event.getFriction();
        float factor = strafe * strafe + forward * forward;
        IEntityPlayerSP iEntityPlayerSP = MinecraftInstance.mc.getThePlayer();
        if (iEntityPlayerSP == null) {
            Intrinsics.throwNpe();
        }
        int angleDiff = (int)(((double)WMathHelper.wrapAngleTo180_float(iEntityPlayerSP.getRotationYaw() - yaw - 22.5f - 135.0f) + 180.0) / 45.0);
        float calcYaw = isSilent ? yaw + 45.0f * (float)angleDiff : yaw;
        float calcMoveDir = Math.max(Math.abs(strafe), Math.abs(forward));
        calcMoveDir *= calcMoveDir;
        float f = calcMoveDir / Math.min(1.0f, calcMoveDir * 2.0f);
        boolean bl = false;
        float calcMultiplier = (float)Math.sqrt(f);
        if (isSilent) {
            switch (angleDiff) {
                case 1: 
                case 3: 
                case 5: 
                case 7: 
                case 9: {
                    if (!(!((double)Math.abs(forward) > 0.005) && !((double)Math.abs(strafe) > 0.005) || (double)Math.abs(forward) > 0.005 && (double)Math.abs(strafe) > 0.005)) {
                        friction /= calcMultiplier;
                        break;
                    }
                    if (!((double)Math.abs(forward) > 0.005) || !((double)Math.abs(strafe) > 0.005)) break;
                    friction *= calcMultiplier;
                    break;
                }
            }
        }
        if (factor >= 1.0E-4f) {
            boolean bl2 = false;
            if ((factor = (float)Math.sqrt(factor)) < 1.0f) {
                factor = 1.0f;
            }
            factor = friction / factor;
            strafe *= factor;
            forward *= factor;
            double d = (double)calcYaw * Math.PI / (double)180.0f;
            boolean bl3 = false;
            double yawSin = Math.sin(d);
            double d2 = (double)calcYaw * Math.PI / (double)180.0f;
            boolean bl4 = false;
            double yawCos = Math.cos(d2);
            IEntityPlayerSP iEntityPlayerSP2 = MinecraftInstance.mc.getThePlayer();
            if (iEntityPlayerSP2 == null) {
                Intrinsics.throwNpe();
            }
            iEntityPlayerSP2.setMotionX(iEntityPlayerSP2.getMotionX() + ((double)strafe * yawCos - (double)forward * yawSin));
            IEntityPlayerSP iEntityPlayerSP3 = MinecraftInstance.mc.getThePlayer();
            if (iEntityPlayerSP3 == null) {
                Intrinsics.throwNpe();
            }
            iEntityPlayerSP3.setMotionZ(iEntityPlayerSP3.getMotionZ() + ((double)forward * yawCos + (double)strafe * yawSin));
        }
        event.cancelEvent();
    }
}

