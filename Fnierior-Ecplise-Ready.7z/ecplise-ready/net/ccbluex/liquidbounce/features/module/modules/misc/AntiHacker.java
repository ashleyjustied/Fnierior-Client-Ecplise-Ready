/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.NotNull
 */
package net.ccbluex.liquidbounce.features.module.modules.misc;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntityPlayerSP;
import net.ccbluex.liquidbounce.event.UpdateEvent;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.utils.MinecraftInstance;
import net.ccbluex.liquidbounce.utils.timer.MSTimer;
import net.ccbluex.liquidbounce.utils.timer.TimeUtils;
import net.ccbluex.liquidbounce.value.TextValue;
import org.jetbrains.annotations.NotNull;

@ModuleInfo(Chinese="Hacker\u52a0\u767d(WIP)", name="AntiHacker", description="\u53ef\u4ee5\u8ba9\u5f00\u4e86HytGetName\u7684\u4eba\u4e0d\u6253\u4f60", category=ModuleCategory.MISC)
@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u000e\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u0012R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u0005\u001a\u00020\u0006X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0007\u0010\b\"\u0004\b\t\u0010\nR\u0011\u0010\u000b\u001a\u00020\f\u00a2\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000e\u00a8\u0006\u0013"}, d2={"Lnet/ccbluex/liquidbounce/features/module/modules/misc/AntiHacker;", "Lnet/ccbluex/liquidbounce/features/module/Module;", "()V", "Name", "Lnet/ccbluex/liquidbounce/value/TextValue;", "delay", "", "getDelay", "()J", "setDelay", "(J)V", "msTimer", "Lnet/ccbluex/liquidbounce/utils/timer/MSTimer;", "getMsTimer", "()Lnet/ccbluex/liquidbounce/utils/timer/MSTimer;", "onUpdate", "", "event", "Lnet/ccbluex/liquidbounce/event/UpdateEvent;", "Fnierior"})
public final class AntiHacker
extends Module {
    private static final TextValue Name;
    private static long delay;
    @NotNull
    private static final MSTimer msTimer;
    public static final AntiHacker INSTANCE;

    public final long getDelay() {
        return delay;
    }

    public final void setDelay(long l) {
        delay = l;
    }

    @NotNull
    public final MSTimer getMsTimer() {
        return msTimer;
    }

    public final void onUpdate(@NotNull UpdateEvent event) {
        Intrinsics.checkParameterIsNotNull(event, "event");
        if (msTimer.hasTimePassed(delay)) {
            IEntityPlayerSP iEntityPlayerSP = MinecraftInstance.mc.getThePlayer();
            if (iEntityPlayerSP == null) {
                Intrinsics.throwNpe();
            }
            iEntityPlayerSP.sendChatMessage("\u6740\u6b7b\u4e86" + Name);
            delay = TimeUtils.randomDelay(500, 5000);
        }
    }

    private AntiHacker() {
    }

    static {
        AntiHacker antiHacker;
        INSTANCE = antiHacker = new AntiHacker();
        Name = new TextValue("YourName", "Me");
        delay = TimeUtils.randomDelay(500, 5000);
        msTimer = new MSTimer();
    }
}

