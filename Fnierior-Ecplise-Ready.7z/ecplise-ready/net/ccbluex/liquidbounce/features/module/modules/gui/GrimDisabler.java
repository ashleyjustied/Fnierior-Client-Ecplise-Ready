/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.play.client.CPacketCloseWindow
 *  net.minecraft.network.play.client.CPacketPlayerTryUseItem
 *  net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock
 *  org.jetbrains.annotations.NotNull
 */
package net.ccbluex.liquidbounce.features.module.modules.gui;

import inferior.ling.utils.C08PacketPlayerBlockPlacement;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.ccbluex.liquidbounce.api.minecraft.network.IPacket;
import net.ccbluex.liquidbounce.event.PacketEvent;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.injection.PacketImpl;
import net.ccbluex.liquidbounce.utils.ClientUtils;
import net.ccbluex.liquidbounce.value.BoolValue;
import net.ccbluex.liquidbounce.value.ListValue;
import net.minecraft.network.play.client.CPacketCloseWindow;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import org.jetbrains.annotations.NotNull;

@ModuleInfo(Chinese="Grim\u7981\u7528\u5668", name="GrimDisabler", category=ModuleCategory.FNIERIOR, description="by wanfeng")
@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\u000e\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000eR\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0011\u0010\u0007\u001a\u00020\b8F\u00a2\u0006\u0006\u001a\u0004\b\t\u0010\n\u00a8\u0006\u000f"}, d2={"Lnet/ccbluex/liquidbounce/features/module/modules/gui/GrimDisabler;", "", "()V", "debugerValue", "Lnet/ccbluex/liquidbounce/value/BoolValue;", "modeValve", "Lnet/ccbluex/liquidbounce/value/ListValue;", "tag", "", "getTag", "()Ljava/lang/String;", "onPacket", "", "event", "Lnet/ccbluex/liquidbounce/event/PacketEvent;", "Fnierior"})
public final class GrimDisabler {
    private final ListValue modeValve = new ListValue("Mode", new String[]{"Grim"}, "Grim");
    private final BoolValue debugerValue = new BoolValue("Debug", false);

    public final void onPacket(@NotNull PacketEvent event) {
        Intrinsics.checkParameterIsNotNull(event, "event");
        IPacket $this$unwrap$iv = event.getPacket();
        boolean $i$f$unwrap = false;
        Object packet = ((PacketImpl)$this$unwrap$iv).getWrapped();
        if (((Boolean)this.debugerValue.get()).booleanValue()) {
            if (packet instanceof CPacketCloseWindow) {
                ClientUtils.displayChatMessage("\u00a7bF\u00a7fnierior \u00a7aClient \u00a7f >> \u00a71CPacketCloseWindow");
            }
            if (packet instanceof CPacketPlayerTryUseItem) {
                ClientUtils.displayChatMessage("\u00a7bF\u00a7fnierior \u00a7aClient \u00a7f >> \u00a71CPacketTryUseItem");
            }
            if (packet instanceof CPacketPlayerTryUseItemOnBlock) {
                ClientUtils.displayChatMessage("\u00a7bF\u00a7fnierior \u00a7aClient \u00a7f >> \u00a71CPacketTryUseItem++");
            }
            if (packet instanceof C08PacketPlayerBlockPlacement) {
                ClientUtils.displayChatMessage("\u00a7bF\u00a7fnierior \u00a7aClient \u00a7f >> \u00a71CPacketPlayerBlockPlacement");
            }
        }
    }

    @NotNull
    public final String getTag() {
        return (String)this.modeValve.get();
    }
}

