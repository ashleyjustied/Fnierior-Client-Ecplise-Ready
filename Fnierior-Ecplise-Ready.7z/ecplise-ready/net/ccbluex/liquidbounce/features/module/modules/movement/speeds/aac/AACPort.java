/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.NotNull
 */
package net.ccbluex.liquidbounce.features.module.modules.movement.speeds.aac;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.api.IClassProvider;
import net.ccbluex.liquidbounce.api.minecraft.client.block.IBlock;
import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntityPlayerSP;
import net.ccbluex.liquidbounce.api.minecraft.util.WBlockPos;
import net.ccbluex.liquidbounce.event.MoveEvent;
import net.ccbluex.liquidbounce.features.module.modules.movement.Speed;
import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.SpeedMode;
import net.ccbluex.liquidbounce.utils.MinecraftInstance;
import net.ccbluex.liquidbounce.utils.MovementUtils;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\b\u0010\u0003\u001a\u00020\u0004H\u0016J\u0010\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u0007H\u0016J\b\u0010\b\u001a\u00020\u0004H\u0016\u00a8\u0006\t"}, d2={"Lnet/ccbluex/liquidbounce/features/module/modules/movement/speeds/aac/AACPort;", "Lnet/ccbluex/liquidbounce/features/module/modules/movement/speeds/SpeedMode;", "()V", "onMotion", "", "onMove", "event", "Lnet/ccbluex/liquidbounce/event/MoveEvent;", "onUpdate", "Fnierior"})
public final class AACPort
extends SpeedMode {
    @Override
    public void onMotion() {
    }

    /*
     * WARNING - void declaration
     */
    @Override
    public void onUpdate() {
        IEntityPlayerSP iEntityPlayerSP = MinecraftInstance.mc.getThePlayer();
        if (iEntityPlayerSP == null) {
            return;
        }
        IEntityPlayerSP thePlayer = iEntityPlayerSP;
        if (!MovementUtils.isMoving()) {
            return;
        }
        float f = thePlayer.getRotationYaw() * ((float)Math.PI / 180);
        double d = 0.2;
        while (true) {
            Speed speed = (Speed)LiquidBounce.INSTANCE.getModuleManager().getModule(Speed.class);
            if (speed == null) {
                Intrinsics.throwNpe();
            }
            if (!(d <= ((Number)speed.getPortMax().get()).doubleValue())) break;
            double d2 = thePlayer.getPosX();
            boolean bl = false;
            float f2 = (float)Math.sin(f);
            double x = d2 - (double)f2 * d;
            d2 = thePlayer.getPosZ();
            boolean bl2 = false;
            f2 = (float)Math.cos(f);
            double z = d2 + (double)f2 * d;
            if (thePlayer.getPosY() < (double)((int)thePlayer.getPosY()) + 0.5) {
                IBlock iBlock;
                void blockPos$iv;
                WBlockPos wBlockPos = new WBlockPos(x, thePlayer.getPosY(), z);
                IClassProvider iClassProvider = MinecraftInstance.classProvider;
                boolean $i$f$getBlock = false;
                Object object = MinecraftInstance.mc.getTheWorld();
                IBlock iBlock2 = object != null && (object = object.getBlockState((WBlockPos)blockPos$iv)) != null ? object.getBlock() : (iBlock = null);
                if (!iClassProvider.isBlockAir(iBlock)) break;
            }
            thePlayer.getSendQueue().addToSendQueue(MinecraftInstance.classProvider.createCPacketPlayerPosition(x, thePlayer.getPosY(), z, true));
            d += 0.2;
        }
    }

    @Override
    public void onMove(@NotNull MoveEvent event) {
        Intrinsics.checkParameterIsNotNull(event, "event");
    }

    public AACPort() {
        super("AACPort");
    }
}

