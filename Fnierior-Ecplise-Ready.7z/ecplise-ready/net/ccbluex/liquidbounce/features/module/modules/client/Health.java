/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.entity.EntityPlayerSP
 *  org.jetbrains.annotations.Nullable
 */
package net.ccbluex.liquidbounce.features.module.modules.client;

import java.awt.Color;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import net.ccbluex.liquidbounce.api.minecraft.client.IMinecraft;
import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntityPlayerSP;
import net.ccbluex.liquidbounce.api.minecraft.util.IScaledResolution;
import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.event.Render2DEvent;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.utils.MinecraftInstance;
import net.ccbluex.liquidbounce.utils.render.BlendUtils;
import net.ccbluex.liquidbounce.value.BoolValue;
import net.ccbluex.liquidbounce.value.IntegerValue;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import org.jetbrains.annotations.Nullable;

@ModuleInfo(name="Health", description="sb.", category=ModuleCategory.FNIERIOR, Chinese="\u8840\u91cf\u663e\u793a")
@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\u0018\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\rH\u0002J\u0012\u0010\u000f\u001a\u00020\u00102\b\u0010\u0011\u001a\u0004\u0018\u00010\u0012H\u0007R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0007X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0007X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0013"}, d2={"Lnet/ccbluex/liquidbounce/features/module/modules/client/Health;", "Lnet/ccbluex/liquidbounce/features/module/Module;", "()V", "cColorValue", "Lnet/ccbluex/liquidbounce/value/BoolValue;", "cFontValue", "colorBlueValue", "Lnet/ccbluex/liquidbounce/value/IntegerValue;", "colorGreenValue", "colorRedValue", "getHealthColor", "", "health", "", "maxHealth", "onRender2D", "", "event", "Lnet/ccbluex/liquidbounce/event/Render2DEvent;", "Fnierior"})
public final class Health
extends Module {
    private final IntegerValue colorRedValue = new IntegerValue("R", 255, 0, 255);
    private final IntegerValue colorGreenValue = new IntegerValue("G", 255, 0, 255);
    private final IntegerValue colorBlueValue = new IntegerValue("B", 255, 0, 255);
    private final BoolValue cColorValue = new BoolValue("CustomColor", false);
    private final BoolValue cFontValue = new BoolValue("CustomFont", false);

    @EventTarget
    public final void onRender2D(@Nullable Render2DEvent event) {
        int n;
        String text;
        IMinecraft iMinecraft = MinecraftInstance.mc;
        Intrinsics.checkExpressionValueIsNotNull(iMinecraft, "mc");
        IScaledResolution sr = MinecraftInstance.classProvider.createScaledResolution(iMinecraft);
        IEntityPlayerSP iEntityPlayerSP = MinecraftInstance.mc.getThePlayer();
        if (iEntityPlayerSP == null) {
            Intrinsics.throwNpe();
        }
        float healthNum = MathKt.roundToInt((double)iEntityPlayerSP.getHealth() * 10.0 / (double)10.0f);
        EntityPlayerSP entityPlayerSP = Minecraft.func_71410_x().field_71439_g;
        Intrinsics.checkExpressionValueIsNotNull(entityPlayerSP, "Minecraft.getMinecraft().player");
        float abNum = MathKt.roundToInt((double)entityPlayerSP.func_110139_bj() * 10.0 / (double)10.0f);
        String abString = (Boolean)this.cFontValue.get() != false ? "\u00a7e" + abNum + "\u00a7r\u2764" : "\u00a7e" + abNum + "\u00a76\u2764";
        EntityPlayerSP entityPlayerSP2 = Minecraft.func_71410_x().field_71439_g;
        Intrinsics.checkExpressionValueIsNotNull(entityPlayerSP2, "Minecraft.getMinecraft().player");
        if (entityPlayerSP2.func_110139_bj() <= 0.0f) {
            abString = "";
        }
        String string = text = (Boolean)this.cFontValue.get() != false ? healthNum + "\u00a7r\u2764 " + abString : healthNum + "\u00a7c\u2764 " + abString;
        if (((Boolean)this.cColorValue.get()).booleanValue()) {
            n = new Color(((Number)this.colorRedValue.get()).intValue(), ((Number)this.colorGreenValue.get()).intValue(), ((Number)this.colorBlueValue.get()).intValue()).getRGB();
        } else {
            IEntityPlayerSP iEntityPlayerSP2 = MinecraftInstance.mc.getThePlayer();
            if (iEntityPlayerSP2 == null) {
                Intrinsics.throwNpe();
            }
            float f = iEntityPlayerSP2.getHealth();
            IEntityPlayerSP iEntityPlayerSP3 = MinecraftInstance.mc.getThePlayer();
            if (iEntityPlayerSP3 == null) {
                Intrinsics.throwNpe();
            }
            n = this.getHealthColor(f, iEntityPlayerSP3.getMaxHealth());
        }
        int c = n;
        MinecraftInstance.mc.getFontRendererObj().drawCenteredString(text, sr.getScaledWidth() / 2, sr.getScaledHeight() / 2 - 25, c, true);
    }

    private final int getHealthColor(float health, float maxHealth) {
        Color customColor;
        float displayhealth = health;
        if (maxHealth > (float)20) {
            displayhealth = 20.0f;
        }
        float[] fractions = new float[]{0.0f, 0.5f, 1.0f};
        Color[] colors = new Color[]{Color.RED, Color.YELLOW, Color.GREEN};
        float progress = displayhealth * (float)5 * 0.01f;
        Color color = BlendUtils.blendColors(fractions, colors, progress);
        if (color == null) {
            Intrinsics.throwNpe();
        }
        Color color2 = customColor = color.brighter();
        Intrinsics.checkExpressionValueIsNotNull(color2, "customColor");
        return color2.getRGB();
    }
}

