/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 *  org.lwjgl.opengl.GL11
 */
package net.ccbluex.liquidbounce.features.module.modules.render;

import java.util.concurrent.CopyOnWriteArrayList;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntityLivingBase;
import net.ccbluex.liquidbounce.api.minecraft.client.entity.IEntityPlayerSP;
import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.event.Render3DEvent;
import net.ccbluex.liquidbounce.event.UpdateEvent;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.utils.MinecraftInstance;
import net.ccbluex.liquidbounce.value.BoolValue;
import net.ccbluex.liquidbounce.value.FloatValue;
import net.ccbluex.liquidbounce.value.IntegerValue;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.opengl.GL11;

@ModuleInfo(Chinese="\u8df3\u5708", name="Jump Circle", category=ModuleCategory.RENDER, description="Skid")
@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u0000J\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u0000 \u001f2\u00020\u0001:\u0002\u001e\u001fB\u0005\u00a2\u0006\u0002\u0010\u0002J\b\u0010\u0017\u001a\u00020\u0018H\u0016J\u0012\u0010\u0019\u001a\u00020\u00182\b\u0010\u001a\u001a\u0004\u0018\u00010\u001bH\u0007J\u0012\u0010\u001c\u001a\u00020\u00182\b\u0010\u001a\u001a\u0004\u0018\u00010\u001dH\u0007R\u001c\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0005\u0010\u0006\"\u0004\b\u0007\u0010\bR\u000e\u0010\t\u001a\u00020\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u000f0\u000eX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0015X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0015X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006 "}, d2={"Lnet/ccbluex/liquidbounce/features/module/modules/render/JumpCircle;", "Lnet/ccbluex/liquidbounce/features/module/Module;", "()V", "allplayer", "Lnet/ccbluex/liquidbounce/api/minecraft/client/entity/IEntityLivingBase;", "getAllplayer", "()Lnet/ccbluex/liquidbounce/api/minecraft/client/entity/IEntityLivingBase;", "setAllplayer", "(Lnet/ccbluex/liquidbounce/api/minecraft/client/entity/IEntityLivingBase;)V", "allplayerlastOnGround", "", "blueValue", "Lnet/ccbluex/liquidbounce/value/IntegerValue;", "circles", "Ljava/util/concurrent/CopyOnWriteArrayList;", "Lnet/ccbluex/liquidbounce/features/module/modules/render/JumpCircle$Circle;", "greenValue", "lastOnGround", "radiusValue", "redValue", "strengthValue", "Lnet/ccbluex/liquidbounce/value/FloatValue;", "widthValue", "onEnable", "", "onRender3D", "ignored", "Lnet/ccbluex/liquidbounce/event/Render3DEvent;", "onUpdate", "Lnet/ccbluex/liquidbounce/event/UpdateEvent;", "Circle", "Companion", "Fnierior"})
public final class JumpCircle
extends Module {
    private final IntegerValue redValue = new IntegerValue("Red", 255, 0, 255);
    private final IntegerValue greenValue = new IntegerValue("Green", 255, 0, 255);
    private final IntegerValue blueValue = new IntegerValue("Blue", 255, 0, 255);
    private final IntegerValue radiusValue = new IntegerValue("Radius", 3, 1, 5);
    private final FloatValue widthValue = new FloatValue("Width", 0.5f, 0.1f, 50.0f);
    private final FloatValue strengthValue = new FloatValue("Strength", 0.02f, 0.01f, 0.2f);
    private final CopyOnWriteArrayList<Circle> circles = new CopyOnWriteArrayList();
    private boolean lastOnGround;
    private boolean allplayerlastOnGround;
    @Nullable
    private IEntityLivingBase allplayer;
    @NotNull
    private static final BoolValue onlyself;
    public static final Companion Companion;

    @Override
    public void onEnable() {
        this.lastOnGround = true;
        this.allplayerlastOnGround = true;
    }

    @Nullable
    public final IEntityLivingBase getAllplayer() {
        return this.allplayer;
    }

    public final void setAllplayer(@Nullable IEntityLivingBase iEntityLivingBase) {
        this.allplayer = iEntityLivingBase;
    }

    @EventTarget
    public final void onUpdate(@Nullable UpdateEvent ignored) {
        if (((Boolean)onlyself.get()).booleanValue()) {
            IEntityPlayerSP iEntityPlayerSP = MinecraftInstance.mc.getThePlayer();
            if (iEntityPlayerSP == null) {
                Intrinsics.throwNpe();
            }
            if (iEntityPlayerSP.getOnGround() && !this.lastOnGround) {
                IEntityPlayerSP iEntityPlayerSP2 = MinecraftInstance.mc.getThePlayer();
                if (iEntityPlayerSP2 == null) {
                    Intrinsics.throwNpe();
                }
                double d = iEntityPlayerSP2.getPosX();
                IEntityPlayerSP iEntityPlayerSP3 = MinecraftInstance.mc.getThePlayer();
                if (iEntityPlayerSP3 == null) {
                    Intrinsics.throwNpe();
                }
                double d2 = iEntityPlayerSP3.getPosY();
                IEntityPlayerSP iEntityPlayerSP4 = MinecraftInstance.mc.getThePlayer();
                if (iEntityPlayerSP4 == null) {
                    Intrinsics.throwNpe();
                }
                double d3 = iEntityPlayerSP4.getPosZ();
                IEntityPlayerSP iEntityPlayerSP5 = MinecraftInstance.mc.getThePlayer();
                if (iEntityPlayerSP5 == null) {
                    Intrinsics.throwNpe();
                }
                double d4 = iEntityPlayerSP5.getLastTickPosX();
                IEntityPlayerSP iEntityPlayerSP6 = MinecraftInstance.mc.getThePlayer();
                if (iEntityPlayerSP6 == null) {
                    Intrinsics.throwNpe();
                }
                double d5 = iEntityPlayerSP6.getLastTickPosY();
                IEntityPlayerSP iEntityPlayerSP7 = MinecraftInstance.mc.getThePlayer();
                if (iEntityPlayerSP7 == null) {
                    Intrinsics.throwNpe();
                }
                this.circles.add(new Circle(d, d2, d3, d4, d5, iEntityPlayerSP7.getLastTickPosZ(), ((Number)this.widthValue.get()).floatValue()));
            }
        } else {
            IEntityLivingBase iEntityLivingBase = this.allplayer;
            if (iEntityLivingBase == null) {
                Intrinsics.throwNpe();
            }
            if (iEntityLivingBase.getOnGround() && !this.allplayerlastOnGround) {
                IEntityLivingBase iEntityLivingBase2 = this.allplayer;
                if (iEntityLivingBase2 == null) {
                    Intrinsics.throwNpe();
                }
                double d = iEntityLivingBase2.getPosX();
                IEntityLivingBase iEntityLivingBase3 = this.allplayer;
                if (iEntityLivingBase3 == null) {
                    Intrinsics.throwNpe();
                }
                double d6 = iEntityLivingBase3.getPosY();
                IEntityLivingBase iEntityLivingBase4 = this.allplayer;
                if (iEntityLivingBase4 == null) {
                    Intrinsics.throwNpe();
                }
                double d7 = iEntityLivingBase4.getPosZ();
                IEntityLivingBase iEntityLivingBase5 = this.allplayer;
                if (iEntityLivingBase5 == null) {
                    Intrinsics.throwNpe();
                }
                double d8 = iEntityLivingBase5.getLastTickPosX();
                IEntityLivingBase iEntityLivingBase6 = this.allplayer;
                if (iEntityLivingBase6 == null) {
                    Intrinsics.throwNpe();
                }
                double d9 = iEntityLivingBase6.getLastTickPosY();
                IEntityLivingBase iEntityLivingBase7 = this.allplayer;
                if (iEntityLivingBase7 == null) {
                    Intrinsics.throwNpe();
                }
                this.circles.add(new Circle(d, d6, d7, d8, d9, iEntityLivingBase7.getLastTickPosZ(), ((Number)this.widthValue.get()).floatValue()));
            }
        }
        IEntityPlayerSP iEntityPlayerSP = MinecraftInstance.mc.getThePlayer();
        if (iEntityPlayerSP == null) {
            Intrinsics.throwNpe();
        }
        this.lastOnGround = iEntityPlayerSP.getOnGround();
        IEntityLivingBase iEntityLivingBase = this.allplayer;
        if (iEntityLivingBase == null) {
            Intrinsics.throwNpe();
        }
        this.allplayerlastOnGround = iEntityLivingBase.getOnGround();
    }

    @EventTarget
    public final void onRender3D(@Nullable Render3DEvent ignored) {
        if (!this.circles.isEmpty()) {
            for (Circle circle : this.circles) {
                if (circle.add(((Number)this.strengthValue.get()).floatValue()) > ((Number)this.radiusValue.get()).doubleValue()) {
                    this.circles.remove(circle);
                    continue;
                }
                GL11.glPushMatrix();
                GL11.glTranslated((double)(circle.getPosX() - MinecraftInstance.mc.getRenderManager().getRenderPosX()), (double)(circle.getPosY() - MinecraftInstance.mc.getRenderManager().getRenderPosY()), (double)(circle.getPosZ() - MinecraftInstance.mc.getRenderManager().getRenderPosZ()));
                GL11.glEnable((int)3042);
                GL11.glEnable((int)2848);
                GL11.glDisable((int)3553);
                GL11.glDisable((int)2929);
                GL11.glBlendFunc((int)770, (int)771);
                GL11.glLineWidth((float)circle.getWidth());
                GL11.glColor4f((float)(((Number)this.redValue.get()).floatValue() / 255.0f), (float)(((Number)this.greenValue.get()).floatValue() / 255.0f), (float)(((Number)this.blueValue.get()).floatValue() / 255.0f), (float)((((Number)this.radiusValue.get()).floatValue() - circle.getRadius()) / ((Number)this.radiusValue.get()).floatValue()));
                GL11.glRotatef((float)90.0f, (float)1.0f, (float)0.0f, (float)0.0f);
                GL11.glBegin((int)3);
                for (int i = 0; i <= 360; i += 5) {
                    GL11.glVertex2f((float)((float)(Math.cos((double)i * Math.PI / 180.0) * (double)circle.getRadius())), (float)((float)(Math.sin((double)i * Math.PI / 180.0) * (double)circle.getRadius())));
                }
                GL11.glEnd();
                GL11.glDisable((int)3042);
                GL11.glEnable((int)3553);
                GL11.glEnable((int)2929);
                GL11.glDisable((int)2848);
                GL11.glPopMatrix();
            }
        }
    }

    static {
        Companion = new Companion(null);
        onlyself = new BoolValue("OnlySelf", true);
    }

    @Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0006\n\u0002\b\u0006\n\u0002\u0010\u0007\n\u0002\b\u0018\b\u0000\u0018\u00002\u00020\u0001B=\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\u0006\u0010\u0007\u001a\u00020\u0003\u0012\u0006\u0010\b\u001a\u00020\u0003\u0012\u0006\u0010\t\u001a\u00020\n\u00a2\u0006\u0002\u0010\u000bJ\u000e\u0010!\u001a\u00020\u00032\u0006\u0010\u001a\u001a\u00020\u0003R\u001a\u0010\u0006\u001a\u00020\u0003X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\r\"\u0004\b\u000e\u0010\u000fR\u001a\u0010\u0007\u001a\u00020\u0003X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0010\u0010\r\"\u0004\b\u0011\u0010\u000fR\u001a\u0010\b\u001a\u00020\u0003X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0012\u0010\r\"\u0004\b\u0013\u0010\u000fR\u001a\u0010\u0002\u001a\u00020\u0003X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0014\u0010\r\"\u0004\b\u0015\u0010\u000fR\u001a\u0010\u0004\u001a\u00020\u0003X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0016\u0010\r\"\u0004\b\u0017\u0010\u000fR\u001a\u0010\u0005\u001a\u00020\u0003X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0018\u0010\r\"\u0004\b\u0019\u0010\u000fR\u001a\u0010\u001a\u001a\u00020\nX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u001b\u0010\u001c\"\u0004\b\u001d\u0010\u001eR\u001a\u0010\t\u001a\u00020\nX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u001f\u0010\u001c\"\u0004\b \u0010\u001e\u00a8\u0006\""}, d2={"Lnet/ccbluex/liquidbounce/features/module/modules/render/JumpCircle$Circle;", "", "posX", "", "posY", "posZ", "lastTickPosX", "lastTickPosY", "lastTickPosZ", "width", "", "(DDDDDDF)V", "getLastTickPosX", "()D", "setLastTickPosX", "(D)V", "getLastTickPosY", "setLastTickPosY", "getLastTickPosZ", "setLastTickPosZ", "getPosX", "setPosX", "getPosY", "setPosY", "getPosZ", "setPosZ", "radius", "getRadius", "()F", "setRadius", "(F)V", "getWidth", "setWidth", "add", "Fnierior"})
    public static final class Circle {
        private float radius;
        private double posX;
        private double posY;
        private double posZ;
        private double lastTickPosX;
        private double lastTickPosY;
        private double lastTickPosZ;
        private float width;

        public final float getRadius() {
            return this.radius;
        }

        public final void setRadius(float f) {
            this.radius = f;
        }

        public final double add(double radius) {
            this.radius += (float)radius;
            return this.radius;
        }

        public final double getPosX() {
            return this.posX;
        }

        public final void setPosX(double d) {
            this.posX = d;
        }

        public final double getPosY() {
            return this.posY;
        }

        public final void setPosY(double d) {
            this.posY = d;
        }

        public final double getPosZ() {
            return this.posZ;
        }

        public final void setPosZ(double d) {
            this.posZ = d;
        }

        public final double getLastTickPosX() {
            return this.lastTickPosX;
        }

        public final void setLastTickPosX(double d) {
            this.lastTickPosX = d;
        }

        public final double getLastTickPosY() {
            return this.lastTickPosY;
        }

        public final void setLastTickPosY(double d) {
            this.lastTickPosY = d;
        }

        public final double getLastTickPosZ() {
            return this.lastTickPosZ;
        }

        public final void setLastTickPosZ(double d) {
            this.lastTickPosZ = d;
        }

        public final float getWidth() {
            return this.width;
        }

        public final void setWidth(float f) {
            this.width = f;
        }

        public Circle(double posX, double posY, double posZ, double lastTickPosX, double lastTickPosY, double lastTickPosZ, float width) {
            this.posX = posX;
            this.posY = posY;
            this.posZ = posZ;
            this.lastTickPosX = lastTickPosX;
            this.lastTickPosY = lastTickPosY;
            this.lastTickPosZ = lastTickPosZ;
            this.width = width;
        }
    }

    @Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u0011\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006\u00a8\u0006\u0007"}, d2={"Lnet/ccbluex/liquidbounce/features/module/modules/render/JumpCircle$Companion;", "", "()V", "onlyself", "Lnet/ccbluex/liquidbounce/value/BoolValue;", "getOnlyself", "()Lnet/ccbluex/liquidbounce/value/BoolValue;", "Fnierior"})
    public static final class Companion {
        @NotNull
        public final BoolValue getOnlyself() {
            return onlyself;
        }

        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker $constructor_marker) {
            this();
        }
    }
}

