/*
 * Decompiled with CFR 0.152.
 */
package net.ccbluex.liquidbounce.features.module;

import java.lang.annotation.RetentionPolicy;
import kotlin.Metadata;
import kotlin.annotation.AnnotationRetention;
import kotlin.annotation.Retention;
import net.ccbluex.liquidbounce.api.MinecraftVersion;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;

@Retention(value=AnnotationRetention.RUNTIME)
@java.lang.annotation.Retention(value=RetentionPolicy.RUNTIME)
@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u001b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0007\b\u0087\u0002\u0018\u00002\u00020\u0001BX\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\u0003\u0012\b\b\u0002\u0010\b\u001a\u00020\t\u0012\b\b\u0002\u0010\n\u001a\u00020\u000b\u0012\b\b\u0002\u0010\f\u001a\u00020\r\u0012\b\b\u0002\u0010\u000e\u001a\u00020\u000b\u0012\u000e\b\u0002\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u00110\u0010R\u000f\u0010\u0007\u001a\u00020\u0003\u00a2\u0006\u0006\u001a\u0004\b\u0007\u0010\u0012R\u000f\u0010\u000e\u001a\u00020\u000b\u00a2\u0006\u0006\u001a\u0004\b\u000e\u0010\u0013R\u000f\u0010\f\u001a\u00020\r\u00a2\u0006\u0006\u001a\u0004\b\f\u0010\u0014R\u000f\u0010\n\u001a\u00020\u000b\u00a2\u0006\u0006\u001a\u0004\b\n\u0010\u0013R\u000f\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\u0006\u001a\u0004\b\u0005\u0010\u0015R\u000f\u0010\u0004\u001a\u00020\u0003\u00a2\u0006\u0006\u001a\u0004\b\u0004\u0010\u0012R\u000f\u0010\b\u001a\u00020\t\u00a2\u0006\u0006\u001a\u0004\b\b\u0010\u0016R\u000f\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0006\u001a\u0004\b\u0002\u0010\u0012R\u0015\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u00110\u0010\u00a2\u0006\u0006\u001a\u0004\b\u000f\u0010\u0017\u00a8\u0006\u0018"}, d2={"Lnet/ccbluex/liquidbounce/features/module/ModuleInfo;", "", "name", "", "description", "category", "Lnet/ccbluex/liquidbounce/features/module/ModuleCategory;", "Chinese", "keyBind", "", "canEnable", "", "autoDisable", "Lnet/ccbluex/liquidbounce/features/module/Module$EnumAutoDisableType;", "array", "supportedVersions", "", "Lnet/ccbluex/liquidbounce/api/MinecraftVersion;", "()Ljava/lang/String;", "()Z", "()Lnet/ccbluex/liquidbounce/features/module/Module$EnumAutoDisableType;", "()Lnet/ccbluex/liquidbounce/features/module/ModuleCategory;", "()I", "()[Lnet/ccbluex/liquidbounce/api/MinecraftVersion;", "Fnierior"})
public @interface ModuleInfo {
    public String name();

    public String description();

    public ModuleCategory category();

    public String Chinese();

    public int keyBind() default 0;

    public boolean canEnable() default true;

    public Module.EnumAutoDisableType autoDisable() default Module.EnumAutoDisableType.NONE;

    public boolean array() default true;

    public MinecraftVersion[] supportedVersions() default {MinecraftVersion.MC_1_8, MinecraftVersion.MC_1_12};
}

