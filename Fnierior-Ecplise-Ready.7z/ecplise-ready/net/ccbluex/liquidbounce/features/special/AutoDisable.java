/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.NotNull
 */
package net.ccbluex.liquidbounce.features.special;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.event.Listenable;
import net.ccbluex.liquidbounce.event.WorldEvent;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.ui.client.hud.element.elements.Notification;
import net.ccbluex.liquidbounce.ui.client.hud.element.elements.NotifyType;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\b\u00c6\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\b\u0010\u0005\u001a\u00020\u0006H\u0016J\u0006\u0010\u0007\u001a\u00020\bJ\u0010\u0010\t\u001a\u00020\b2\u0006\u0010\n\u001a\u00020\u000bH\u0007R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\f"}, d2={"Lnet/ccbluex/liquidbounce/features/special/AutoDisable;", "Lnet/ccbluex/liquidbounce/event/Listenable;", "()V", "name", "", "handleEvents", "", "handleGameEnd", "", "onWorld", "event", "Lnet/ccbluex/liquidbounce/event/WorldEvent;", "Fnierior"})
public final class AutoDisable
implements Listenable {
    private static final String name = "AutoDisable";
    public static final AutoDisable INSTANCE;

    /*
     * WARNING - void declaration
     */
    @EventTarget
    public final void onWorld(@NotNull WorldEvent event) {
        void $this$filterTo$iv$iv;
        Intrinsics.checkParameterIsNotNull(event, "event");
        Iterable $this$filter$iv = LiquidBounce.INSTANCE.getModuleManager().getModules();
        boolean $i$f$filter = false;
        Iterable iterable = $this$filter$iv;
        Collection destination$iv$iv = new ArrayList();
        boolean $i$f$filterTo = false;
        for (Object element$iv$iv : $this$filterTo$iv$iv) {
            Module it = (Module)element$iv$iv;
            boolean bl = false;
            if (!(it.getState() && it.getAutoDisable() == Module.EnumAutoDisableType.RESPAWN && it.getTriggerType() == Module.EnumTriggerType.TOGGLE)) continue;
            destination$iv$iv.add(element$iv$iv);
        }
        Iterable $this$forEach$iv = (List)destination$iv$iv;
        boolean $i$f$forEach = false;
        for (Object element$iv : $this$forEach$iv) {
            Module module = (Module)element$iv;
            boolean bl = false;
            module.setState(false);
            LiquidBounce.INSTANCE.getHud().addNotification(new Notification(name, "\u5173\u95ed " + module.getName() + "\u56e0\u4e3a\u4e16\u754c\u88ab\u6539\u53d8.", NotifyType.WARNING, 2000, 0, 16, null));
        }
    }

    /*
     * WARNING - void declaration
     */
    public final void handleGameEnd() {
        void $this$filterTo$iv$iv;
        Iterable $this$filter$iv = LiquidBounce.INSTANCE.getModuleManager().getModules();
        boolean $i$f$filter = false;
        Iterable iterable = $this$filter$iv;
        Collection destination$iv$iv = new ArrayList();
        boolean $i$f$filterTo = false;
        for (Object element$iv$iv : $this$filterTo$iv$iv) {
            Module it = (Module)element$iv$iv;
            boolean bl = false;
            if (!(it.getState() && it.getAutoDisable() == Module.EnumAutoDisableType.GAME_END)) continue;
            destination$iv$iv.add(element$iv$iv);
        }
        Iterable $this$forEach$iv = (List)destination$iv$iv;
        boolean $i$f$forEach = false;
        for (Object element$iv : $this$forEach$iv) {
            Module module = (Module)element$iv;
            boolean bl = false;
            module.setState(false);
            LiquidBounce.INSTANCE.getHud().addNotification(new Notification(name, "\u5173\u95ed \u300c" + module.getChinese() + "\u300d \u56e0\u4e3a\u6e38\u620f\u7ed3\u675f.", NotifyType.WARNING, 2000, 0, 16, null));
        }
    }

    @Override
    public boolean handleEvents() {
        return true;
    }

    private AutoDisable() {
    }

    static {
        AutoDisable autoDisable;
        INSTANCE = autoDisable = new AutoDisable();
    }
}

