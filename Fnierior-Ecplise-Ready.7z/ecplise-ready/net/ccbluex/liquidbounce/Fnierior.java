/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.GuiScreen
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package net.ccbluex.liquidbounce;

import inferior.ling.LiquidBounceKt;
import inferior.ling.NativeClass;
import java.awt.AWTException;
import java.awt.Image;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.util.ArrayList;
import java.util.Objects;
import javax.imageio.ImageIO;
import kotlin.Metadata;
import kotlin.TypeCastException;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.StringCompanionObject;
import kotlin.text.StringsKt;
import me.manager.CombatManager;
import me.sound.Sound;
import me.utils.AnimationHandler;
import net.ccbluex.liquidbounce.api.Wrapper;
import net.ccbluex.liquidbounce.api.minecraft.util.IResourceLocation;
import net.ccbluex.liquidbounce.cape.CapeAPI;
import net.ccbluex.liquidbounce.event.ClientShutdownEvent;
import net.ccbluex.liquidbounce.event.EventManager;
import net.ccbluex.liquidbounce.features.command.CommandManager;
import net.ccbluex.liquidbounce.features.module.ModuleManager;
import net.ccbluex.liquidbounce.features.module.modules.combat.CancelC03;
import net.ccbluex.liquidbounce.features.special.AntiForge;
import net.ccbluex.liquidbounce.features.special.BungeeCordSpoof;
import net.ccbluex.liquidbounce.features.special.ClientRichPresence;
import net.ccbluex.liquidbounce.features.special.DonatorCape;
import net.ccbluex.liquidbounce.file.FileConfig;
import net.ccbluex.liquidbounce.file.FileManager;
import net.ccbluex.liquidbounce.script.ScriptManager;
import net.ccbluex.liquidbounce.script.remapper.Remapper;
import net.ccbluex.liquidbounce.ui.altmanager.GuiAltManager;
import net.ccbluex.liquidbounce.ui.client.clickgui.ClickGui;
import net.ccbluex.liquidbounce.ui.client.hud.HUD;
import net.ccbluex.liquidbounce.ui.font.Fonts;
import net.ccbluex.liquidbounce.utils.ClientUtils;
import net.ccbluex.liquidbounce.utils.InventoryUtils;
import net.ccbluex.liquidbounce.utils.RotationUtils;
import net.ccbluex.liquidbounce.utils.misc.sound.TipSoundManager;
import net.minecraft.client.gui.GuiScreen;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@NativeClass
@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u0000\u00c8\u0001\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0007\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J&\u0010\u0086\u0001\u001a\u00030\u0087\u00012\u0007\u0010\u0088\u0001\u001a\u00020\u00042\u0007\u0010\u0089\u0001\u001a\u00020\u00042\b\u0010\u008a\u0001\u001a\u00030\u008b\u0001H\u0002J\b\u0010\u008c\u0001\u001a\u00030\u0087\u0001J\b\u0010\u008d\u0001\u001a\u00030\u0087\u0001R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R!\u0010\u000b\u001a\u0012\u0012\u0004\u0012\u00020\u00040\fj\b\u0012\u0004\u0012\u00020\u0004`\r\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0011\u0010\u0010\u001a\u00020\u0011\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R\u001a\u0010\u0014\u001a\u00020\u0015X\u0086.\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0016\u0010\u0017\"\u0004\b\u0018\u0010\u0019R\u001c\u0010\u001a\u001a\u0004\u0018\u00010\u001bX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u001c\u0010\u001d\"\u0004\b\u001e\u0010\u001fR\u001a\u0010 \u001a\u00020!X\u0086.\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\"\u0010#\"\u0004\b$\u0010%R\u001a\u0010&\u001a\u00020'X\u0086.\u00a2\u0006\u000e\n\u0000\u001a\u0004\b(\u0010)\"\u0004\b*\u0010+R\u001a\u0010,\u001a\u00020-X\u0086.\u00a2\u0006\u000e\n\u0000\u001a\u0004\b.\u0010/\"\u0004\b0\u00101R\u001a\u00102\u001a\u000203X\u0086.\u00a2\u0006\u000e\n\u0000\u001a\u0004\b4\u00105\"\u0004\b6\u00107R\u001a\u00108\u001a\u00020\tX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b9\u0010:\"\u0004\b;\u0010<R\u001a\u0010=\u001a\u00020>X\u0086.\u00a2\u0006\u000e\n\u0000\u001a\u0004\b?\u0010@\"\u0004\bA\u0010BR\u001a\u0010C\u001a\u00020DX\u0086.\u00a2\u0006\u000e\n\u0000\u001a\u0004\bE\u0010F\"\u0004\bG\u0010HR\u001a\u0010I\u001a\u00020JX\u0086.\u00a2\u0006\u000e\n\u0000\u001a\u0004\bK\u0010L\"\u0004\bM\u0010NR\u001a\u0010O\u001a\u00020\tX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\bO\u0010:\"\u0004\bP\u0010<R\u001a\u0010Q\u001a\u00020RX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\bS\u0010T\"\u0004\bU\u0010VR\u001a\u0010W\u001a\u00020XX\u0086.\u00a2\u0006\u000e\n\u0000\u001a\u0004\bY\u0010Z\"\u0004\b[\u0010\\R\u001a\u0010]\u001a\u00020\tX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b^\u0010:\"\u0004\b_\u0010<R\u001a\u0010`\u001a\u00020aX\u0086.\u00a2\u0006\u000e\n\u0000\u001a\u0004\bb\u0010c\"\u0004\bd\u0010eR\u001a\u0010f\u001a\u00020gX\u0086.\u00a2\u0006\u000e\n\u0000\u001a\u0004\bh\u0010i\"\u0004\bj\u0010kR\u001a\u0010l\u001a\u00020mX\u0086.\u00a2\u0006\u000e\n\u0000\u001a\u0004\bn\u0010o\"\u0004\bp\u0010qR\u001a\u0010r\u001a\u00020sX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\bt\u0010u\"\u0004\bv\u0010wR\u001c\u0010x\u001a\u0004\u0018\u00010yX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\bz\u0010{\"\u0004\b|\u0010}R\u0011\u0010~\u001a\u00020\t\u00a2\u0006\b\n\u0000\u001a\u0004\b\u007f\u0010:R \u0010\u0080\u0001\u001a\u00030\u0081\u0001X\u0086.\u00a2\u0006\u0012\n\u0000\u001a\u0006\b\u0082\u0001\u0010\u0083\u0001\"\u0006\b\u0084\u0001\u0010\u0085\u0001\u00a8\u0006\u008e\u0001"}, d2={"Lnet/ccbluex/liquidbounce/Fnierior;", "", "()V", "CLIENT_CLOUD", "", "CLIENT_CREATOR", "CLIENT_NAME", "CLIENT_VERSION", "IN_DEV", "", "MINECRAFT_VERSION", "UPDATE_LIST", "Ljava/util/ArrayList;", "Lkotlin/collections/ArrayList;", "getUPDATE_LIST", "()Ljava/util/ArrayList;", "Username", "Lkotlin/String$Companion;", "getUsername", "()Lkotlin/jvm/internal/StringCompanionObject;", "animationHandler", "Lme/utils/AnimationHandler;", "getAnimationHandler", "()Lme/utils/AnimationHandler;", "setAnimationHandler", "(Lme/utils/AnimationHandler;)V", "background", "Lnet/ccbluex/liquidbounce/api/minecraft/util/IResourceLocation;", "getBackground", "()Lnet/ccbluex/liquidbounce/api/minecraft/util/IResourceLocation;", "setBackground", "(Lnet/ccbluex/liquidbounce/api/minecraft/util/IResourceLocation;)V", "clickGui", "Lnet/ccbluex/liquidbounce/ui/client/clickgui/ClickGui;", "getClickGui", "()Lnet/ccbluex/liquidbounce/ui/client/clickgui/ClickGui;", "setClickGui", "(Lnet/ccbluex/liquidbounce/ui/client/clickgui/ClickGui;)V", "clientRichPresence", "Lnet/ccbluex/liquidbounce/features/special/ClientRichPresence;", "getClientRichPresence", "()Lnet/ccbluex/liquidbounce/features/special/ClientRichPresence;", "setClientRichPresence", "(Lnet/ccbluex/liquidbounce/features/special/ClientRichPresence;)V", "combatManager", "Lme/manager/CombatManager;", "getCombatManager", "()Lme/manager/CombatManager;", "setCombatManager", "(Lme/manager/CombatManager;)V", "commandManager", "Lnet/ccbluex/liquidbounce/features/command/CommandManager;", "getCommandManager", "()Lnet/ccbluex/liquidbounce/features/command/CommandManager;", "setCommandManager", "(Lnet/ccbluex/liquidbounce/features/command/CommandManager;)V", "darkMode", "getDarkMode", "()Z", "setDarkMode", "(Z)V", "eventManager", "Lnet/ccbluex/liquidbounce/event/EventManager;", "getEventManager", "()Lnet/ccbluex/liquidbounce/event/EventManager;", "setEventManager", "(Lnet/ccbluex/liquidbounce/event/EventManager;)V", "fileManager", "Lnet/ccbluex/liquidbounce/file/FileManager;", "getFileManager", "()Lnet/ccbluex/liquidbounce/file/FileManager;", "setFileManager", "(Lnet/ccbluex/liquidbounce/file/FileManager;)V", "hud", "Lnet/ccbluex/liquidbounce/ui/client/hud/HUD;", "getHud", "()Lnet/ccbluex/liquidbounce/ui/client/hud/HUD;", "setHud", "(Lnet/ccbluex/liquidbounce/ui/client/hud/HUD;)V", "isStarting", "setStarting", "latestVersion", "", "getLatestVersion", "()I", "setLatestVersion", "(I)V", "mainMenu", "Lnet/minecraft/client/gui/GuiScreen;", "getMainMenu", "()Lnet/minecraft/client/gui/GuiScreen;", "setMainMenu", "(Lnet/minecraft/client/gui/GuiScreen;)V", "mainMenuPrep", "getMainMenuPrep", "setMainMenuPrep", "moduleManager", "Lnet/ccbluex/liquidbounce/features/module/ModuleManager;", "getModuleManager", "()Lnet/ccbluex/liquidbounce/features/module/ModuleManager;", "setModuleManager", "(Lnet/ccbluex/liquidbounce/features/module/ModuleManager;)V", "scriptManager", "Lnet/ccbluex/liquidbounce/script/ScriptManager;", "getScriptManager", "()Lnet/ccbluex/liquidbounce/script/ScriptManager;", "setScriptManager", "(Lnet/ccbluex/liquidbounce/script/ScriptManager;)V", "tipSoundManager", "Lnet/ccbluex/liquidbounce/utils/misc/sound/TipSoundManager;", "getTipSoundManager", "()Lnet/ccbluex/liquidbounce/utils/misc/sound/TipSoundManager;", "setTipSoundManager", "(Lnet/ccbluex/liquidbounce/utils/misc/sound/TipSoundManager;)V", "toggleVolume", "", "getToggleVolume", "()F", "setToggleVolume", "(F)V", "trayIcon", "Ljava/awt/TrayIcon;", "getTrayIcon", "()Ljava/awt/TrayIcon;", "setTrayIcon", "(Ljava/awt/TrayIcon;)V", "windows", "getWindows", "wrapper", "Lnet/ccbluex/liquidbounce/api/Wrapper;", "getWrapper", "()Lnet/ccbluex/liquidbounce/api/Wrapper;", "setWrapper", "(Lnet/ccbluex/liquidbounce/api/Wrapper;)V", "displayTray", "", "Title", "Text", "type", "Ljava/awt/TrayIcon$MessageType;", "startClient", "stopClient", "Fnierior"})
public final class Fnierior {
    @NotNull
    public static final String CLIENT_NAME = "Fnierior";
    @NotNull
    public static final String CLIENT_VERSION = "#0604";
    public static final boolean IN_DEV = true;
    @NotNull
    public static final String CLIENT_CREATOR = "\u7b26\u6faa";
    @NotNull
    public static GuiScreen mainMenu;
    @NotNull
    public static final String MINECRAFT_VERSION = "1.12.2";
    @NotNull
    private static final StringCompanionObject Username;
    @NotNull
    public static final String CLIENT_CLOUD = "https://cloud.liquidbounce.net/LiquidBounce";
    @NotNull
    private static final ArrayList<String> UPDATE_LIST;
    private static boolean isStarting;
    private static boolean mainMenuPrep;
    private static boolean darkMode;
    @NotNull
    public static ModuleManager moduleManager;
    @NotNull
    public static CommandManager commandManager;
    @NotNull
    public static EventManager eventManager;
    @NotNull
    public static FileManager fileManager;
    @NotNull
    public static ScriptManager scriptManager;
    @NotNull
    public static CombatManager combatManager;
    @NotNull
    public static TipSoundManager tipSoundManager;
    private static float toggleVolume;
    private static final boolean windows;
    @Nullable
    private static TrayIcon trayIcon;
    @NotNull
    public static HUD hud;
    @NotNull
    public static AnimationHandler animationHandler;
    @NotNull
    public static ClickGui clickGui;
    private static int latestVersion;
    @Nullable
    private static IResourceLocation background;
    @NotNull
    public static ClientRichPresence clientRichPresence;
    @NotNull
    public static Wrapper wrapper;
    public static final Fnierior INSTANCE;

    @NotNull
    public final GuiScreen getMainMenu() {
        GuiScreen guiScreen = mainMenu;
        if (guiScreen == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mainMenu");
        }
        return guiScreen;
    }

    public final void setMainMenu(@NotNull GuiScreen guiScreen) {
        Intrinsics.checkParameterIsNotNull(guiScreen, "<set-?>");
        mainMenu = guiScreen;
    }

    @NotNull
    public final StringCompanionObject getUsername() {
        return Username;
    }

    @NotNull
    public final ArrayList<String> getUPDATE_LIST() {
        return UPDATE_LIST;
    }

    public final boolean isStarting() {
        return isStarting;
    }

    public final void setStarting(boolean bl) {
        isStarting = bl;
    }

    public final boolean getMainMenuPrep() {
        return mainMenuPrep;
    }

    public final void setMainMenuPrep(boolean bl) {
        mainMenuPrep = bl;
    }

    public final boolean getDarkMode() {
        return darkMode;
    }

    public final void setDarkMode(boolean bl) {
        darkMode = bl;
    }

    @NotNull
    public final ModuleManager getModuleManager() {
        ModuleManager moduleManager = Fnierior.moduleManager;
        if (moduleManager == null) {
            Intrinsics.throwUninitializedPropertyAccessException("moduleManager");
        }
        return moduleManager;
    }

    public final void setModuleManager(@NotNull ModuleManager moduleManager) {
        Intrinsics.checkParameterIsNotNull(moduleManager, "<set-?>");
        Fnierior.moduleManager = moduleManager;
    }

    @NotNull
    public final CommandManager getCommandManager() {
        CommandManager commandManager = Fnierior.commandManager;
        if (commandManager == null) {
            Intrinsics.throwUninitializedPropertyAccessException("commandManager");
        }
        return commandManager;
    }

    public final void setCommandManager(@NotNull CommandManager commandManager) {
        Intrinsics.checkParameterIsNotNull(commandManager, "<set-?>");
        Fnierior.commandManager = commandManager;
    }

    @NotNull
    public final EventManager getEventManager() {
        EventManager eventManager = Fnierior.eventManager;
        if (eventManager == null) {
            Intrinsics.throwUninitializedPropertyAccessException("eventManager");
        }
        return eventManager;
    }

    public final void setEventManager(@NotNull EventManager eventManager) {
        Intrinsics.checkParameterIsNotNull(eventManager, "<set-?>");
        Fnierior.eventManager = eventManager;
    }

    @NotNull
    public final FileManager getFileManager() {
        FileManager fileManager = Fnierior.fileManager;
        if (fileManager == null) {
            Intrinsics.throwUninitializedPropertyAccessException("fileManager");
        }
        return fileManager;
    }

    public final void setFileManager(@NotNull FileManager fileManager) {
        Intrinsics.checkParameterIsNotNull(fileManager, "<set-?>");
        Fnierior.fileManager = fileManager;
    }

    @NotNull
    public final ScriptManager getScriptManager() {
        ScriptManager scriptManager = Fnierior.scriptManager;
        if (scriptManager == null) {
            Intrinsics.throwUninitializedPropertyAccessException("scriptManager");
        }
        return scriptManager;
    }

    public final void setScriptManager(@NotNull ScriptManager scriptManager) {
        Intrinsics.checkParameterIsNotNull(scriptManager, "<set-?>");
        Fnierior.scriptManager = scriptManager;
    }

    @NotNull
    public final CombatManager getCombatManager() {
        CombatManager combatManager = Fnierior.combatManager;
        if (combatManager == null) {
            Intrinsics.throwUninitializedPropertyAccessException("combatManager");
        }
        return combatManager;
    }

    public final void setCombatManager(@NotNull CombatManager combatManager) {
        Intrinsics.checkParameterIsNotNull(combatManager, "<set-?>");
        Fnierior.combatManager = combatManager;
    }

    @NotNull
    public final TipSoundManager getTipSoundManager() {
        TipSoundManager tipSoundManager = Fnierior.tipSoundManager;
        if (tipSoundManager == null) {
            Intrinsics.throwUninitializedPropertyAccessException("tipSoundManager");
        }
        return tipSoundManager;
    }

    public final void setTipSoundManager(@NotNull TipSoundManager tipSoundManager) {
        Intrinsics.checkParameterIsNotNull(tipSoundManager, "<set-?>");
        Fnierior.tipSoundManager = tipSoundManager;
    }

    public final float getToggleVolume() {
        return toggleVolume;
    }

    public final void setToggleVolume(float f) {
        toggleVolume = f;
    }

    public final boolean getWindows() {
        return windows;
    }

    @Nullable
    public final TrayIcon getTrayIcon() {
        return trayIcon;
    }

    public final void setTrayIcon(@Nullable TrayIcon trayIcon) {
        Fnierior.trayIcon = trayIcon;
    }

    @NotNull
    public final HUD getHud() {
        HUD hUD = hud;
        if (hUD == null) {
            Intrinsics.throwUninitializedPropertyAccessException("hud");
        }
        return hUD;
    }

    public final void setHud(@NotNull HUD hUD) {
        Intrinsics.checkParameterIsNotNull(hUD, "<set-?>");
        hud = hUD;
    }

    @NotNull
    public final AnimationHandler getAnimationHandler() {
        AnimationHandler animationHandler = Fnierior.animationHandler;
        if (animationHandler == null) {
            Intrinsics.throwUninitializedPropertyAccessException("animationHandler");
        }
        return animationHandler;
    }

    public final void setAnimationHandler(@NotNull AnimationHandler animationHandler) {
        Intrinsics.checkParameterIsNotNull(animationHandler, "<set-?>");
        Fnierior.animationHandler = animationHandler;
    }

    @NotNull
    public final ClickGui getClickGui() {
        ClickGui clickGui = Fnierior.clickGui;
        if (clickGui == null) {
            Intrinsics.throwUninitializedPropertyAccessException("clickGui");
        }
        return clickGui;
    }

    public final void setClickGui(@NotNull ClickGui clickGui) {
        Intrinsics.checkParameterIsNotNull(clickGui, "<set-?>");
        Fnierior.clickGui = clickGui;
    }

    public final int getLatestVersion() {
        return latestVersion;
    }

    public final void setLatestVersion(int n) {
        latestVersion = n;
    }

    @Nullable
    public final IResourceLocation getBackground() {
        return background;
    }

    public final void setBackground(@Nullable IResourceLocation iResourceLocation) {
        background = iResourceLocation;
    }

    @NotNull
    public final ClientRichPresence getClientRichPresence() {
        ClientRichPresence clientRichPresence = Fnierior.clientRichPresence;
        if (clientRichPresence == null) {
            Intrinsics.throwUninitializedPropertyAccessException("clientRichPresence");
        }
        return clientRichPresence;
    }

    public final void setClientRichPresence(@NotNull ClientRichPresence clientRichPresence) {
        Intrinsics.checkParameterIsNotNull(clientRichPresence, "<set-?>");
        Fnierior.clientRichPresence = clientRichPresence;
    }

    @NotNull
    public final Wrapper getWrapper() {
        Wrapper wrapper = Fnierior.wrapper;
        if (wrapper == null) {
            Intrinsics.throwUninitializedPropertyAccessException("wrapper");
        }
        return wrapper;
    }

    public final void setWrapper(@NotNull Wrapper wrapper) {
        Intrinsics.checkParameterIsNotNull(wrapper, "<set-?>");
        Fnierior.wrapper = wrapper;
    }

    private final void displayTray(String Title2, String Text2, TrayIcon.MessageType type) throws AWTException {
        SystemTray tray = SystemTray.getSystemTray();
        Image image2 = Toolkit.getDefaultToolkit().createImage("icon.png");
        TrayIcon trayIcon = new TrayIcon(image2, "Tray Demo");
        trayIcon.setImageAutoSize(true);
        trayIcon.setToolTip("System tray icon demo");
        tray.add(trayIcon);
        trayIcon.displayMessage(Title2, Text2, type);
    }

    public final void startClient() {
        isStarting = true;
        ClientUtils.getLogger().info("Starting Fnierior b#0604, by \u7b26\u6faa");
        fileManager = new FileManager();
        EventManager eventManager = Fnierior.eventManager = new EventManager();
        if (eventManager == null) {
            Intrinsics.throwUninitializedPropertyAccessException("eventManager");
        }
        eventManager.registerListener(new RotationUtils());
        EventManager eventManager2 = Fnierior.eventManager;
        if (eventManager2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("eventManager");
        }
        eventManager2.registerListener(new AntiForge());
        EventManager eventManager3 = Fnierior.eventManager;
        if (eventManager3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("eventManager");
        }
        eventManager3.registerListener(new BungeeCordSpoof());
        EventManager eventManager4 = Fnierior.eventManager;
        if (eventManager4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("eventManager");
        }
        eventManager4.registerListener(new DonatorCape());
        EventManager eventManager5 = Fnierior.eventManager;
        if (eventManager5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("eventManager");
        }
        eventManager5.registerListener(new InventoryUtils());
        tipSoundManager = new TipSoundManager();
        clientRichPresence = new ClientRichPresence();
        combatManager = new CombatManager();
        EventManager eventManager6 = Fnierior.eventManager;
        if (eventManager6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("eventManager");
        }
        CombatManager combatManager = Fnierior.combatManager;
        if (combatManager == null) {
            Intrinsics.throwUninitializedPropertyAccessException("combatManager");
        }
        eventManager6.registerListener(combatManager);
        commandManager = new CommandManager();
        Fonts.loadFonts();
        ModuleManager moduleManager = Fnierior.moduleManager = new ModuleManager();
        if (moduleManager == null) {
            Intrinsics.throwUninitializedPropertyAccessException("moduleManager");
        }
        moduleManager.registerModules();
        animationHandler = new AnimationHandler();
        try {
            Remapper.INSTANCE.loadSrg();
            ScriptManager scriptManager = Fnierior.scriptManager = new ScriptManager();
            if (scriptManager == null) {
                Intrinsics.throwUninitializedPropertyAccessException("scriptManager");
            }
            scriptManager.loadScripts();
            ScriptManager scriptManager2 = Fnierior.scriptManager;
            if (scriptManager2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("scriptManager");
            }
            scriptManager2.enableScripts();
        }
        catch (Throwable throwable) {
            ClientUtils.getLogger().error("Failed to load scripts.", throwable);
        }
        CommandManager commandManager = Fnierior.commandManager;
        if (commandManager == null) {
            Intrinsics.throwUninitializedPropertyAccessException("commandManager");
        }
        commandManager.registerCommands();
        FileManager fileManager = Fnierior.fileManager;
        if (fileManager == null) {
            Intrinsics.throwUninitializedPropertyAccessException("fileManager");
        }
        FileConfig[] fileConfigArray = new FileConfig[6];
        FileManager fileManager2 = Fnierior.fileManager;
        if (fileManager2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("fileManager");
        }
        fileConfigArray[0] = fileManager2.modulesConfig;
        FileManager fileManager3 = Fnierior.fileManager;
        if (fileManager3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("fileManager");
        }
        fileConfigArray[1] = fileManager3.valuesConfig;
        FileManager fileManager4 = Fnierior.fileManager;
        if (fileManager4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("fileManager");
        }
        fileConfigArray[2] = fileManager4.accountsConfig;
        FileManager fileManager5 = Fnierior.fileManager;
        if (fileManager5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("fileManager");
        }
        fileConfigArray[3] = fileManager5.friendsConfig;
        FileManager fileManager6 = Fnierior.fileManager;
        if (fileManager6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("fileManager");
        }
        fileConfigArray[4] = fileManager6.xrayConfig;
        FileManager fileManager7 = Fnierior.fileManager;
        if (fileManager7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("fileManager");
        }
        fileConfigArray[5] = fileManager7.shortcutsConfig;
        fileManager.loadConfigs(fileConfigArray);
        clickGui = new ClickGui();
        FileManager fileManager8 = Fnierior.fileManager;
        if (fileManager8 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("fileManager");
        }
        FileManager fileManager9 = Fnierior.fileManager;
        if (fileManager9 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("fileManager");
        }
        fileManager8.loadConfig(fileManager9.clickGuiConfig);
        try {
            CapeAPI.INSTANCE.registerCapeService();
        }
        catch (Throwable throwable) {
            ClientUtils.getLogger().error("Failed to register cape service", throwable);
        }
        hud = HUD.Companion.createDefault();
        FileManager fileManager10 = Fnierior.fileManager;
        if (fileManager10 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("fileManager");
        }
        FileManager fileManager11 = Fnierior.fileManager;
        if (fileManager11 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("fileManager");
        }
        fileManager10.loadConfig(fileManager11.hudConfig);
        ClientUtils.disableFastRender();
        GuiAltManager.loadGenerators();
        CancelC03.checkMom();
        LiquidBounceKt.HWIDVerify();
        if (windows && SystemTray.isSupported()) {
            try {
                trayIcon = new TrayIcon(ImageIO.read(Objects.requireNonNull(this.getClass().getResourceAsStream("/assets/minecraft/pride/icon128.png"))));
            }
            catch (Exception e) {
                e.printStackTrace();
            }
            TrayIcon trayIcon = Fnierior.trayIcon;
            if (trayIcon != null) {
                trayIcon.setImageAutoSize(true);
            }
            TrayIcon trayIcon2 = Fnierior.trayIcon;
            if (trayIcon2 != null) {
                trayIcon2.setToolTip(CLIENT_NAME);
            }
            try {
                SystemTray.getSystemTray().add(Fnierior.trayIcon);
            }
            catch (AWTException aWTException) {
                // empty catch block
            }
            TrayIcon trayIcon3 = Fnierior.trayIcon;
            if (trayIcon3 != null) {
                trayIcon3.displayMessage(CLIENT_NAME, "\u611f\u8c22\u4f7f\u7528Fnierior", TrayIcon.MessageType.NONE);
            }
            Sound.notificationsAllowed(true);
        }
        new Sound();
        isStarting = false;
    }

    public final void stopClient() {
        EventManager eventManager = Fnierior.eventManager;
        if (eventManager == null) {
            Intrinsics.throwUninitializedPropertyAccessException("eventManager");
        }
        eventManager.callEvent(new ClientShutdownEvent());
        FileManager fileManager = Fnierior.fileManager;
        if (fileManager == null) {
            Intrinsics.throwUninitializedPropertyAccessException("fileManager");
        }
        fileManager.saveAllConfigs();
        ClientRichPresence clientRichPresence = Fnierior.clientRichPresence;
        if (clientRichPresence == null) {
            Intrinsics.throwUninitializedPropertyAccessException("clientRichPresence");
        }
        clientRichPresence.shutdown();
    }

    private Fnierior() {
    }

    static {
        Fnierior fnierior;
        INSTANCE = fnierior = new Fnierior();
        Username = StringCompanionObject.INSTANCE;
        UPDATE_LIST = CollectionsKt.arrayListOf("QQ Group 519931150 ", "Update Logs : ", "Build 47", "Build 46", "1.Update UI", "2.Bypass GrimAC", "Build 45", "1.Add Some Modules", "2.Fuck", "Build 44", "1.Better Velocity", "2.Better NoSlow", "3.114514");
        String string = System.getProperties().getProperty("os.name");
        Intrinsics.checkExpressionValueIsNotNull(string, "System.getProperties().getProperty(\"os.name\")");
        String string2 = string;
        boolean bl = false;
        String string3 = string2;
        if (string3 == null) {
            throw new TypeCastException("null cannot be cast to non-null type java.lang.String");
        }
        String string4 = string3.toLowerCase();
        Intrinsics.checkExpressionValueIsNotNull(string4, "(this as java.lang.String).toLowerCase()");
        windows = StringsKt.contains$default((CharSequence)string4, "windows", false, 2, null);
    }
}

