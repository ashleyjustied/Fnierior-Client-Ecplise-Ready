/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.GuiScreen
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package net.ccbluex.liquidbounce;

import cn.hanabi.gui.cloudmusic.MusicManager;
import inferior.ling.EaseVerify;
import inferior.ling.NativeClass;
import inferior.ling.client.NewGuiWelcome;
import java.awt.AWTException;
import java.awt.Image;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.util.Objects;
import javax.imageio.ImageIO;
import kotlin.Metadata;
import kotlin.TypeCastException;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.StringCompanionObject;
import kotlin.text.StringsKt;
import me.manager.CombatManager;
import me.sound.Sound;
import me.utils.AnimationHandler;
import me.utils.QQUtils;
import net.ccbluex.liquidbounce.api.Wrapper;
import net.ccbluex.liquidbounce.api.minecraft.util.IResourceLocation;
import net.ccbluex.liquidbounce.cape.CapeAPI;
import net.ccbluex.liquidbounce.event.ClientShutdownEvent;
import net.ccbluex.liquidbounce.event.EventManager;
import net.ccbluex.liquidbounce.features.command.CommandManager;
import net.ccbluex.liquidbounce.features.module.ModuleManager;
import net.ccbluex.liquidbounce.features.special.AntiForge;
import net.ccbluex.liquidbounce.features.special.BungeeCordSpoof;
import net.ccbluex.liquidbounce.features.special.ClientRichPresence;
import net.ccbluex.liquidbounce.features.special.DonatorCape;
import net.ccbluex.liquidbounce.file.FileConfig;
import net.ccbluex.liquidbounce.file.FileManager;
import net.ccbluex.liquidbounce.script.ScriptManager;
import net.ccbluex.liquidbounce.script.remapper.Remapper;
import net.ccbluex.liquidbounce.ui.altmanager.GuiAltManager;
import net.ccbluex.liquidbounce.ui.client.clickgui.ClickGui;
import net.ccbluex.liquidbounce.ui.client.hud.HUD;
import net.ccbluex.liquidbounce.ui.cnfont.FontLoaders;
import net.ccbluex.liquidbounce.ui.font.Fonts;
import net.ccbluex.liquidbounce.utils.ClientUtils;
import net.ccbluex.liquidbounce.utils.InventoryUtils;
import net.ccbluex.liquidbounce.utils.RotationUtils;
import net.ccbluex.liquidbounce.utils.misc.sound.TipSoundManager;
import net.minecraft.client.gui.GuiScreen;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@NativeClass
@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u0000\u00cc\u0001\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0010\b\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0007\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J&\u0010\u0093\u0001\u001a\u00030\u0094\u00012\u0007\u0010\u0095\u0001\u001a\u00020\u00042\u0007\u0010\u0096\u0001\u001a\u00020\u00042\b\u0010\u0097\u0001\u001a\u00030\u0098\u0001H\u0002J\u0007\u0010\u0099\u0001\u001a\u00020\u0004J\b\u0010\u009a\u0001\u001a\u00030\u0094\u0001J\b\u0010\u009b\u0001\u001a\u00030\u0094\u0001R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u001a\u0010\t\u001a\u00020\nX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u000b\u0010\f\"\u0004\b\r\u0010\u000eR\u000e\u0010\u000f\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u0010\u001a\u00020\u0011X\u0086.\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0012\u0010\u0013\"\u0004\b\u0014\u0010\u0015R\u001c\u0010\u0016\u001a\u0004\u0018\u00010\u0017X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0018\u0010\u0019\"\u0004\b\u001a\u0010\u001bR\u001a\u0010\u001c\u001a\u00020\u001dX\u0086.\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u001e\u0010\u001f\"\u0004\b \u0010!R\u001a\u0010\"\u001a\u00020#X\u0086.\u00a2\u0006\u000e\n\u0000\u001a\u0004\b$\u0010%\"\u0004\b&\u0010'R\u001a\u0010(\u001a\u00020)X\u0086.\u00a2\u0006\u000e\n\u0000\u001a\u0004\b*\u0010+\"\u0004\b,\u0010-R\u001a\u0010.\u001a\u00020/X\u0086.\u00a2\u0006\u000e\n\u0000\u001a\u0004\b0\u00101\"\u0004\b2\u00103R\u001a\u00104\u001a\u000205X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b6\u00107\"\u0004\b8\u00109R\u001a\u0010:\u001a\u00020;X\u0086.\u00a2\u0006\u000e\n\u0000\u001a\u0004\b<\u0010=\"\u0004\b>\u0010?R\u001a\u0010@\u001a\u00020AX\u0086.\u00a2\u0006\u000e\n\u0000\u001a\u0004\bB\u0010C\"\u0004\bD\u0010ER\u001a\u0010F\u001a\u00020GX\u0086.\u00a2\u0006\u000e\n\u0000\u001a\u0004\bH\u0010I\"\u0004\bJ\u0010KR\u001a\u0010L\u001a\u00020MX\u0086.\u00a2\u0006\u000e\n\u0000\u001a\u0004\bN\u0010O\"\u0004\bP\u0010QR\u001a\u0010R\u001a\u00020SX\u0086.\u00a2\u0006\u000e\n\u0000\u001a\u0004\bT\u0010U\"\u0004\bV\u0010WR\u001a\u0010X\u001a\u000205X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\bX\u00107\"\u0004\bY\u00109R\u001a\u0010Z\u001a\u000205X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\bZ\u00107\"\u0004\b[\u00109R\u001a\u0010\\\u001a\u000205X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\\\u00107\"\u0004\b]\u00109R\u001a\u0010^\u001a\u00020_X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b`\u0010a\"\u0004\bb\u0010cR\u001a\u0010d\u001a\u000205X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\be\u00107\"\u0004\bf\u00109R\u001a\u0010g\u001a\u00020hX\u0086.\u00a2\u0006\u000e\n\u0000\u001a\u0004\bi\u0010j\"\u0004\bk\u0010lR\u001a\u0010m\u001a\u00020nX\u0086.\u00a2\u0006\u000e\n\u0000\u001a\u0004\bo\u0010p\"\u0004\bq\u0010rR\u001a\u0010s\u001a\u00020tX\u0086.\u00a2\u0006\u000e\n\u0000\u001a\u0004\bu\u0010v\"\u0004\bw\u0010xR\u001a\u0010y\u001a\u00020zX\u0086.\u00a2\u0006\u000e\n\u0000\u001a\u0004\b{\u0010|\"\u0004\b}\u0010~R\u001f\u0010\u007f\u001a\u00030\u0080\u0001X\u0086\u000e\u00a2\u0006\u0012\n\u0000\u001a\u0006\b\u0081\u0001\u0010\u0082\u0001\"\u0006\b\u0083\u0001\u0010\u0084\u0001R\"\u0010\u0085\u0001\u001a\u0005\u0018\u00010\u0086\u0001X\u0086\u000e\u00a2\u0006\u0012\n\u0000\u001a\u0006\b\u0087\u0001\u0010\u0088\u0001\"\u0006\b\u0089\u0001\u0010\u008a\u0001R\u0013\u0010\u008b\u0001\u001a\u000205\u00a2\u0006\t\n\u0000\u001a\u0005\b\u008c\u0001\u00107R \u0010\u008d\u0001\u001a\u00030\u008e\u0001X\u0086.\u00a2\u0006\u0012\n\u0000\u001a\u0006\b\u008f\u0001\u0010\u0090\u0001\"\u0006\b\u0091\u0001\u0010\u0092\u0001\u00a8\u0006\u009c\u0001"}, d2={"Lnet/ccbluex/liquidbounce/LiquidBounce;", "", "()V", "CLIENT_CLOUD", "", "CLIENT_CREATOR", "CLIENT_NAME", "CLIENT_VERSION", "MINECRAFT_VERSION", "Ranking", "Lkotlin/String$Companion;", "getRanking", "()Lkotlin/jvm/internal/StringCompanionObject;", "setRanking", "(Lkotlin/jvm/internal/StringCompanionObject;)V", "SPECIAL_DEV", "animationHandler", "Lme/utils/AnimationHandler;", "getAnimationHandler", "()Lme/utils/AnimationHandler;", "setAnimationHandler", "(Lme/utils/AnimationHandler;)V", "background", "Lnet/ccbluex/liquidbounce/api/minecraft/util/IResourceLocation;", "getBackground", "()Lnet/ccbluex/liquidbounce/api/minecraft/util/IResourceLocation;", "setBackground", "(Lnet/ccbluex/liquidbounce/api/minecraft/util/IResourceLocation;)V", "clickGui", "Lnet/ccbluex/liquidbounce/ui/client/clickgui/ClickGui;", "getClickGui", "()Lnet/ccbluex/liquidbounce/ui/client/clickgui/ClickGui;", "setClickGui", "(Lnet/ccbluex/liquidbounce/ui/client/clickgui/ClickGui;)V", "clientRichPresence", "Lnet/ccbluex/liquidbounce/features/special/ClientRichPresence;", "getClientRichPresence", "()Lnet/ccbluex/liquidbounce/features/special/ClientRichPresence;", "setClientRichPresence", "(Lnet/ccbluex/liquidbounce/features/special/ClientRichPresence;)V", "combatManager", "Lme/manager/CombatManager;", "getCombatManager", "()Lme/manager/CombatManager;", "setCombatManager", "(Lme/manager/CombatManager;)V", "commandManager", "Lnet/ccbluex/liquidbounce/features/command/CommandManager;", "getCommandManager", "()Lnet/ccbluex/liquidbounce/features/command/CommandManager;", "setCommandManager", "(Lnet/ccbluex/liquidbounce/features/command/CommandManager;)V", "darkMode", "", "getDarkMode", "()Z", "setDarkMode", "(Z)V", "eventManager", "Lnet/ccbluex/liquidbounce/event/EventManager;", "getEventManager", "()Lnet/ccbluex/liquidbounce/event/EventManager;", "setEventManager", "(Lnet/ccbluex/liquidbounce/event/EventManager;)V", "fileManager", "Lnet/ccbluex/liquidbounce/file/FileManager;", "getFileManager", "()Lnet/ccbluex/liquidbounce/file/FileManager;", "setFileManager", "(Lnet/ccbluex/liquidbounce/file/FileManager;)V", "fontLoaders", "Lnet/ccbluex/liquidbounce/ui/cnfont/FontLoaders;", "getFontLoaders", "()Lnet/ccbluex/liquidbounce/ui/cnfont/FontLoaders;", "setFontLoaders", "(Lnet/ccbluex/liquidbounce/ui/cnfont/FontLoaders;)V", "guiwelcome", "Lnet/minecraft/client/gui/GuiScreen;", "getGuiwelcome", "()Lnet/minecraft/client/gui/GuiScreen;", "setGuiwelcome", "(Lnet/minecraft/client/gui/GuiScreen;)V", "hud", "Lnet/ccbluex/liquidbounce/ui/client/hud/HUD;", "getHud", "()Lnet/ccbluex/liquidbounce/ui/client/hud/HUD;", "setHud", "(Lnet/ccbluex/liquidbounce/ui/client/hud/HUD;)V", "isStarting", "setStarting", "isVerified", "setVerified", "isVersionVerified", "setVersionVerified", "latestVersion", "", "getLatestVersion", "()I", "setLatestVersion", "(I)V", "mainMenuPrep", "getMainMenuPrep", "setMainMenuPrep", "moduleManager", "Lnet/ccbluex/liquidbounce/features/module/ModuleManager;", "getModuleManager", "()Lnet/ccbluex/liquidbounce/features/module/ModuleManager;", "setModuleManager", "(Lnet/ccbluex/liquidbounce/features/module/ModuleManager;)V", "musicManager", "Lcn/hanabi/gui/cloudmusic/MusicManager;", "getMusicManager", "()Lcn/hanabi/gui/cloudmusic/MusicManager;", "setMusicManager", "(Lcn/hanabi/gui/cloudmusic/MusicManager;)V", "scriptManager", "Lnet/ccbluex/liquidbounce/script/ScriptManager;", "getScriptManager", "()Lnet/ccbluex/liquidbounce/script/ScriptManager;", "setScriptManager", "(Lnet/ccbluex/liquidbounce/script/ScriptManager;)V", "tipSoundManager", "Lnet/ccbluex/liquidbounce/utils/misc/sound/TipSoundManager;", "getTipSoundManager", "()Lnet/ccbluex/liquidbounce/utils/misc/sound/TipSoundManager;", "setTipSoundManager", "(Lnet/ccbluex/liquidbounce/utils/misc/sound/TipSoundManager;)V", "toggleVolume", "", "getToggleVolume", "()F", "setToggleVolume", "(F)V", "trayIcon", "Ljava/awt/TrayIcon;", "getTrayIcon", "()Ljava/awt/TrayIcon;", "setTrayIcon", "(Ljava/awt/TrayIcon;)V", "windows", "getWindows", "wrapper", "Lnet/ccbluex/liquidbounce/api/Wrapper;", "getWrapper", "()Lnet/ccbluex/liquidbounce/api/Wrapper;", "setWrapper", "(Lnet/ccbluex/liquidbounce/api/Wrapper;)V", "displayTray", "", "Title", "Text", "type", "Ljava/awt/TrayIcon$MessageType;", "getRank", "startClient", "stopClient", "Fnierior"})
public final class LiquidBounce {
    @NotNull
    public static final String CLIENT_NAME = "Fnierior";
    @NotNull
    public static final String CLIENT_VERSION = "#0705";
    @NotNull
    public static final String CLIENT_CREATOR = "\u7b26\u6faa";
    @NotNull
    public static final String SPECIAL_DEV = "RyF_";
    @NotNull
    public static FontLoaders fontLoaders;
    @NotNull
    public static final String MINECRAFT_VERSION = "1.12.2";
    @NotNull
    private static StringCompanionObject Ranking;
    @NotNull
    public static final String CLIENT_CLOUD = "https://cloud.liquidbounce.net/LiquidBounce";
    private static boolean isStarting;
    private static boolean mainMenuPrep;
    private static boolean darkMode;
    @NotNull
    public static ModuleManager moduleManager;
    @NotNull
    public static CommandManager commandManager;
    @NotNull
    public static EventManager eventManager;
    @NotNull
    public static FileManager fileManager;
    @NotNull
    public static ScriptManager scriptManager;
    @NotNull
    public static CombatManager combatManager;
    @NotNull
    public static TipSoundManager tipSoundManager;
    @NotNull
    public static MusicManager musicManager;
    @NotNull
    public static GuiScreen guiwelcome;
    private static float toggleVolume;
    private static final boolean windows;
    @Nullable
    private static TrayIcon trayIcon;
    @NotNull
    public static HUD hud;
    @NotNull
    public static AnimationHandler animationHandler;
    @NotNull
    public static ClickGui clickGui;
    private static int latestVersion;
    @Nullable
    private static IResourceLocation background;
    private static boolean isVersionVerified;
    private static boolean isVerified;
    @NotNull
    public static ClientRichPresence clientRichPresence;
    @NotNull
    public static Wrapper wrapper;
    public static final LiquidBounce INSTANCE;

    @NotNull
    public final FontLoaders getFontLoaders() {
        FontLoaders fontLoaders = LiquidBounce.fontLoaders;
        if (fontLoaders == null) {
            Intrinsics.throwUninitializedPropertyAccessException("fontLoaders");
        }
        return fontLoaders;
    }

    public final void setFontLoaders(@NotNull FontLoaders fontLoaders) {
        Intrinsics.checkParameterIsNotNull(fontLoaders, "<set-?>");
        LiquidBounce.fontLoaders = fontLoaders;
    }

    @NotNull
    public final StringCompanionObject getRanking() {
        return Ranking;
    }

    public final void setRanking(@NotNull StringCompanionObject stringCompanionObject) {
        Intrinsics.checkParameterIsNotNull(stringCompanionObject, "<set-?>");
        Ranking = stringCompanionObject;
    }

    public final boolean isStarting() {
        return isStarting;
    }

    public final void setStarting(boolean bl) {
        isStarting = bl;
    }

    public final boolean getMainMenuPrep() {
        return mainMenuPrep;
    }

    public final void setMainMenuPrep(boolean bl) {
        mainMenuPrep = bl;
    }

    public final boolean getDarkMode() {
        return darkMode;
    }

    public final void setDarkMode(boolean bl) {
        darkMode = bl;
    }

    @NotNull
    public final ModuleManager getModuleManager() {
        ModuleManager moduleManager = LiquidBounce.moduleManager;
        if (moduleManager == null) {
            Intrinsics.throwUninitializedPropertyAccessException("moduleManager");
        }
        return moduleManager;
    }

    public final void setModuleManager(@NotNull ModuleManager moduleManager) {
        Intrinsics.checkParameterIsNotNull(moduleManager, "<set-?>");
        LiquidBounce.moduleManager = moduleManager;
    }

    @NotNull
    public final CommandManager getCommandManager() {
        CommandManager commandManager = LiquidBounce.commandManager;
        if (commandManager == null) {
            Intrinsics.throwUninitializedPropertyAccessException("commandManager");
        }
        return commandManager;
    }

    public final void setCommandManager(@NotNull CommandManager commandManager) {
        Intrinsics.checkParameterIsNotNull(commandManager, "<set-?>");
        LiquidBounce.commandManager = commandManager;
    }

    @NotNull
    public final EventManager getEventManager() {
        EventManager eventManager = LiquidBounce.eventManager;
        if (eventManager == null) {
            Intrinsics.throwUninitializedPropertyAccessException("eventManager");
        }
        return eventManager;
    }

    public final void setEventManager(@NotNull EventManager eventManager) {
        Intrinsics.checkParameterIsNotNull(eventManager, "<set-?>");
        LiquidBounce.eventManager = eventManager;
    }

    @NotNull
    public final FileManager getFileManager() {
        FileManager fileManager = LiquidBounce.fileManager;
        if (fileManager == null) {
            Intrinsics.throwUninitializedPropertyAccessException("fileManager");
        }
        return fileManager;
    }

    public final void setFileManager(@NotNull FileManager fileManager) {
        Intrinsics.checkParameterIsNotNull(fileManager, "<set-?>");
        LiquidBounce.fileManager = fileManager;
    }

    @NotNull
    public final ScriptManager getScriptManager() {
        ScriptManager scriptManager = LiquidBounce.scriptManager;
        if (scriptManager == null) {
            Intrinsics.throwUninitializedPropertyAccessException("scriptManager");
        }
        return scriptManager;
    }

    public final void setScriptManager(@NotNull ScriptManager scriptManager) {
        Intrinsics.checkParameterIsNotNull(scriptManager, "<set-?>");
        LiquidBounce.scriptManager = scriptManager;
    }

    @NotNull
    public final CombatManager getCombatManager() {
        CombatManager combatManager = LiquidBounce.combatManager;
        if (combatManager == null) {
            Intrinsics.throwUninitializedPropertyAccessException("combatManager");
        }
        return combatManager;
    }

    public final void setCombatManager(@NotNull CombatManager combatManager) {
        Intrinsics.checkParameterIsNotNull(combatManager, "<set-?>");
        LiquidBounce.combatManager = combatManager;
    }

    @NotNull
    public final TipSoundManager getTipSoundManager() {
        TipSoundManager tipSoundManager = LiquidBounce.tipSoundManager;
        if (tipSoundManager == null) {
            Intrinsics.throwUninitializedPropertyAccessException("tipSoundManager");
        }
        return tipSoundManager;
    }

    public final void setTipSoundManager(@NotNull TipSoundManager tipSoundManager) {
        Intrinsics.checkParameterIsNotNull(tipSoundManager, "<set-?>");
        LiquidBounce.tipSoundManager = tipSoundManager;
    }

    @NotNull
    public final MusicManager getMusicManager() {
        MusicManager musicManager = LiquidBounce.musicManager;
        if (musicManager == null) {
            Intrinsics.throwUninitializedPropertyAccessException("musicManager");
        }
        return musicManager;
    }

    public final void setMusicManager(@NotNull MusicManager musicManager) {
        Intrinsics.checkParameterIsNotNull(musicManager, "<set-?>");
        LiquidBounce.musicManager = musicManager;
    }

    @NotNull
    public final GuiScreen getGuiwelcome() {
        GuiScreen guiScreen = guiwelcome;
        if (guiScreen == null) {
            Intrinsics.throwUninitializedPropertyAccessException("guiwelcome");
        }
        return guiScreen;
    }

    public final void setGuiwelcome(@NotNull GuiScreen guiScreen) {
        Intrinsics.checkParameterIsNotNull(guiScreen, "<set-?>");
        guiwelcome = guiScreen;
    }

    public final float getToggleVolume() {
        return toggleVolume;
    }

    public final void setToggleVolume(float f) {
        toggleVolume = f;
    }

    public final boolean getWindows() {
        return windows;
    }

    @Nullable
    public final TrayIcon getTrayIcon() {
        return trayIcon;
    }

    public final void setTrayIcon(@Nullable TrayIcon trayIcon) {
        LiquidBounce.trayIcon = trayIcon;
    }

    @NotNull
    public final HUD getHud() {
        HUD hUD = hud;
        if (hUD == null) {
            Intrinsics.throwUninitializedPropertyAccessException("hud");
        }
        return hUD;
    }

    public final void setHud(@NotNull HUD hUD) {
        Intrinsics.checkParameterIsNotNull(hUD, "<set-?>");
        hud = hUD;
    }

    @NotNull
    public final AnimationHandler getAnimationHandler() {
        AnimationHandler animationHandler = LiquidBounce.animationHandler;
        if (animationHandler == null) {
            Intrinsics.throwUninitializedPropertyAccessException("animationHandler");
        }
        return animationHandler;
    }

    public final void setAnimationHandler(@NotNull AnimationHandler animationHandler) {
        Intrinsics.checkParameterIsNotNull(animationHandler, "<set-?>");
        LiquidBounce.animationHandler = animationHandler;
    }

    @NotNull
    public final ClickGui getClickGui() {
        ClickGui clickGui = LiquidBounce.clickGui;
        if (clickGui == null) {
            Intrinsics.throwUninitializedPropertyAccessException("clickGui");
        }
        return clickGui;
    }

    public final void setClickGui(@NotNull ClickGui clickGui) {
        Intrinsics.checkParameterIsNotNull(clickGui, "<set-?>");
        LiquidBounce.clickGui = clickGui;
    }

    public final int getLatestVersion() {
        return latestVersion;
    }

    public final void setLatestVersion(int n) {
        latestVersion = n;
    }

    @Nullable
    public final IResourceLocation getBackground() {
        return background;
    }

    public final void setBackground(@Nullable IResourceLocation iResourceLocation) {
        background = iResourceLocation;
    }

    public final boolean isVersionVerified() {
        return isVersionVerified;
    }

    public final void setVersionVerified(boolean bl) {
        isVersionVerified = bl;
    }

    public final boolean isVerified() {
        return isVerified;
    }

    public final void setVerified(boolean bl) {
        isVerified = bl;
    }

    @NotNull
    public final String getRank() {
        String QQ = QQUtils.getSubString(QQUtils.getLoginQQList().toString(), "=", "}");
        if (Intrinsics.areEqual(QQ, "256293448")) {
            return "Developer";
        }
        if (Intrinsics.areEqual(QQ, "2187359214")) {
            return "Developer";
        }
        return "User";
    }

    @NotNull
    public final ClientRichPresence getClientRichPresence() {
        ClientRichPresence clientRichPresence = LiquidBounce.clientRichPresence;
        if (clientRichPresence == null) {
            Intrinsics.throwUninitializedPropertyAccessException("clientRichPresence");
        }
        return clientRichPresence;
    }

    public final void setClientRichPresence(@NotNull ClientRichPresence clientRichPresence) {
        Intrinsics.checkParameterIsNotNull(clientRichPresence, "<set-?>");
        LiquidBounce.clientRichPresence = clientRichPresence;
    }

    @NotNull
    public final Wrapper getWrapper() {
        Wrapper wrapper = LiquidBounce.wrapper;
        if (wrapper == null) {
            Intrinsics.throwUninitializedPropertyAccessException("wrapper");
        }
        return wrapper;
    }

    public final void setWrapper(@NotNull Wrapper wrapper) {
        Intrinsics.checkParameterIsNotNull(wrapper, "<set-?>");
        LiquidBounce.wrapper = wrapper;
    }

    private final void displayTray(String Title2, String Text2, TrayIcon.MessageType type) throws AWTException {
        SystemTray tray = SystemTray.getSystemTray();
        Image image2 = Toolkit.getDefaultToolkit().createImage("icon.png");
        TrayIcon trayIcon = new TrayIcon(image2, "Tray Demo");
        trayIcon.setImageAutoSize(true);
        trayIcon.setToolTip("System tray icon demo");
        tray.add(trayIcon);
        trayIcon.displayMessage(Title2, Text2, type);
    }

    public final void startClient() {
        isStarting = true;
        ClientUtils.getLogger().info("Starting Fnierior b#0705, by \u7b26\u6faa");
        fileManager = new FileManager();
        EventManager eventManager = LiquidBounce.eventManager = new EventManager();
        if (eventManager == null) {
            Intrinsics.throwUninitializedPropertyAccessException("eventManager");
        }
        eventManager.registerListener(new RotationUtils());
        EventManager eventManager2 = LiquidBounce.eventManager;
        if (eventManager2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("eventManager");
        }
        eventManager2.registerListener(new AntiForge());
        EventManager eventManager3 = LiquidBounce.eventManager;
        if (eventManager3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("eventManager");
        }
        eventManager3.registerListener(new BungeeCordSpoof());
        EventManager eventManager4 = LiquidBounce.eventManager;
        if (eventManager4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("eventManager");
        }
        eventManager4.registerListener(new DonatorCape());
        EventManager eventManager5 = LiquidBounce.eventManager;
        if (eventManager5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("eventManager");
        }
        eventManager5.registerListener(new InventoryUtils());
        tipSoundManager = new TipSoundManager();
        musicManager = new MusicManager();
        clientRichPresence = new ClientRichPresence();
        combatManager = new CombatManager();
        EventManager eventManager6 = LiquidBounce.eventManager;
        if (eventManager6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("eventManager");
        }
        CombatManager combatManager = LiquidBounce.combatManager;
        if (combatManager == null) {
            Intrinsics.throwUninitializedPropertyAccessException("combatManager");
        }
        eventManager6.registerListener(combatManager);
        guiwelcome = new NewGuiWelcome();
        commandManager = new CommandManager();
        fontLoaders = new FontLoaders();
        Fonts.loadFonts();
        FontLoaders.initFonts();
        ModuleManager moduleManager = LiquidBounce.moduleManager = new ModuleManager();
        if (moduleManager == null) {
            Intrinsics.throwUninitializedPropertyAccessException("moduleManager");
        }
        moduleManager.registerModules();
        animationHandler = new AnimationHandler();
        try {
            Remapper.INSTANCE.loadSrg();
            ScriptManager scriptManager = LiquidBounce.scriptManager = new ScriptManager();
            if (scriptManager == null) {
                Intrinsics.throwUninitializedPropertyAccessException("scriptManager");
            }
            scriptManager.loadScripts();
            ScriptManager scriptManager2 = LiquidBounce.scriptManager;
            if (scriptManager2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("scriptManager");
            }
            scriptManager2.enableScripts();
        }
        catch (Throwable throwable) {
            ClientUtils.getLogger().error("Failed to load scripts.", throwable);
        }
        CommandManager commandManager = LiquidBounce.commandManager;
        if (commandManager == null) {
            Intrinsics.throwUninitializedPropertyAccessException("commandManager");
        }
        commandManager.registerCommands();
        FileManager fileManager = LiquidBounce.fileManager;
        if (fileManager == null) {
            Intrinsics.throwUninitializedPropertyAccessException("fileManager");
        }
        FileConfig[] fileConfigArray = new FileConfig[6];
        FileManager fileManager2 = LiquidBounce.fileManager;
        if (fileManager2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("fileManager");
        }
        fileConfigArray[0] = fileManager2.modulesConfig;
        FileManager fileManager3 = LiquidBounce.fileManager;
        if (fileManager3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("fileManager");
        }
        fileConfigArray[1] = fileManager3.valuesConfig;
        FileManager fileManager4 = LiquidBounce.fileManager;
        if (fileManager4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("fileManager");
        }
        fileConfigArray[2] = fileManager4.accountsConfig;
        FileManager fileManager5 = LiquidBounce.fileManager;
        if (fileManager5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("fileManager");
        }
        fileConfigArray[3] = fileManager5.friendsConfig;
        FileManager fileManager6 = LiquidBounce.fileManager;
        if (fileManager6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("fileManager");
        }
        fileConfigArray[4] = fileManager6.xrayConfig;
        FileManager fileManager7 = LiquidBounce.fileManager;
        if (fileManager7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("fileManager");
        }
        fileConfigArray[5] = fileManager7.shortcutsConfig;
        fileManager.loadConfigs(fileConfigArray);
        clickGui = new ClickGui();
        FileManager fileManager8 = LiquidBounce.fileManager;
        if (fileManager8 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("fileManager");
        }
        FileManager fileManager9 = LiquidBounce.fileManager;
        if (fileManager9 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("fileManager");
        }
        fileManager8.loadConfig(fileManager9.clickGuiConfig);
        try {
            CapeAPI.INSTANCE.registerCapeService();
        }
        catch (Throwable throwable) {
            ClientUtils.getLogger().error("Failed to register cape service", throwable);
        }
        hud = HUD.Companion.createDefault();
        FileManager fileManager10 = LiquidBounce.fileManager;
        if (fileManager10 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("fileManager");
        }
        FileManager fileManager11 = LiquidBounce.fileManager;
        if (fileManager11 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("fileManager");
        }
        fileManager10.loadConfig(fileManager11.hudConfig);
        ClientUtils.disableFastRender();
        GuiAltManager.loadGenerators();
        EaseVerify.INSTANCE.checkMom();
        EaseVerify.INSTANCE.tryVerify();
        EaseVerify.INSTANCE.tryMethod();
        if (windows && SystemTray.isSupported()) {
            try {
                trayIcon = new TrayIcon(ImageIO.read(Objects.requireNonNull(this.getClass().getResourceAsStream("/assets/minecraft/pride/icon128.png"))));
            }
            catch (Exception e) {
                e.printStackTrace();
            }
            TrayIcon trayIcon = LiquidBounce.trayIcon;
            if (trayIcon != null) {
                trayIcon.setImageAutoSize(true);
            }
            TrayIcon trayIcon2 = LiquidBounce.trayIcon;
            if (trayIcon2 != null) {
                trayIcon2.setToolTip(CLIENT_NAME);
            }
            try {
                SystemTray.getSystemTray().add(LiquidBounce.trayIcon);
            }
            catch (AWTException aWTException) {
                // empty catch block
            }
            TrayIcon trayIcon3 = LiquidBounce.trayIcon;
            if (trayIcon3 != null) {
                trayIcon3.displayMessage(CLIENT_NAME, "\u611f\u8c22\u4f7f\u7528Fnierior", TrayIcon.MessageType.NONE);
            }
            Sound.notificationsAllowed(true);
        }
        new Sound();
        isStarting = false;
    }

    public final void stopClient() {
        EventManager eventManager = LiquidBounce.eventManager;
        if (eventManager == null) {
            Intrinsics.throwUninitializedPropertyAccessException("eventManager");
        }
        eventManager.callEvent(new ClientShutdownEvent());
        FileManager fileManager = LiquidBounce.fileManager;
        if (fileManager == null) {
            Intrinsics.throwUninitializedPropertyAccessException("fileManager");
        }
        fileManager.saveAllConfigs();
        ClientRichPresence clientRichPresence = LiquidBounce.clientRichPresence;
        if (clientRichPresence == null) {
            Intrinsics.throwUninitializedPropertyAccessException("clientRichPresence");
        }
        clientRichPresence.shutdown();
    }

    private LiquidBounce() {
    }

    static {
        LiquidBounce liquidBounce;
        INSTANCE = liquidBounce = new LiquidBounce();
        Ranking = StringCompanionObject.INSTANCE;
        String string = System.getProperties().getProperty("os.name");
        Intrinsics.checkExpressionValueIsNotNull(string, "System.getProperties().getProperty(\"os.name\")");
        String string2 = string;
        boolean bl = false;
        String string3 = string2;
        if (string3 == null) {
            throw new TypeCastException("null cannot be cast to non-null type java.lang.String");
        }
        String string4 = string3.toLowerCase();
        Intrinsics.checkExpressionValueIsNotNull(string4, "(this as java.lang.String).toLowerCase()");
        windows = StringsKt.contains$default((CharSequence)string4, "windows", false, 2, null);
        isVersionVerified = true;
    }
}

