/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 */
package me.sound;

import me.sound.SoundPlayer;
import net.ccbluex.liquidbounce.LiquidBounce;
import net.minecraft.client.Minecraft;

public class Sound {
    public static Sound INSTANCE;
    public static final Minecraft mc;
    private static boolean notificationsAllowed;

    public static void notificationsAllowed(boolean value) {
        notificationsAllowed = value;
    }

    public Sound() {
        new SoundPlayer().playSound(SoundPlayer.SoundType.SPECIAL, LiquidBounce.moduleManager.getToggleVolume());
    }

    public void Volll() {
        new SoundPlayer().playSound(SoundPlayer.SoundType.VICTORY, LiquidBounce.moduleManager.getToggleVolume());
    }

    static {
        mc = Minecraft.func_71410_x();
        notificationsAllowed = false;
    }
}

