/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.NotNull
 */
package op.lbp.newVer;

import java.awt.Color;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0013\b\u00c6\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u0011\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006R\u0011\u0010\u0007\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\b\u0010\u0006R\u0011\u0010\t\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u0006R\u0011\u0010\u000b\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\f\u0010\u0006R\u0011\u0010\r\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u0006R\u0011\u0010\u000f\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0006R\u0011\u0010\u0011\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0006R\u0011\u0010\u0013\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0006R\u0011\u0010\u0015\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0006\u00a8\u0006\u0017"}, d2={"Lop/lbp/newVer/ColorManager;", "", "()V", "background", "Ljava/awt/Color;", "getBackground", "()Ljava/awt/Color;", "border", "getBorder", "button", "getButton", "buttonOutline", "getButtonOutline", "dropDown", "getDropDown", "moduleBackground", "getModuleBackground", "sliderButton", "getSliderButton", "textBox", "getTextBox", "unusedSlider", "getUnusedSlider", "Fnierior"})
public final class ColorManager {
    @NotNull
    private static final Color background;
    @NotNull
    private static final Color textBox;
    @NotNull
    private static final Color dropDown;
    @NotNull
    private static final Color button;
    @NotNull
    private static final Color moduleBackground;
    @NotNull
    private static final Color unusedSlider;
    @NotNull
    private static final Color sliderButton;
    @NotNull
    private static final Color border;
    @NotNull
    private static final Color buttonOutline;
    public static final ColorManager INSTANCE;

    @NotNull
    public final Color getBackground() {
        return background;
    }

    @NotNull
    public final Color getTextBox() {
        return textBox;
    }

    @NotNull
    public final Color getDropDown() {
        return dropDown;
    }

    @NotNull
    public final Color getButton() {
        return button;
    }

    @NotNull
    public final Color getModuleBackground() {
        return moduleBackground;
    }

    @NotNull
    public final Color getUnusedSlider() {
        return unusedSlider;
    }

    @NotNull
    public final Color getSliderButton() {
        return sliderButton;
    }

    @NotNull
    public final Color getBorder() {
        return border;
    }

    @NotNull
    public final Color getButtonOutline() {
        return buttonOutline;
    }

    private ColorManager() {
    }

    static {
        ColorManager colorManager;
        INSTANCE = colorManager = new ColorManager();
        background = new Color(241, 243, 247);
        textBox = new Color(170, 170, 170);
        dropDown = new Color(238, 238, 238);
        button = new Color(238, 238, 238);
        moduleBackground = new Color(251, 251, 251);
        unusedSlider = new Color(154, 154, 154);
        sliderButton = new Color(69, 69, 69);
        border = new Color(241, 243, 247);
        buttonOutline = new Color(241, 243, 247);
    }
}

