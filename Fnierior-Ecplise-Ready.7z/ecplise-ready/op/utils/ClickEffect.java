/*
 * Decompiled with CFR 0.152.
 */
package op.utils;

import java.awt.Color;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import op.utils.SimpleAnimation;

public class ClickEffect {
    private float x;
    private float y;
    private SimpleAnimation animation = new SimpleAnimation(0.0f);

    public ClickEffect(float x, float y) {
        this.x = x;
        this.y = y;
        this.animation.setValue(0.0f);
    }

    public void draw() {
        this.animation.setAnimation(100.0f, 12.0);
        double radius = 8.0f * this.animation.getValue() / 100.0f;
        int alpha = (int)(255.0f - 255.0f * this.animation.getValue() / 100.0f);
        int color = new Color(255, 255, 255, alpha).getRGB();
        RenderUtils.drawArc(this.x, this.y, radius, color, 0, 360.0, 5);
    }

    public boolean canRemove() {
        return this.animation.getValue() > 99.0f;
    }
}

